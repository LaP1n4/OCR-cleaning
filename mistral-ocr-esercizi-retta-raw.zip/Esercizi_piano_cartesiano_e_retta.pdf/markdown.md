Capitolo 4

PIANO CARTESIANO E RETTA

# ESERCIZI

12 Attività interattive,
9 Prova tu

10 Codici Python

# 1 Punti e segmenti

# Punti nel piano cartesiano

Teoria a pagina 193

1 attività interattiva

1 LEGGI IL GRAFICO Scrivi le coordinate dei punti indicati in figura.

![img-0.jpeg](img-0.jpeg)

2 LEGGI IL GRAFICO Per ogni figura scrivi quali punti hanno ordinata positiva e quali hanno ascissa negativa.

![img-1.jpeg](img-1.jpeg)

3 Rappresenta nel piano cartesiano i seguenti punti:

$$A(-2; 5); \quad B(-4; -1); \quad C(3; 0);$$

$$D(2; -5); \quad E\left(-\frac{5}{2}; 2\right).$$

4 Senza rappresentarli nel piano cartesiano indica a quale quadrante appartengono i seguenti punti:

$$A\left(-\frac{1}{2}; 2\right); \quad B(4; -5); \quad C(1 - \sqrt{2}; 1);$$

$$D(-6; -2).$$

5 VERO O FALSO?

a. I punti che si trovano sull'asse delle ordinate hanno coordinate \((a;0)\)
b. \(A(-1; - 3)\) si trovava nel terzo quadrante.
c. I punti che appartengono al quarto quadrante hanno coordinate opposte.
d. Tutti i punti di ascissa 0 si trovano sull'asse delle ordinate.

V F

V F

V F

V F

6 Disegna il quadrilatero di vertici:

$$A(5; -1), B(3; 3), C(-2; 4), D(-1; -4).$$

Rispondi alle seguenti domande.

a. Quale vertic ha I'ordinata maggiore?
b. Quale vertic ha l'ascissa minore?
c. Quali vertici hanno ascissa negativa?

7 Indica in quale quadrante si trova un punto se:

a. l'ascissa è negativa e l'ordinata positiva;
b. le sue coordinate sono entrambé positive;
c. le sue coordinate sono tali che \(xy > 0\)
d. le sue coordinate sono entrambé nulle;
e. I'ascissa e uguall'ordinata.

8 Per quale valore di $a$ il punto $P(-3a - 1; 6a + 6)$

appartiene all'asse $y$? E all'asse $x$?

$$\left[ -\frac{1}{3}; -1 \right]$$

9 YOU & MATHS The point $(a, b)$ is reflected over the $y$-axis to the point $(c, d)$, which is then reflected over the $x$-axis to the point $(e, f)$. Compute the value of $ab - ef$.

A $2ab$

C $-1$

E $1$

B $ab + b^2$

D $0$

(USA, Wolsborn-Drazovich Memorial Math Contest)

10 Dato il punto $P(3a; a + 2)$, determina per quali valori di $a$ il punto appartiene al secondo quadrante. $[-2 < a < 0]$

# RISOLVI IN 2 PASSI

1 Un punto \(P(x_{P};y_{P})\) appartiene al secondo quadrante se \(x_{P} <   0\mathrm{e}y_{P} > 0\)
2 Poni le due condizioni a sistema e risolvilo.

11 Trova per quali valori di $k$ $A(2 - k; 2k - 1)$ appartiene al primo quadrante.

$$\left[ \frac{1}{2} < k < 2 \right]$$

ESERCIZI

214

PUNTI E SEGMENTI

Paragrafo 1

12 Per quali valori di \(kP(2k - 5; k^2 - 5k + 6)\) è un punto dell'asse x? Calcola il valore corrispondente dell'ascissa. \([k = 2, x = -1; k = 3, x = 1]\)
13 Per quali valori di \(a\) il punto \(P(4a - a^2; 2a - 12)\) appartiene al quarto quadrante? \([0 < a < 4]\)

VERIFICA CON PYTHON

Scrivi un programma che, considerato il punto P dell'esercizio, chieda in input un valore di a, stampi le coordinate di P e rappresenti il punto nel piano cartesiano. Usa il programma per verificare il risultato che hai ottenuto.

14 Trova per quali valori di k il punto

$$A \left( 2 - | k |, \frac { 1 - 2 k } { k ^ { 2 } - 4 } \right)$$

appartiene al primo quadrante. $$\left\{ \frac { 1 } { 2 } < k < 2 \right\}$$

15 In un riferimento cartesiano, A è l'insieme dei punti che hanno ascissa x ≥ 1, B è l'insieme dei punti che hanno ordinata y > 3. Disegna A ∩ B.

In un riferimento cartesiano, \(A\) è l'insieme dei punti che hanno ascissa \(x\) tale che \(-1 < x \leq 6\) e \(B\) è l'insieme dei punti che hanno ordinata \(y\) tale che \(-1 \leq y < 8\). Disegna \(A \cap B\).
Dato il punto \(A\left(\sqrt{a - 1};\frac{a}{2} -1\right)\) ,trova per quali valori di a il punto e interno al quadrato che ha i lati paralleliagli assicartesianieha due vertici di coordinate \((-1;0)\) e(3;4). [2<a<10]
18 Calcola per quali valori di \(a\) il punto

$$P ( | a + 1 | ; a - 4 )$$

appartiene alla striscia individuata dalle parallele all'asse y passanti per A(-2; 0) e B(4; 0). $$[ - 5 \leq a \leq 3 ]$$

LEGGI IL GRAFICO Indica per ciascun insieme di punti evidenziato la condizione sulle coordinate che lo descrive.

![img-2.jpeg](img-2.jpeg)

![img-3.jpeg](img-3.jpeg)

![img-4.jpeg](img-4.jpeg)

![img-5.jpeg](img-5.jpeg)

Rappresenta nel piano cartesiano gli insiemi dei punti P(x; y) le cui coordinate soddisfano le seguenti condizioni.

21 $$\left\{ \begin{array} { l } { | x - 4 | < 2 } \\ { 1 + y ^ { 2 } < 5 } \end{array} \right.$$

23 $$\left\{ \begin{array} { l } { x < - 2 } \\ { y < 1 } \end{array} \right. \vee \left\{ \begin{array} { l } { x \geq 3 } \\ { y ^ { 2 } \leq 1 6 } \end{array} \right.$$

22 $$\left\{ \begin{array} { l } { x = 4 } \\ { 1 \leq y < 7 } \end{array} \right.$$

24 $$\left\{ \begin{array} { l } { | x - 2 | < 3 } \\ { | y | \leq 2 } \end{array} \right.$$

25 Rappresenta i punti dell'asse x la cui ascissa verifica la condizione:

a. $$| x | \geq 3;$$

b. $$| 2 x - 1 | = 3;$$

c. $$| 3 x + 2 | < 1.$$

26 Rappresenta i punti dell'asse y la cui ordinata verifica la condizione:

a. $$| y ^ { 2 } - 3 | \leq 1;$$

b. $$| 1 - 3 y | = 6;$$

c. $$| y - 4 | > 2.$$

27 LEGGI IL GRAFICO VERO O FALSO?

![img-6.jpeg](img-6.jpeg)

a. Il rettangolo della figura può essere individuato da

$$\left\{ ( x ; y ) \mid x ^ { 2 } - x \leq 0 \land \mid y - 3 \mid \leq 3 \right\} .$$

b. La disequazione \(x^{2} - 4x\leq 0\) nel piano cartesiano e verificata solo dai punti del segmente di estremi (0; 0) e (4; 0).
c. I punti che verificano il systema \(\left\{ \begin{array}{l} |x| \leq 1 \\ |y| \leq 3 \end{array} \right.\) appar tengono a un rettangolo che ha centro nell'origine e un vertic di coordinate (1; 3).

V F

V F

V F

215

ESERCIZIO

Capitolo 4

PIANO CARTESIANO E RETTA

# Distanza fra due punti

Teoria a pagina 194

1 attività interattiva

# I FONDAMENTALI

Prova tu fai un esercizio simile interattiva

# Calcolare la distanza fra due punti

Dati i punti $A(4; 1)$, $B(4; 4)$ e $C(-2; 4)$, calcoliamo le distanze $\overline{AB}$, $\overline{BC}$ e $\overline{CA}$.

I punti $A(4; 1)$ e $B(4; 4)$ hanno la stessa ascissa, quindi:

![img-7.jpeg](img-7.jpeg)

$$\overline{AB} = |y_A - y_B| = |1 - 4| = |-3| = 3.$$

I punti $B(4; 4)$ e $C(-2; 4)$ hanno la stessa ordinata, quindi:

$$\overline{BC} = |x_B - x_C| = |4 - (-2)| = |4 + 2| = |6| = 6.$$

I punti $C(-2; 4)$ e $A(4; 1)$ hanno ascisse e ordinate diverse:

$$\overline{CA} = \sqrt{(x_C - x_A)^2 + (y_C - y_A)^2} = \sqrt{(-2 - 4)^2 + (4 - 1)^2} =$$

$$\sqrt{36 + 9} = \sqrt{45} = 3\sqrt{5}.$$

Per la presenza dei quadrati, è indifferente scegliere $C$ o $A$ come primo punto.

$$A(x_A; y_A), B(x_B; y_B)$$

$$\overline{AB} = \sqrt{(x_A - x_B)^2 + (y_A - y_B)^2}$$

# Calcola la distanza fra i punti indicati.

28

$A(2; 1)$,

$B(2; 6)$.

29

$A(-4; \frac{4}{3})$,

$B(-4; \frac{5}{6})$.

30

$A(-\frac{3}{4}; 4)$,

$B(\frac{17}{4}; 2)$.

31

$A(2; 6)$,

$B(9; -1)$.

32

$A(-10; \frac{1}{2})$,

$B(1; \frac{1}{2})$.

33

$A(\frac{4}{3}; 15)$,

$B(\frac{1}{3}; 7)$.

34

$A(2 + \sqrt{2}; 0)$,

$B(2; \sqrt{7})$.

35

$A(-\sqrt{2}; -1)$,

$B(\sqrt{18}; -6)$.

# Trova la distanza dei seguenti punti dall'origine.

36

$A(-4; -3), B(2; -1)$.

37

$A(8; -15), B(-6; 8)$.

38

$A(-1; 7), B(-7; -1)$.

# Determina il perimetro dei triangoli che hanno i seguenti vertici.

39

$A(2; 4), B(2; 1), C(6; 3)$.

40

$A(\frac{1}{2}; 7), B(-2; 3), C(3; -1)$.

41

$A(6; 3), B(-1; 3), C(1; -2)$.

# LEGGI IL GRAFICO Calcola il perimetro dei seguenti poligoni.

![img-8.jpeg](img-8.jpeg)

![img-9.jpeg](img-9.jpeg)

![img-10.jpeg](img-10.jpeg)

42

![img-11.jpeg](img-11.jpeg)

![img-12.jpeg](img-12.jpeg)

45

REALTÀ E MODELLI Il Quadrilatero della Moda è una zona di Milano famosa per i negozi di lusso. Deve il suo nome al fatto che la delimitano quattro strade, via Monte Napoleone, via Manzoni, via della Spiga e corso Venezia, formando una figura simile a un quadrilatero. In un sistema di riferimento come quello in figura, con l'unità di misura in decametri, possiamo assumere che i vertici del quadrilatero abbiano coordinate $A(30; 0)$, $B(46; 17)$, $C(15; 54)$ e $D(0; 33)$. Karim percorre tutto il quadrilatero, camminando alla velocità costante di 5 km/h e senza soste. Quanto tempo impiega?

[circa 17 minuti]

ESERCIZI

216

PUNTI E SEGMENTI

Paragrafo 1

46 Calcola il perimetro del quadrilatero i cui vertici sono \(A(-5;6),B(0;6),C(2;2),D(-3; - 3).\) \([5 + 5\sqrt{2} +2\sqrt{5} +\sqrt{85}]\)
47 Stabilisci se il triangolo \( ABC \) di vertici \( A(-5;6) \), \( B(-1;4) \), \( C(4; - 1) \) è isoscele. [no]
48 Verifica che il triangolo con i vertici nei punti \(A(-3;0),B(5;0)\in C(1;4\sqrt{3})\) è equilatero.
Un triangolo ha vertici \(A(-3;2)\in B(5;2)\) e area \(S = 16\) . Determina le coordinate del terzo vertice \(C\) , sapendo che appartiene al semiasse delle ordinate positive. \([C(0;6)]\)
50 Verifica che il quadrilatero con i vertici \(A(2;1)\) \(B(8;2),C(11;7),D(5;6)\) è un parallelogramma. (Suggerimento. Verifica che i lati opposti sono congruenti.)
Stabilisci se il triangolo \( ABC \) di vertici \( A(1; -2) \), \( B(-1; 2) \), \( C(-1; -3) \) è un triangolo rettangolo. (Suggerimento. Verifica se le misure dei lati soddisfano il teorema di Pitagora.)
52 Determinina il punto \(P\) sull'asse \(x\) equidistante da \(A(-5;5)\) e da \(B(0;2)\). \(\left[P\left(-\frac{23}{5};0\right)\right]\)
53 Individua il punto \(P\) che ha ordinata uguate all'asciissa ed è equidistante da \(A(-2;1)\) e \(B(5; - 4)\) \([P(9;9)]\)
54 Verifica che il triangolo di vertici \(A(2;2),B\left(6,\frac{3}{2}\right)\) \(C(4;5)\) è isoscele e calcola la misura del suo perimetro. \(\left[\sqrt{13}(1 + \sqrt{5})\right]\)
55 Trova per quali valori di \(k\) il punto \(P(k + 2; k + 1)\) è equidistante da \(A(-2;1)\) e \(B(4; -2)\). \(\left[-\frac{1}{2}\right]\)
RISOLVI CON PYTHON
Scriv un programma che risolva l'esercizio, using solve) della libreria SymPy.
56 Determinina per quali valori di a la distanza tra i punti \(A(2a + 3;2)\in B(1;2a)\) e uguate a 4. \(\pm 1]\)
57 Calcola per quali valori di \(k\) il segmento con estremi i punti \(P(2;1 + k)\in Q\left(\frac{k}{2};0\right)\) misura 5. \(\pm 4]\)
58 Dati i punti \(A(2k; - 1),B(-2; - k + 3),C(4;3)\) trova \(k\) in modo che risulti \(\overline{AB} = \overline{CO}\) ,essendo O l'origine degli assi cartesiani. \(\pm 1]\)
59 Trova il punto \(P(a; b)\) equidistante dai punti \(A(-4; 0), B(0; 3) \in C(1; 0)\). \(\left[P\left(-\frac{3}{2}, \frac{5}{6}\right)\right]\)
60 Determinina il circocentro del triangolo \( ABC \) con \( A(7;1),B(2;7),C(-2; - 2) \). (Suggerimento. Ricorda che il circocentro di un triangolo è il centro della circonferenza circoscritta ed è quindi equidistante dai tre vertici del triangolo.)

61 Dati i punti \(A(3;7),B(9; - 1)\in C(1;k)\) ,trova \(k\) in modo che il triangolo \(ABC\) sua rettangolo in C. [3]
62 Verifica che il quadrilatero AOBC di vertici \(A(-1; - 1),O(0;0),B(-2;2),C(-3;1)\) è un rettangolo. (Suggerimento. Verifica che i lati opposti sono congruenti e che le diagonali sono congruenti.)
Stabilisci se il quadrilatero di vertici consecutivi \(I(0;2),L(3; - 3),M(8;0),N(5;4)\) è un rettangolo.
64 LEGGI IL GRAFICO Verifica che il quadrilatero in figura è un rombo.

![img-13.jpeg](img-13.jpeg)

65 Dati i punti $A(-2;3)$, $B(1;-1)$ e $P(a-2;-3a)$, trova per quali valori di $a$ si ha:

$$\overline{PA}^2 + \overline{PB}^2 = 33. \quad \left[a = -1; a = \frac{7}{10}\right]$$

66 Determinina un punto \(P\) sull'asse \(x\) che abbia distanza da \(A(1;2)\) doppia della sua distanza da \(B(0;1)\). \(\left[(-1;0)\mathrm{o}\left(\frac{1}{3};0\right)\right]\)
67 Trova un punto \(P\) sull'asse \(y\) equidistante da \(A\left(-\frac{3}{2};1\right)\) e da \(B(2; - 1)\) . \(\left[\left(0; - \frac{7}{16}\right)\right]\)
68 Calcola le coordinate di un punto \(P\) , che ha ordinata positiva e tripla rispetto all'ascissa, in modo che \(\overline{PA} = 5\) , con \(A(-1;2)\) [(2;6)]
FISICA MOTO NEL PIANO Due corpi, \(A\in B\) ,si muovono su due strade rettilinee perpendicolari e al tempo \(t = 0\) si trovano entrambi in O. Il corpo A viaggia con moto uniformamente accelerato, con accelerazione \(a = 0,4\mathrm{m / s^2}\) e velocità \(\nu_{\mathrm{b}} = 4\mathrm{m / s}\) in O,mente B si muove con moto uniforme, con velocità \(\nu = 12\mathrm{m / s}\) Qual è la loro distanza dopo 1 minuto? [1,2 km]

![img-14.jpeg](img-14.jpeg)

![img-15.jpeg](img-15.jpeg)

217

ESERCIZI

Capitolo 4 PIANO CARTESIANO E RETTA

# Area di triangoli e poligoni

1 attività interattiva

Calcola l'area dei triangoli che hanno i vertici indicati.

70 A(1; 5), B(3; 1), C(8; 4).

# COMPLETA LO SVOLGIMENTO

![img-16.jpeg](img-16.jpeg)

Calcoliamo l'area $\mathcal{A}$ del rettangolo $AHKL$: $\mathcal{A} = \overline{AH} \cdot \overline{HK}$.

$$\overline{AH} = | \quad | = 4, \quad \overline{HK} = |8 - 1| = 7 \rightarrow \mathcal{A} = 4 \cdot 7 = 28.$$

Calcoliamo l'area del triangolo $T_1$: $\mathcal{A}_{T_1} = \frac{\overline{LC}}{2}$.

$$\overline{LC} = |5 - 4| = 1, \quad \overline{LA} = |8 - \quad| = 7 \rightarrow \mathcal{A}_{T_1} = \frac{1 \cdot 7}{2} = \frac{7}{2}.$$[{"box_2d": [105, 269, 519, 298], "label": "text", "caption": "Analogamente: $\\mathcal{A}_{T_2} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_2} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\quad \\quad \\quad \\quad \\quad \\quad \\text{analogamente: } \\mathcal{A}_{T_3} = \\frac{\\quad \\

PUNTI E SEGMENTI

Paragrafo 1

Determina le coordinate del punto medio del segmento di estremi A e B.

81 A(4; -3), B(10; -3).

85 A(1/3; 4), B(4; 1/2).

82 A(5; 1), B(5; 9).

86 A(1/3; -4), B(-1/2; 3).

83 A(0; 1), B(1; -1).

87 A(-2√3; 1), B(4√3; -3).

84 A(-3; 1/4), B(6; 3/4).

88 A(a-1; 2), B(2a+1/2; -2a).

89 TEST Il segmento AB ha punto medio M(5/2; 5). Se A(-1/2; -1), allora:

A B(11; 11/2).

B B(11/2; 11).

C B(-11/2; -11).

D B(-11; -11/2).

Per ogni segmento AB sono indicate le coordinate di un estremo e quelle del punto medio M. Calcola le coordinate dell'altro estremo.

90 A(2; 4), M(0; 2).

93 A(3/2; -4), M(3/2; 2).

91 A(3; 5), M(2; 1).

94 B(3/2; 5/2), M(4; 5).

92 A(-2; -1), M(-1; -4).

95 B(4/3; -3/4), M(0; 0).

GENERALIZZA CON PYTHON

Considera un segmento e il suo punto medio M. Scrivi un programma che chieda le coordinate di uno dei due estremi e di M e fornisca le coordinate dell'altro estremo. Negli input usa Fraction() del modulo fractions, utile per inserire anche frazioni nella forma m/n, per esempio 5/2, -3/4.

96 Trova le coordinate del punto P' simmetrico di P(2; 1) rispetto a C(5; 2).

[P'(8; 3)]

97 Nel triangolo ABC, di vertici A(-2; 4), B(0; 2), C(4; 6), determina i punti medi dei lati e la misura delle mediane. {(-1; 3), (2; 4), (1; 5); √34; 4; √10}

98 Dato il triangolo ABC con A(1; 3), B(6; 1) e C(3; -5), considera i punti medi M e N dei lati AC e BC e verifica che MN = 1/2 AB.

99 Dati i punti A(2k-1; 2) e B(3; 2k+5), trova k in modo che il punto medio del segmento AB abbia ascissa doppia dell'ordinata. [k = -6]

100 Il segmento AB ha per estremi i punti A(1; 2a+1) e B(a-2; -a). Trova a sapendo che il punto medio di AB dista √5 dall'origine O. [a = ±3]

101 I punti A(2; 1) e B(5; 5) sono vertici del triangolo ABC e M(1/2; -1) è il punto medio del lato AC. Determina:

a. le coordinate di C;

b. il perimetro del triangolo.

[a) C(-1; -3); b) 20]

102 I punti A(-2; 3) e B(3; 4) sono vertici del triangolo ABC. Sapendo che M(1; 1) è il punto medio del lato BC:

a. determina le coordinate di C;

b. verifica che il triangolo è isoscele;

c. calcola l'area del triangolo.

[a) C(-1; -2); c) 13]

103 Verifica che il triangolo ABC di vertici A(1; 3), B(4; 1), C(3; 11/4) è isoscele e trova la misura dell'altezza relativa alla base. [√13/4]

104 Determina le coordinate dei punti A' e B', simmetrici di A(0; 1) e B(5; 0) rispetto a C(2; 2), e verifica che il quadrilatero ABA'B' è un parallelogramma. [A'(4; 3); B'(-1; 4)]

![img-17.jpeg](img-17.jpeg)

ESERCIZI

219

Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

105 I punti $A(3; 6)$, $B(-3; 3)$ e $C(-2; 2)$ sono vertici consecutivi del parallelogramma $ABCD$. Calcola le coordinate del quarto vertice $D$. [D(4; 5)]

# RISOLVI IN 2 PASSI

3 Trova il punto medio \(M\) della diagonale \(AC\)
2 Poiché \(M\) èanche punto medio della diagonale \(BD\) ,usa la formula del punto medio per trovare \(D\)

106 Del parallelogramma \(ABCD\) sono noti i vertici consecutivi \(A(1;5),B(-4; - 7),C(2;1)\) .Calcola le coordinate del vertice \(D\) e il perimetro. (7; 13; 46)
107 Un parallelogramma \(ABCD\) ha due vertici consecutivi in \(A(1;2)\in B(7; - 1)\) e il punto di intersezione delle dia-gonali e \(P(4;3)\) . Determinina \(C\in D\) , il perimetro e l'area del parallelogramma. \(\left[C(7;4),D(1;7);10 + 6\sqrt{5};30\right]\)
108 Dato il segmento di estremi \(A(-1;1)\) e \(B(4; - 2)\) ,trova il segmento simmetrico \(A^{\prime}B^{\prime}\) rispetto al punto \(P(1;2)\) e determina sull'asse \(x\) un punto \(C\) in modo che il triangolo \(A^{\prime}B^{\prime}C\) sa isoscele sulla base \(A^{\prime}B^{\prime}\)

$$\left[ A'(3; 3), B'(-2; 6); C\left(-\frac{11}{5}; 0\right) \right]$$

109 Individua il vertice $C$ di un triangolo isoscele di base $AB$ con $A(-1; 1)$ e $B(2; 0)$, sapendo che l'altezza relativa ad $AB$ misura $\frac{\sqrt{10}}{2}$. [C$_1$(1; 2), C$_2$(0; -1)]

# Baricentro di un triangolo

Teoria a pagina 195

1 attività interattiva

Calcola le coordinate del baricentro dei triangoli che hanno i seguenti vertici.

110 \(A(-1;0)\) ， \(B(5;1)\) ， \(C(2;2)\)
11 \(A(-1;3)\) ， \(B(2; - 2)\) ， \(C(-5; - 1)\)
112 \(A(-3;7)\) ， \(B(0;1)\) ， \(C(6;6)\)
113 \(A(2;4)\) ， \(B(-1; - 5)\) ， \(C(5; - 2)\)
114 \(A(-3;0)\) ， \(B\left(\frac{1}{2}; - 3\right)\) ， \(C\left(\frac{5}{2};3\right)\)

$$x_G = \frac{x_A + x_B + x_C}{3} \quad y_G = \frac{y_A + y_B + y_C}{3}$$

115 \(A(1;0)\) ， \(B\left(\frac{2}{3}; - 7\right)\) ， \(C\left(-\frac{5}{3}; - 1\right)\)
116 \(A\left(\frac{\sqrt{2}}{2};0\right)\) \(B(3\sqrt{2};1)\) \(C\left(\frac{1}{\sqrt{2}};2\right)\)

117 Un triangolo \( ABC \) con \( A(-3;2) \in B(4;1) \) ha baricentro \( G(1;3) \). Calcola le coordinate di \( C \). [(2;6)]
118 Determinina le coordinate del terzo vertic di un triangolo, sapendo che due vertici sono \(A(3;8)\) e \(B(-1;2)\) e il baricentro e \(G(2;3)\). [C(4; -1)]
Nel triangolo \(ABC\) , con \(A(0;5)\) \(B(1;1)\in C\) sull'asse \(x\) , il baricentro \(G\) ha ascisa 3.Determina le coordinate di \(C\in G\) [C(8;0),G(3;2)]
120 Trova il valore di \(k\) per cui il triangolo di vertici \(A(2k;3 - k)\) \(B(k - 5; - k)\in C(4 - k; - 7)\) ha il baricentro di ascisa 1. [2]
E dato il triangolo \( ABC \) di vertici \( A(k - 1;3) \), \( B(2k;h - 2) \in C(4; - 2h) \). Trova \( k \in h \) in modo che il baricentro del triangolo sa l'origine degli assisi. \( [k = -1, h = 1] \)
Il triangolo \( ABC \) ha come vertici \( A(4a + 1;2) \), \( B(3 - a; a^2 - 6) \in C(5;0) \). Per quali valori di \( a \) il baricentro del triangolo appariene al secondo quadrante? \( [a < -3] \)

123 Determinina per quale valore di \(a\) il triangolo di vertici \(A(3;a + 2)\) \(B(-2a;1)\in C(1;a - 4)\) ha il baricentro \(G\) sull'asse \(y\) e calcola la distanza di \(G\) dai tre vertici. \([a = 2;3\sqrt{2},4,\sqrt{10} ]\)
FISICA EQUILIBRIO DEI SOLIDI In figura è rap-presentata una lamina metallica nelle viene appesa a una parete. Determinina le coordinate del suo baricentro. La lamina è in equilibrio? Perché? [(4; 2)]

![img-18.jpeg](img-18.jpeg)

220

DISTANZA, PUNTO MEDIO, BARICENTRO

RIEPILOGO

# Parti proporzionali in un segmento

125 Dato il segmento di estremi $A(-1; 1)$ e $B(5; 4)$, determina le coordinate del punto $C$ su $AB$ tale che $AC$ sia il doppio di $BC$.

# COMPLETA LO SVOLGIMENTO

![img-19.jpeg](img-19.jpeg)

Disegniamo il segmento $AB$ e fissiamo un punto $C(x; y)$ su $AB$. Tracciamo da $A, B$ e $C$ le rette parallele all'asse $x$ e all'asse $y$.

Poiché deve essere $AC \cong \underline{\quad}$, per il teorema di Talete valgono le due relazioni $A'C' \cong 2C'B'$ e $A'C'' \cong 2C'B''$.

Determiniamo le misure dei segmenti $A'C'$ e $C'B'$. Otteniamo:

$$\overline{A'C'} = x + 1 \quad \text{e} \quad \overline{C'B'} = \underline{\quad} - x.$$

Sostituiamo nella relazione $\overline{A'C'} = 2\overline{C'B'}$ e troviamo l'ascissa di $C$:

$$x + 1 = \underline{\quad} (5 - x) \rightarrow x + 1 = 10 - 2x \rightarrow x = 3.$$

In modo analogo troviamo che l'ordinata di $C$ è $y = \underline{\quad}$.

Il punto cercato è $C(3; 3)$.

126 Nel segmento di estremi $A(-3; 4)$ e $B(3; -2)$ individua le coordinate di un punto $C$ tale che $AC$ sia triplo di $BC$.

$$\left[ C \left( \frac{3}{2}, -\frac{1}{2} \right) \right]$$

127 Dato il segmento di estremi $A(-4; 0)$ e $B(6; 5)$, quali sono le coordinate di un punto $C$ tali che $AC$ sia un quarto di $BC$? [C(-2; 1)]

128 Dato il segmento di estremi $A(0; 6)$ e $B(7; 1)$, determina le coordinate dei punti che lo dividono in due parti proporzionali ai numeri $4$ e $3$.

$$\left[ \left( 3; \frac{27}{7} \right), \left( 4; \frac{22}{7} \right) \right]$$

129 Calcola le coordinate dei punti del segmento di estremi $A(4; 4)$ e $B(-2; -5)$ che lo suddividono in tre parti congruenti. [(2; 1), (0; -2)]

130 Individua le coordinate dei punti del segmento di estremi $A(-1; 3)$ e $B(7; -5)$ che lo suddividono in quattro parti congruenti.

$$[(1; 1), (3; -1), (5; -3)]$$

131 I punti $A(6; 1)$ e $B(1; 0)$ sono gli estremi della mediana $AM$ di un triangolo $ABC$. Trova il baricentro $G$ del triangolo.

$$\left[ G \left( \frac{8}{3}; \frac{1}{3} \right) \right]$$

# RIEPILOGO Distanza, punto medio, baricentro

132 COMPLETA

a. La distanza tra \(P(-1;3)\) e \(Q(2; - 1)\) e
b. Il punto medio del segmento \(AB\), di estremi \(A(\underline{\quad};6)\) e \(B(-3; - 8)\), e \(M(2;\underline{\quad})\)
c. Il simmetrico di \(A(-1;3)\) rispetto a \(C\left(2; - \frac{1}{2}\right)\) e \(A^{\prime}(\underline{\quad};\underline{\quad})\)
d. La distanza tra \(A(3; - 4)\in B(\underline{\quad};2)\dot{\varepsilon}6.\)

133 TEST Nel triangolo $ABC$ la mediana $AM$ ha per estremi i punti $A(-3; 5)$ e $B(-3; -1)$. Quali sono le coordinate del baricentro del triangolo $ABC$?

A (-3; 1).

C (-3; 2).

B (-3; 0).

D I dati non sono sufficienti per determinarle.

134 TEST Il triangolo di vertici $A(1; 2)$, $B(1 - 3a; -4)$ e $C(1; b - 4)$ ha baricentro $G(-1; -1)$ se:

A \(a = 1\wedge b = 3\)
B \(a = 3\wedge b = 2\)
C \(a = 2\wedge b = 3\)
D \(a = 2\wedge b = 1\)

135 TEST Un triangolo ha due vertici nei punti di coordinate $(-4; 1)$ e $(2; -1)$ e il terzo vertice nel punto di coordinate $(1; k)$. Per quanti valori reali di $k$ tale triangolo risulta isoscele?

A Nessuno.

D 5.

B 1.

E Infiniti.

C 4.

(Giochi di Archimede)

221

ESERCIZIO

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCITI

136 TEST Considera il piano cartesiano. Quanti sono i quadrati aventi un vertice in $(-1; -1)$ e tali che uno degli assi coordinati sia asse di simmetria del quadrato stesso?

A 2

B 3

C 4

D 5

E 6

(Kangourou Italia, Categoria Student)

137 Nel grafico, il punto $E$ ha coordinate $(0; 2)$ e $B$ giace sul semiasse $x$ positivo così che $\overline{BE} = \sqrt{7}$. Inoltre, il punto $C$ giace sul semiasse $x$ positivo così che $\overline{BC} = \overline{OB}$. Se il punto $D$ si trova nel primo quadrante in modo che $\overline{CBD} = 30^{\circ}$ e $\overline{BCD} = 90^{\circ}$, qual è la lunghezza di $ED$?

![img-20.jpeg](img-20.jpeg)

(CAN, Canadian Open Mathematics Challenge)

[√13]

138 Considera i punti $A(a + 2; 1)$ e $B(3; b - 1)$, con $a$ e $b$ numeri reali. Calcola $a$ e $b$ in modo che $\overline{AB}$ sia uguale a 1 e che il punto medio $M$ del segmento $AB$ abbia ordinata $\frac{1}{2}$. Trova poi i punti $C$ sull'asse $y$ la cui distanza da $A$ è $3\sqrt{10}$.

![img-21.jpeg](img-21.jpeg)

$$[a = 1, b = 1; C_1(0; 10), C_2(0; -8)]$$

139 LEGGI IL GRAFICO Calcola la misura del perimetro e dell'area del trapezio in figura. Congiungi $A$ e $D$ con il punto medio $M$ del lato $CB$ e verifica che il triangolo $ADM$ è isoscele. $[19 + \sqrt{61}; 39]$

![img-22.jpeg](img-22.jpeg)

140 Verifica che il triangolo di vertici $A(-3; -1)$, $B\left(2; \frac{3}{2}\right)$, $C(-9; 11)$ è rettangolo e che la mediana relativa all'ipotenusa è congruente alla metà dell'ipotenusa stessa.

141 Considera i punti $A(-2a; -1)$ e $B(a - 5; -1)$, con $a > 0$, e trova $a$ in modo che $\overline{AB}$ sia 7. Determina poi il punto $C$ di ascisa 5, in modo che il triangolo $ABC$ abbia area 35.

$$[a = 4; C_1(5; 9), C_2(5; -11)]$$

142 Del rombo $ABCD$ sono noti i vertici $A(1; 0)$, $B(5; 3)$ e il punto di incontro $M(1; 3)$ delle diagonali. Trova le coordinate degli altri vertici $C$ e $D$ e calcola il perimetro del rombo.

$$[C(1; 6), D(-3; 3); 20]$$

143 Determina il baricentro $G$ del triangolo di vertici $A(-1; 3)$, $B(6; 1)$, $C(4; 8)$ e verifica che la mediana $AM$ è divisa da $G$ in due parti, una doppia dell'altra. $[G(3; 4)]$

144 Determina le condizioni sul parametro $h$ affinché il baricentro del triangolo di vertici $P(1 + h; 2)$, $Q(h - 2; 2h)$ e $R(-3; h + 1)$ appartenga al secondo quadrante. $[-1 < h < 2]$

145 LEGGI IL GRAFICO Calcola il perimetro del triangolo che si ottiene congiungendo i punti medi dei lati del triangolo in figura e verifica che è la metà del perimetro del triangolo di partenza.

146 Dato il triangolo $ABC$ di vertici $A(0; 4)$, $B(1; -3)$ e $C(5; 0)$, calcola il perimetro e l'area. Trova poi il baricentro $G$ e il circocentro $P$ del triangolo.

$$\left[5\sqrt{2} + \sqrt{41} + 5; \frac{31}{2}; G\left(2; \frac{1}{3}\right), P\left(\frac{87}{62}; \frac{39}{62}\right)\right]$$

147 Determina le coordinate di un punto $P$ che ha l'ascissa uguale all'ordinata ed è equidistante dai punti $A(2; 0)$ e $B(0; 4)$ e trova il perimetro, l'area e il baricentro del triangolo $APB$.

$$\left[P(3; 3); \sqrt{10}(2 + \sqrt{2}); 5; G\left(\frac{5}{3}; \frac{7}{3}\right)\right]$$

148 I vertici di un triangolo sono $A(3; h + k + 1)$, $B(h - k; 2)$ e $C(h; h + 2k + 1)$. Per quali valori dei parametri $h$ e $k$ il baricentro è $G(1; 4)$? Rappresenta il triangolo ottenuto e, dopo aver verificato che è isoscele, determina il raggio della circonferenza in esso inscritta. (Suggerimento. La misura del raggio della circonferenza inscritta in un triangolo è uguale al rapporto tra le misure dell'area e del semiperimetro.)

$$\left[h = 1, k = 2; \frac{2\sqrt{5} - \sqrt{2}}{3}\right]$$

149 Nel triangolo isoscele $ABC$ i vertici della base sono $A(-2; 1)$ e $B(6; -1)$ e la misura dell'area è $\frac{85}{2}$.

a. Trova il vertice \(C\)
b. Determinina il raggio della circonferenza inscritta nel triangolo.

$$\left[a) C_1\left(\frac{9}{2}; 10\right), C_2\left(-\frac{1}{2}; -10\right); b) \frac{\sqrt{493} - 2\sqrt{17}}{5}\right]$$

222

DISTANZA, PUNTO MEDIO, BARICENTRO

RIEPILOGO

In un triangolo di vertici \(A(0;5),B(3; - 1),C(6;3)\) conduci da un punto \(P\) del lato \(AB\) la retta parallela al lato \(BC\) fino a incontrare il lato \(AC\) nel punto \(Q\) . Quali coordinate deve ave \(P\) affinché le aree dei triangoli \(PAQ\) e \(BAC\) stiano fra loro come 4 sta a 9? [P(2;1)]
151 Verifica che il triangolo di vertici \(A(4;2),B(9;4)\in C\left(8; - \frac{3}{4}\right)\) e isoscele e calcola la sua area. Trova le coordinate dei punti che dividono l'altezza \(CH\) del triangolo in tre segmenti congruenti.

$$\left[ \frac{87}{8}; P\left(\frac{15}{2}; \frac{1}{2}\right), Q\left(7; \frac{7}{4}\right) \right]$$

Dati i punti \(A(-4;0)\) e \(B(2;2)\) ,trova per quali valori di \(k\) il punto \(C(2k - 1;k + 3)\) e il vertic del triangolo isoscele \(ABC\) di base \(AB\) .Determina poi un punto \(P\) del lato \(AC\) tale che \(\frac{\overline{AP}}{7} = \overline{PC}\) . \(\left[-\frac{2}{7};P\left(-\frac{15}{8};\frac{19}{8}\right)\right]\)
153 Un triangolo \( ABC \) ha per vertici i punti \( A(k^2 - 1; 2) \), \( B(-4; 2k) \in C(5; 1 - 3k) \). Trova \( k \) in modo che il triangolo \( A'B'C' \), simmetrico di \( ABC \) rispetto al punto \( P(-1; 2) \), abbia per baricentro il punto \( G' \left(-\frac{10}{3}; \frac{11}{3}\right) \). Calcola poi il perimetro e l'area del triangolo \( ABC \).

$$\left[ k = 2; 2\sqrt{53} + 9\sqrt{2}; \frac{45}{2} \right]$$

154 Se $M(2; 2)$ è il punto di incontro delle diagonali di un quadrato $ABCD$ di lato $l = 2\sqrt{2}$, determina le coordinate dei vertici del quadrato, sapendo che le diagonali sono perpendicolari agli assi coordinati.

$$[A(4; 2), B(2; 4), C(0; 2), D(2; 0)]$$

155 I punti \(A(4;6),B(9;3)\in C(6; - 2)\) sono tre vertici consecutivi di un quadrilatero \(ABCD\) avente le diagonali che si intersecano in \(M\) punto medio della diagonale \(AC\) . Inoltre, \(M\) divide la diagonale \(BD\) in due parti tali che \(MD\) è doppio di \(MB\) . Determina le coordinate del vertic \(D\) e l'area di \(ABCD\) . [D(-3;0);51]
156 I punti \(A(-2;4)\in B(0;1)\) sono due vertici del parallelogramma \(ABCD\) e il punto \(M\left(2;\frac{9}{2}\right)\) è il punto di intersezione delle diagonali.

a. Determinina le coordinate dei vertici \(C\in D\)
b. Verifica che il parallelogramma è un rettangolo.
c. Calcolane il perimetro e l'area.

$$[a) C(6; 5), D(4; 8); c) 6\sqrt{13}; 26]$$

157 Trova i punti \(A^{\prime}\) e \(B^{\prime}\) simmetrici dei punti \(A(-2;1)\) e \(B(1;4)\) rispetto all'origine \(O\) degli assi, e determina nel quarto quadrante il punto \(C\) in modo che il triangolo \(A'B'C\) sa rettangolo, con ipotenusa \(A'C\), e abbia area uguate a 12. \([A'(2; - 1), B'(-1; - 4); C(3; - 8)]\)
158 Dati i punti \(A\left(\frac{5 - h}{5};\frac{10 + 7h}{5}\right),B(1 - 2h;2 - h)\in C(1 + 3h;2 - h)\) , con \(h\) numero reale diverso da 0:

a. verifica che il triangolo \( ABC \) è rettangolo in \( A \);
b. determina i valori di \(h\) affinché il triangolo abbia area 24;
c. verifica che, scelti due valori distincti di \(h\), i due triangoli che si ottengono sono simili.

$$[b) h = \pm 2]$$

159 Del triangolo $ABC$ sono noti il vertice $B(4; 5)$ e il punto medio $M(1; 1)$ del lato $AC$. Trova:

a. il baricentro \(G\) del triangolo;
b. le coordinate del vertice \(A\) sapendo che si trovava sull'asse \(y\), con ordinata minore di 5, e che il lato \(AB\) misura \(2\sqrt{5}\);
c. le coordinate del vertice \(C\)
d. il perimetro e l'area del triangolo.

160 Dati i punti $A(-2; 2)$ e $B(1; 8)$, determina:

a. il punto \(C\) di ordinata \(-1\) in modo che il triangolo \(ABC\) sa rettangolo in \(A\);
b. il punto \(D\) di ascissa \(-1\) in modo che il triangolo \(ABD\) sa isoscele con la base su \(AB\);
c. il rapporto tra le aree dei triangoli \( ABC \in ABD \);
d. il circocentro dei triangoli \( ABC \in ABD \).

$$[a) C(4; -1); b) D\left(-1; \frac{21}{4}\right); c) 12; d) P\left(\frac{5}{2}; \frac{7}{2}\right), P'\left(\frac{33}{4}; \frac{5}{8}\right)]$$

223

ESERCIZI

Capitolo 4

PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

# Punti e segmenti nel piano cartesiano

Prima di iniziare,
esercitati su laZ Esercizi

1 Considera i triangoli che hanno come vertici \(A(0;2)\) \(B(2;2)\) e un punto \(C\) che appartiene all'asse \(x\) . Stabilisci quanti sono i triangoli \(ABC\) con perimetro uguali a 8. [2]
LEGGI L GRAFICO ASSOCIA ciascun insieme di punti rappresentato in colore nel piano cartesiano alla condizione sulle coordinate che lo definisce.

![img-23.jpeg](img-23.jpeg)

![img-24.jpeg](img-24.jpeg)

![img-25.jpeg](img-25.jpeg)

![img-26.jpeg](img-26.jpeg)

1. $$\begin{cases} x^2 - 2 \le x \\ y^4 < 1 \end{cases}$$

2. $$\begin{cases} y^4 - y^2 \ge 12 \\ x^3 + x^2 + 3x + 3 \ge 0 \end{cases}$$

3. $$\begin{cases} |x| \le 3 \\ y^2 + 2y > 3 \end{cases}$$

4. $$\begin{cases} x^3 - x^2 - x \ge 2 \\ y^2 + 10 \le 7y \end{cases}$$

3 Considera il triangolo di vertici $$A(-1; 3)$$, $$B(2; 1)$$ e $$C(5; 5)$$.

a. Calcola l'area del triangolo \( ABC \).
b. Determinina le coordinate del punto medio \(M\) del lato \(BC\) e il rapporto fra l'area del triangolo \(ABM\) e l'area del triangolo \(ABC\).

[a) 9; b) $$M\left(\frac{7}{2}; 3\right), \frac{1}{2}$$

4 Dati i punti $$A(0; 2)$$, $$B(4; -1)$$ e $$C(4; 4)$$:

a. determinina il punto medio \(M\) del segmento \(AC\) e il punto \(D\) simmetrico di \(B\) rispetto a \(M\)
b. verifica che il quadrilatero \(ABCD\) è un rombo e calcola la sua area. [a] \(M(2;3),D(0;7)\) b) 20]

5 Un triangolo ha vertici $$A(-1; 1 - 4b)$$, $$B(3a - 1; 2)$$ e $$C(5; -2)$$, dove $$a$$ e $$b$$ sono parametri reali.

a. Determinina i valori di \(a\) e \(b\) in modo che il baricentro sua \(G(b + 1;a - 2)\)
b. Per i valori trovati calcola l'area del triangolo ACG.

[a) $$a = 1, b = 1$$; b) $$\frac{9}{2}$$

6 a. Dati i punti \(A(1;1)\) e \(B(5;7)\) , quanti sono i punti \(C\) , appartenentiagliassi,per cui il triangolo \(ABC\) e isoscele?
b. Determinina quanti sono i punti \(C\) se sappiamo che \(AB\) è la base. [a] 10; b) 2]

7 Per quali valori di $$a$$ il punto $$P(2a - 4; |a + 1|)$$ appartiene al quadrato che ha i lati paralleli agli assi cartesiani, un vertice in $$A(-2; 3)$$ e un altro vertice in $$A'$$ simmetrico di $$A$$ rispetto al punto $$(1; 0)$$? $$[1 \le a \le 2]$$

8 REALTÀ E MODELLI In un allenamento per una gara di dressage Sofia, con la sua cavalla Luna, deve effettuare il percorso in figura fermandosi nei punti indicati. In quei punti, durante la gara, dovrà far compiere a Luna delle «riprese», cioè delle serie di figure e movimenti come piroette o cambi di passo.

![img-27.jpeg](img-27.jpeg)

![img-28.jpeg](img-28.jpeg)

a. Qual è la lunghezza del percorso?
b. Prima di farlo a cavallo, Sofia prova il percorso a piedi, alla fermarsi e a una velocità costante, impiegando 2 minuti. Qual è la velocità tenuta da Sofia?

[a) circa 173 m; b) circa 1,4 m/s]

ESERCIZI

224

RETTE NEL PIANO CARTESIANO

Paragrafo 2

## 2 Rette nel piano cartesiano

1 attività interattiva

Teoria a pagina 196

### Dall'equazione al grafico

161 LEGGI IL GRAFICO ASSOCIA all'equazione di ogni retta il relativo grafico.

a. $-x - 2 = 0$

b. $y = -x - 2$

c. $y = -2$

d. $y - x - 2 = 0$

![img-29.jpeg](img-29.jpeg)

![img-30.jpeg](img-30.jpeg)

![img-31.jpeg](img-31.jpeg)

![img-32.jpeg](img-32.jpeg)

# I FONDAMENTALI

Prova tu foi un esercizio simile interattiva

### Disegnare una retta, data la sua equazione

Tracciamo le rette di equazioni:

a. $x = -3$;

b. $y = 4$;

c. $x + 4y - 4 = 0$.

a. $x = -3 \rightarrow$ tutti i punti hanno ascissa $-3$ (figura a).
b. $y = 4 \rightarrow$ tutti i punti hanno ordinata 4 (figura b).
c. Scriviamo l'equazione in forma esplicita: $y = -\frac{1}{4}x + 1$.
Troviamo alcuni punti della retta assegnando dei valori a piacere all'ascissa e calcolando l'ordinata.
Disegniamo i punti e tracciamo la retta (figura c).

Una retta di equazione:

- $x = h$ è parallela all'asse $y$;
- $y = k$ è parallela all'asse $x$.

Per rappresentare una retta non parallela ad alcun asse conviene scrivere la sua equazione in forma esplicita, così da calcolare più facilmente l'ordinata di un punto che le appartiene, partendo da un valore a piacere dell'ascissa.

![img-33.jpeg](img-33.jpeg)

![img-34.jpeg](img-34.jpeg)

![img-35.jpeg](img-35.jpeg)

### Rappresenta nel piano cartesiano le rette che hanno le seguenti equazioni.

162 $2x - 1 = 0$;

$y - 5 = 0$.

166 $y = -x + 4$;

$y = \frac{1}{4}x - 1$.

163 $2x - y = 0$;

$4y + 1 = 0$.

167 $x = 4$;

$x - y + 3 = 0$.

164 $y = -\frac{2}{3}x + 1$;

$x = \frac{5}{2}$.

168 $4x - 3 = 0$;

$2x + y - 1 = 0$.

165 $2x + 7 = 0$;

$4x - y + 4 = 0$.

169 $y - x + 1 = 0$;

$2x - 3y + 6 = 0$.

# 170 VERO O FALSO?

a. L'equazione $ax + 1 = 0$ rappresenta, per $a \neq 0$, l'equazione di una retta parallela all'asse $x$.
b. L'equazione $ax + by + c = 0$ rappresenta sempre, al variare di $a, b, c$, una retta del piano cartesiano.
c. $x = 2$ nel piano cartesiano rappresenta il punto $(2; 0)$ dell'asse $x$.
d. La retta $4x - 5y = 0$ passa per l'origine.

V F

V F

V F

V F

225

ESERCIZIO

Capitolo 4

PIANO CARTESIANO E RETTA

# Appartenenza di un punto a una retta

Stabilisci se le rette che hanno le seguenti equazioni passano per i punti indicati.

171 \(2x - 6y - 1 = 0,\) \(A\left(-\frac{1}{2};0\right),\) \(B\left(1;\frac{1}{6}\right),\) \(C(-1;0),\) \(D\left(10;\frac{3}{2}\right).\)
172 \(y = -x + 2,\) \(A(-5;3),\) \(B(10;4),\) \(C(-10;0),\) \(D(0; - 2).\)

GENERALIZZA CON PYTHON

Considerata una retta di equazione $y = mx + 2$, scrivi un programma che acquisisca in input i valori di $m$ e delle coordinate di un punto $P$, anche come frazioni, e, dopo aver detto se la retta passa per $P$, disegni il grafico con la retta e il punto.

173 Sulla retta di equazione \(2x + y - 3 = 0\) determina il punto \(A\) di ascissa \(-1\) e il punto \(B\) di ordinata 7.
Data la retta di equazione \(2x + y - 5 = 0\), stabilisci se i punti \(A(2;1)\) e \(B(1;1)\) appartengono aessa e determina l'ordinata del suo punto \(C\) di ascissa 1 e l'ascissa del suo punto \(D\) di ordinata 4. \(\left[C(1;3),D\left(\frac{1}{2};4\right)\right]\)
Determina per ciascuna delle rette di equazioni \(x - 4y + 7 = 0,2x + 6y - 7 = 0\) e \(2y - x - 4 = 0\) il relativo punto di ordinata \(-\frac{1}{2}\). \(\left[\left(-9; - \frac{1}{2}\right),\left(5; - \frac{1}{2}\right),\left(-5; - \frac{1}{2}\right)\right]\)
Un punto \(P\) della retta di equazione \(y = -3x + 4\) e distante \(4\sqrt{2}\) da \(Q(2;6)\). Trova le sue coordinate.

$\left[(-2; 10) \text{ o } \left(\frac{6}{5}; \frac{2}{5}\right)\right]$

# RISOLVI IN 2 PASSI

1 Se un punto \(P\) generico appartiene alla retta di equazione \(y = -3x + 4\), le sue coordinate sono \((x; -3x + 4)\).
2 Imponi che la distanza di \(P\) da \(Q\) sua \(4\sqrt{2}\) e risolvi l'equazione in \(x\) che ottieni.

17 Quali punti della bisettrice del primo e terzo quadrante distano \(\sqrt{13}\) da \(A(4; - 1)\)? [(1;1); (2;2)]
178 Considera la retta di equazione \(6x - y - 12 = 0\) e calcula l'area del triangolo che esta forma con gli assi cartesiani. [12]
179 Per quale valore di \(a\) il punto \(A(a - 2;1 - 3a)\) appartiene alla retta di equazione \(x - 2y = 3?\) \([a = 1]\)
170 Trova il valore di \(k\) affinché l'equazione \((k + 1)x - ky + 2 = 0\) sua l'equazione di una retta passante per il punto \(A(1; - 2)\) e disegna tale retta. \([k = -1]\)
Calcola il valore del parametro \(k\) affinché la retta di equazione \((2k - 1)x - (k + 1)y + k = 0\) passi per il punto \(A(0;3)\). Disegna tale retta dopo aver trovato i punti che ha in comune con l'asse \(x\) e con l'asse \(y\).

$\left[k = -\frac{3}{2}, \left(-\frac{3}{8}; 0\right), (0; 3)\right]$

182 SPIEGA PERCHÉ Dimostra che la distance tra due punti \(A(x_{A};y_{A})\) e \(B(x_{B};y_{B})\) appartenenti a una retta di equazione \(y = mx + q\) è independente da \(q\).
183 Trova, se esiste, per quale valore di \(k\) l'equazione lineare \((k^2 + k - 2)x + (k^2 - k)y + k^2 - 1 = 0\) in \(x, y\):

a. non rappresenta una retta;

c. rappresenta una retta passante per $P(1; 0)$.

b. rappresenta una retta parallela all'asse $y$;

$\left[a) k = 1; b) k = 0; c) k = -\frac{3}{2}\right]$

184 Trova, se esiste, il valore di $c$ tale che la retta di equazione $x + cy = 1$:

a. sia parallela all'asse $x$;

c. sia parallela all'asse $y$;

b. passi per $(3; 1)$;

d. passi per il punto dell'asse $y$ di ordinata $-\frac{1}{2}$.

$\left[a) \nexists c \in \mathbb{R}; b) c = -2; c) c = 0; d) c = -2\right]$

185 REALTÀ E MODELLI Un gruppo di studenti controlla il ritardo dell'orologio della propria aula confrontando per diversi giorni l'ora indicata dall'orologio con quella di un orologio satellitare. Gli studenti riescono a descrivere il ritardo accumulato $R$, in secondi, tramite l'equazione $R = \frac{3}{2} G + 9$, dove $G$ è il numero dei giorni trascorsi dall'inizio dell'esperimento. Rappresenta in un grafico l'equazione ricavata e determina il ritardo accumulato 30 giorni dopo la prima misurazione. [54 s]

![img-36.jpeg](img-36.jpeg)

ESERCIZI

226

RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Coefficiente angolare e ordinata all'origine

186 AL VOLO Determina, se esiste, il coefficiente angolare delle rette che hanno le seguenti equazioni.

a. $$y = \frac{x}{4} - 1$$

b. $$4x + 2y - 5 = 0$$

c. $$3y - 6 = 0$$

d. $$2x = 5$$

e. $$\frac{x + y}{4} = 0$$

f. $$7x = -14y$$

Per ognuna delle seguenti equazioni di rette indica, se esistono, il coefficiente angolare $$m$$ e il termine noto $$q$$ e poi rappresentale.

187 $$2 - 2x = 0; \quad y - x - 1 = 0.$$

188 $$y = -3x + 6; \quad 2x - y - 2 = 0.$$

189 VERO O FALSO?

a. L'equazione \( y = mx + q \) rappresenta tutte le rette del piano al variare di \( m \in q \).
b. L'equazione \(4y - x + 1 = 0\) non è l'espressione di una funzione di \(\mathbb{R}\) in \(\mathbb{R}\).
c. L'asse \(x\) non ha coefficiente angolare.
d. L'ordinata all'origine della retta \( y - 5 = \frac{1}{2} (x + 1) \) è \( \frac{11}{2} \).

V F
V F
V F
V F

# LEGGI IL GRAFICO

190 TEST Osservando la figura si deducono le seguenti affermazioni. Una sola è falsa. Quale?

![img-37.jpeg](img-37.jpeg)

A Le rette \(r,s\in t\) hanno I'ordinata all'origine positiva.
B I coefficienti angolari di \(r\in s\) sono discordi.
C Il coefficiente angolare di \(s\) è maggiore di quello di \(t\).
D Il coefficiente angolare della retta \(t\) è minore di quello di \(r\).

191 In ognuna delle seguenti figure evidenzia l'angolo tra retta e asse $$x$$, come definito nella teoria. Indica se il coefficiente angolare della retta è positivo, negativo, nullo o non definito.

![img-38.jpeg](img-38.jpeg)

192 Indica il segno di $$m$$ e $$q$$ per ognuna delle seguenti rette di equazione $$y = mx + q$$.

![img-39.jpeg](img-39.jpeg)

193 Determina per quali valori di $$a$$ la retta di equazione $$5y + (a^2 - 9)x + a = 0$$ forma con l'asse $$x$$ un angolo $$\alpha$$ acuto. Per quali valori di $$a$$ l'angolo $$\alpha$$ è di $$45^\circ$$? $$[-3 < a < 3, a = \pm 2]$$

# RISOLVI IN 3 PASSI

1 Scrivi l'equazione della retta in forma esplicita e determina il coefficiente angolare \( m \).
La retta deve formare un angolo acuto con l'asse \(x\), quindi poni \(m > 0\) e risolvi la disequazione in \(a\).
3 Verifica che, se \(\alpha = 45^{\circ}\) , alla il coefficiente angolare vale 1; poni \(m = 1\) e risolvi l'equazione.

227

ESERCIZI

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

194 Indica per quali valori di \(a\) la retta di equazione \(y = (2 - a)x + a - 3\) forma con l'asse \(x\) un angolo acuto. Se \(a = 2\), che angolo forma la retta con l'asse \(x\)? \([a < 2]\)
195 Determinina la condizione sul parametro \(a\) affinché la retta di equazione \(2ay + (a - 2)x - 1 = 0\) formi un angolo retto con l'asse \(x\). \([a = 0]\)
196 Considera la retta di equazione \( y = 2kx - 3k - 6 \) e indica per quali valori di \( k \) interseca l'asse \( y \) in un punto di ordinata negativa. \( [k > -2] \)
197 Trova i valori di \(k\) tali che la retta di equazione \(-3y + (3k - k^2)x + 5 = 0\) formi con l'asse \(x\) un angolo ottuso. \([k < 0 \vee k > 3]\)

Determina il coefficiente angolare delle rette passanti per O(0; 0) che formano con l'asse x gli angoli indicati.

198 30°; 45°; 60°. [√3/3; 1; √3] 199 120°; 135°; 150°. [-√3; -1; -√3/3]

# Grafici di funzioni definite a tratti

Rappresenta graficamente le seguenti funzioni.

![img-40.jpeg](img-40.jpeg)

200 y = {2x - 1 se x ≤ 0, -1 se 0 < x ≤ 4, -x + 6 se x > 4}

# COMPLETA LO SVOLGIMENTO

Il grafico della funzione è costituito da [ ] tratti.

Troviamo due punti che soddisfano l'equazione y = 2x - 1, con x [ ] 0, e disegniamo la semiretta.

Disegniamo il segmento per 0 < x ≤ 4, osservando che appartiene a una retta parallela all'asse [ ].

Rappresentiamo la semiretta di equazione y = -x + 6 usando punti con ascissa maggiore di [ ].

201 y = { -x + 7 se x ≤ 0, 7 se x > 0}

202 y = { -5x + 1 se x ≤ 1, 2x se x > 1}

203 y = { -1 se x < 2/3, 3x + 2 se x ≥ 2/3}

204 y = { 2x - 1 se x ≤ 1, -2x + 4 se x > 1}

205 y = { -x - 1 se x ≤ 0, -3 se 0 < x ≤ 3, x - 6 se x > 3}

206 y = { 2x + 1 se x ≤ -2, -x - 5 se -2 < x < 1, x - 6 se x ≥ 1}

# RISOLVI CON PYTHON

Scrivi un programma che disegni il grafico della funzione indicata.

207 y = x + |x - 2|

# RISOLVI IN 2 PASSI

1 Studia il segno dell'argomento del valore assoluto, ponendolo maggiore o uguale a 0.
2 Applicando la definizione di valore assoluto, scrivi la funzione data come funzione definita a tratti e rappresenta graficamente.

208 y = -|x|

209 y = |x| + 1

210 y = 2|x| + 1

211 y = |x - 4|

212 y = -|x - 2|

213 y = |x + 1| - 1

214 y = |2x + 3| - 3

215 y = |x + 3| + x + 3

216 y = |1/2 x - 2|

217 y = 2 - |x/3|

218 y = ||x| - 2|

219 y = |x - 2| + |1 - x|

220 y = 2√x² - x

221 y = |3 - x| + |x|

222 y = ||x| - 1| + 2

228

RETTE NEL PIANO CARTESIANO

Paragrafo 2

223 $$y = |x - 1| + |x - 2|$$

224 $$y = \sqrt{x^2 - 6x + 9} + |x| + 3$$

225 $$y = |2x + |x - 1| + 2|$$

226 $$y = \begin{cases} |x| - 1 & \text{se } x < 2 \\ -\frac{1}{2}x + 2 & \text{se } x \geq 2 \end{cases}$$

227 $$y = x + 2|x| - |1 - x|$$

228 $$y = \begin{cases} |x + 1| & \text{se } x \leq 0 \\ 2 - \left|\frac{1}{2}x - 1\right| & \text{se } x > 0 \end{cases}$$

Rappresenta graficamente le seguenti funzioni dopo averne determinato il dominio.

229 $$y = \frac{|x^2 + 2x|}{x + 2} - 3$$

RISOLVI IN 4 PASSI

1. Trova il dominio della funzione.

2. Studia il segno dell'argomento del valore assoluto, ponendolo maggiore o uguale a 0.

3. Applicando la definizione di valore assoluto, scrivi la funzione a tratti corrispondente a quella data.

4. Semplifica e rappresenta la funzione ottenuta, tenendo conto del dominio.

230 $$y = \frac{|x + 1|}{x + 1}$$

231 $$y = \frac{|2x|}{x} - 4$$

232 $$y = \frac{\sqrt{x^2}}{x} + |x - 2|$$

233 $$y = \frac{x^2 - 1}{|x - 1|}$$

234 $$y = \frac{x^2 - 2x - 3}{|x - 3|} + x$$

235 $$y = \frac{x^2}{|x|} - \frac{|x^2 - 2x|}{x - 2}$$

236 $$y = \frac{\sqrt{1 - 2x + x^2}}{x - 1} + 2$$

237 $$y = |x + 1| + \frac{|x - 2|}{2 - x}$$

238 $$y = \frac{|x + 1|}{x + 1} + |x - 2| + 2$$

239 $$y = \frac{x^2 - 3x + 2}{x - 1} + 1$$

240 $$y = \frac{x^2 - 7x + 6}{\sqrt{x^2 - 2x + 1}}$$

241 $$y = \frac{x^3 + 2x^2 - x - 2}{|x + 1|(x + 2)}$$

242 $$y = \frac{x^4 - 5x^2 + 4}{x^4 - 2x^2 - x + 2}$$

243 $$y = \frac{2x^3 + 5x + 3}{|x + 1|} - |x|$$

244 $$y = \frac{\sqrt{x^2 - 6x + 9}}{3 - x} + |x - 1| + 2$$

Traccia i grafici che rappresentano le soluzioni delle seguenti equazioni. Si tratta di funzioni?

245 $$|x| - x = 2$$

246 $$y + 2|y| = 3$$

247 $$|x| + |y| = 2$$

248 $$|x + 2| + |y - 2| - 4 = 0$$

249 $$2|x - 1| - 3|y + 2| = 5$$

250 $$|x + 4| - |y - 5| = 9$$

251 $$x = \frac{2y}{|y|} - 1$$

252 $$x = \sqrt{y^2 - 4y + 4} + y$$

253 Data la funzione $$f(x) = a|x - 3| + b$$, trova per quali valori di $$a$$ e $$b$$ il grafico di $$f(x)$$ passa per i punti $$(0; 2)$$ e $$(-2; 4)$$ e rappresentala nel piano cartesiano. $$[a = 1, b = -1]$$

254 Data la funzione $$f(x) = \frac{ax}{|3x|} - x + b$$, trova per quali valori di $$a$$ e $$b$$ il grafico della funzione $$f(x)$$ passa per i punti $$\left(5; -\frac{9}{2}\right)$$ e $$\left(-1; -\frac{5}{2}\right)$$ e rappresentala nel piano cartesiano. $$[a = 6, b = -\frac{3}{2}]$$

# Problemi

255 FISICA MOTO RETTILINEO Selene parte da casa per andare a trovare il suo amico Luca, che vive nella sua stessa via. La funzione che descrive la velocità di Selene (in m/s) al variare del tempo (in s) è:

![img-41.jpeg](img-41.jpeg)

$$v(t) = \begin{cases} 0,02t & \text{se } 0 \leq t \leq 60 \\ 1,2 & \text{se } 60 < t \leq 240 \\ -0,02t + 6 & \text{se } 240 < t \leq 300 \end{cases}$$

a. Qual è la velocità di Selene 30 s dopo la partenza?
b. C'è un'alto istante in cui la velocità di Selene è uguale a quella 30 s dopo la partenza? Se si, quale?
c. Rappresenta la velocità di Selene in un grafico velocità-tempo. [a) \(0,6\mathrm{m / s}\); b) \(4\mathrm{min}30\mathrm{s}\)

ESERCIZI

229

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCITI

256 CHIMICA Gli studenti Ada e Thomas riscaldano un campione di acido stearico fino alla temperatura di 90 °C e poi lo lasciano raffreddare. Osservano che l'andamento nel tempo t della temperatura y del campione può essere descritto dalla funzione

![img-42.jpeg](img-42.jpeg)

$$y = \begin{cases} -7t + 90 & \text{se } 0 \le t < 3,0 \\ t, & \text{se } 3,0 \le t < 11, \\ -5t + 124 & \text{se } t \ge 11 \end{cases}$$

con la temperatura y in °C e il tempo t in minuti. Durante l'intervallo $3,0 \le t < 11$ la temperatura è rimasta costante ($t_0$) perché è avvenuto il passaggio dallo stato liquido allo stato solido.

a. Calcola la temperatura di solidificazione \(t\), misurata dagli studenti.
b. Se gli studenti terminano l'esperienza nell'istante in cui il campione raggiunge la temperatura ambiente di \(24^{\circ}\mathrm{C}\) quantato è durato complessivamente il raffreddamento?
c. Rappresenta la curva di raffreddamento nel piano cartesian. [a) \(69^{\circ}\mathrm{C}\); b) 20 minuti]

# Dal grafico all'equazione

LEGGI IL GRAFICO Per ogni grafico scrivi l'equazione della retta relativa.

![img-43.jpeg](img-43.jpeg)

![img-44.jpeg](img-44.jpeg)

![img-45.jpeg](img-45.jpeg)

260 Trova l'equazione della retta che passa per il punto \(P(1; - 5)\) ed è parallela all'asse \(x\)
261 Traccia la retta parallela all'asse \(y\) passante per il punto \(A(-2;1)\) e scrivi la sua equazione.
262 Determinina le equazioni delle rette passanti per l'origine e per i seguenti punti:

a. \((-1;\frac{1}{2})\)
b. \((2; - 4)\)
c. (3;9).

263 Scrivi le equazioni:

a. delle rette passanti per il punto \(P(2; - 6)\) paralleleagliassi cartesiani;
b. della retta passante per \(P\) e per l'origine.

264 a. Disegna la retta passante per l'origine e per il punto $A\left(\frac{1}{4}; \frac{1}{3}\right)$.

b. Scrivi la sua equazione.
c. Verifica che la retta passa anche per i punti \(B(3;4),C(-6; - 8),D\left(1;\frac{4}{3}\right)\)

$$\left[y = \frac{4}{3}x\right]$$

265 LEGGI IL GRAFICO Scrivi le equazioni dei seguenti grafici.

![img-46.jpeg](img-46.jpeg)

![img-47.jpeg](img-47.jpeg)

![img-48.jpeg](img-48.jpeg)

230

RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Parti del piano e della retta e disequazioni in due variabili

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Rappresentare il semipiano definito da una disequazione

Rappresentiamo il semipiano definito dalla disequazione $6x + 3y - 2 \geq 0$.

# 1 Primo metodo

![img-49.jpeg](img-49.jpeg)

Esplicitiamo rispetto a $y$: $6x + 3y - 2 \geq 0 \rightarrow y \geq -2x + \frac{2}{3}$.

Disegniamo la retta $r$ di equazione $y = -2x + \frac{2}{3}$.

Le soluzioni della disequazione sono rappresentate da tutti i punti del semipiano che hanno l'ordinata maggiore o uguale all'ordinata del punto che ha la stessa ascissa e si trova sulla retta.

# 2 Secondo metodo

Per evitare di esplicitare la disequazione rispetto a $y$, si può procedere mediante un punto di prova. Per comodità consideriamo come punto

di prova l'origine $O$. Sostituiamo le sue coordinate nella disequazione.

Otteniamo $-2 \geq 0$, che è falso, quindi $O$ non appartiene al semipiano cercato, che è allora quello opposto al semipiano a cui appartiene $O$.

Per usare il punto di prova, scegliamo un punto che non appartiene alla retta e sostituiamo le sue coordinate nella disequazione.

Se la disequazione è verificata, il semipiano a cui appartiene il punto è quello cercato, altrimenti è quello opposto.

# Rappresenta nel piano cartesiano l'insieme delle soluzioni delle seguenti disequazioni.

266 $y \leq 4$

267 $y \leq 6$

268 $y > x + 4$

269 $x < y$

270 $x \geq -3$

271 $y \geq 2x$

272 $y + x + 5 \geq 0$

273 $y - x - 1 > 0$

274 $x + y > 2$

275 $2y + x \geq 4$

276 $2x + 3 \geq 0$

277 $x + 6 > 0$

278 $x < y + 8$

279 $y \geq 2|x|$

280 $y \leq |x + 1|$

# Semirette e segmenti

Rappresenta nel piano cartesiano la semiretta o il segmento definiti da ciascuno dei seguenti sistemi.

281 $\begin{cases} y = 2x - 1 \\ x \leq 2 \end{cases}$

282 $\begin{cases} y + 1 = 0 \\ x \geq \frac{1}{3} \end{cases}$

283 $\begin{cases} x = 3 - y \\ 0 \leq x < 4 \end{cases}$

284 $\begin{cases} 4x + 2y - 1 = 0 \\ -\frac{1}{2} < x \leq 4 \end{cases}$

# Altre regioni del piano

Rappresenta nel piano cartesiano l'insieme delle soluzioni dei seguenti sistemi di disequazioni.

285 $\begin{cases} y \geq -x - 1 \\ x - 2y + 2 \geq 0 \end{cases}$

# RISOLVI IN 2 PASSI

1 Rappresenta ciascuno dei due semipiani. Puoi farlo applicando il metod del punto di prova.
2 Le soluzioni del systeme sono rappresentate dall'intersezione dei due semipiani.

ESERCIZIO

231

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

286 $$\left\{ \begin{array}{l} y \geq 2 \\ y \leq x + 6 \end{array} \right.$$

287 $$\left\{ \begin{array}{l} y \leq 3x \\ y \geq x \end{array} \right.$$

288 $$\left\{ \begin{array}{l} y - x - 1 \leq 0 \\ x < 0 \\ y + 3 \geq 0 \end{array} \right.$$

289 $$\left\{ \begin{array}{l} 2y + 3x - 4 \leq 0 \\ 3y - 4x + 3 \geq 0 \end{array} \right.$$

290 $$\left\{ \begin{array}{l} x > \frac{3}{4} y - 3 \\ x \leq 2 - 2y \end{array} \right.$$

291 $$\left\{ \begin{array}{l} y \geq |x| \\ y \leq 4 \end{array} \right.$$

292 $$\left\{ \begin{array}{l} |x| < 2 \\ |x + y| < 2 \end{array} \right.$$

293 $$\left\{ \begin{array}{l} 2x - 3y + 6 \geq 0 \\ 9y + 4x - 36 \leq 0 \\ y > 1 \end{array} \right.$$

294 $$\left\{ \begin{array}{l} |y - 2x| \leq 1 \\ |y + x| < 1 \end{array} \right.$$

# FAI IL PUNTO SULLE COMPETENZE

# Rette nel piano cartesiano

Prima di iniziare, esercitati su laZ Esercizi

1 VERO O FALSO? Considera la retta di equazione $$kx + (1 - k)y - 3 = 0$$, con $$k \in \mathbb{R}$$.

a. Per \(k = 0\) l'equazione non rappresenta una funzione.
b. La retta ha coefficiente angolare negativo se \(0 < k < 1\)
c. Esiste un valore di \(k\) per cui la retta passa per l'origine.
d. Esiste un valore di \(k\) per cui i punti \((1;0)\) e \((-1; - 3)\) appartengono entrambi alla retta.
e. Per \(k = 1\) la retta giace solo nel II e nel III quadrante.

V F

V F

V F

V F

V F

2 Determina il dominio delle funzioni seguenti e rappresentate graficamente.

a. $$y = \frac{\sqrt{4x^2 - 4x + 1}}{|1 - 2x|} + x$$

b. $$y = \frac{|x - 3|}{3 - x} \cdot 2x - 4$$

[a) $$x \neq \frac{1}{2}$$; b) $$x \neq 3$$]

3 Determina, se esistono, i valori del parametro $$k$$ per cui la retta di equazione $$x + (k - 3)y + k = 0$$:

a. interseca l'asse \(y\) in un punto di ordinata positiva;
b. forma con il semiasse positivo delle ascisse un angolo ottuso;
c. non interseca l'asse \(y\)
d. passa per l'origine.

[a) $$0 < k < 3$$; b) $$k > 3$$; c) $$k = 3$$; d) $$k = 0$$]

4 Dati la retta di equazione $$4x - 2y + 1 = 0$$ e il punto $$C\left(1; \frac{1}{2}\right)$$, determina, se possibile, le coordinate dei punti $$A$$ e $$B$$ in modo che il triangolo $$ABC$$ sia isoscele, con la base $$AB$$ che giace sulla retta e i lati obliqui lunghi $$2\sqrt{2}$$.

$$\left[ \left(-1; -\frac{3}{2}\right), \left(\frac{7}{5}; \frac{33}{10}\right) \right]$$

5 REALTÀ E MODELLI Cristina sta riempendo la sua vasca da bagno, che ha una capacità di 200 L, quando riceve una telefonata. Chiude il rubinetto e lo riapre alla fine dei 25 minuti di telefonata, per richiuderlo poi quando c'è la giusta quantità d'acqua. Fatto il bagno toglie il tappo e lascia che la vasca si svuoti. La funzione della quantità di acqua $$y$$, in L, nella vasca al variare del tempo $$t$$, in minuti, dalla fine della telefonata è:

![img-50.jpeg](img-50.jpeg)

$$y = \begin{cases} 50 + 7t & \text{se } 0 \leq t < 10 \\ 120 & \text{se } 10 \leq t < 30. \\ -10t + 420 & \text{se } 30 \leq t \leq 42 \end{cases}$$

a. Rappresenta la funzione.
b. In che percentuale è piena la vasca all'arrivo della Telefonata?
c. Se Cristina avesse lasciato il rubinetto aperto durante la Telefonata, la vasca avrebbe potuto contentere tutte l'acqua? Supponi che la velocità di riempimento della vasca sia costante. [b] \(25\%\) c) no

6 TEST La retta $$r$$ forma con il semiasse positivo delle ascisse un angolo di $$150^{\circ}$$ e passa per il punto $$P$$, in cui la retta di equazione $$3x - 4y + 8 = 0$$ interseca l'asse $$y$$. Quale delle seguenti affermazioni è falsa?

A La retta $$r$$ ha coefficiente angolare negativo.

C La retta $$r$$ passa per il punto $$(-1; 0)$$.

B L'ordinata di $$r$$ all'origine è 2.

D La retta $$r$$ giace in tre quadranti.

232

POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

7 Rappresenta nel piano cartesiano l'insieme delle soluzioni del sistema di disequazioni:

$$\left\{ \begin{array}{l} 2x - y + 4 \geq 0 \\ 2x + y - 4 \leq 0. \\ y \geq |x| - 2 \end{array} \right.$$

Calcola l'area della regione di piano rappresentata.

[12]

8 Rappresenta graficamente la spezzata definita dal sistema $$\left\{ \begin{array}{l} y = ||x + 1| - 3 \\ |x + 1| \leq 6 \end{array} \right.$$ e determina la sua lunghezza. [12√2]

### 3 Posizione reciproca di due rette

Stabilisci la posizione reciproca delle seguenti coppie di rette.

295 $$2x + y - 5 = 0, \quad x - 3y - 6 = 0.$$

RISOLVI IN 2 PASSI

1 Poni aSYSTEMA le due equazioni. Il systema\
può essere determinato con una sola soluzione \((x,y)\) ,impossible o indeterminato.Le rette sono,rispettivamente,incidenti nel punto \((x,y)\) ,parallele e distinte o coincidenti.
2 Verifica che il systema è determinato e conferma il risultato nel piano cartesian.

296 \(2x + y + 3 = 0\) \(3x - y + 2 = 0.\)
297 \(4x - 3y - 2 = 0,\) \(-8x + 6y - 1 = 0.\)
298 \(x + 3y - 4 = 0,\) \(2x + 6y - 8 = 0.\)
299 \(-x + y - 6 = 0,\) \(x + y - 6 = 0.\)
300 \(y = 3x - 6,\) \(y = 2x - 5.\)

# Rette incidenti

Teoria a pagina 200

301 COMPLETA Date le rette di equazioni $$3x - 6h = 0$$ e $$2y - x + k = 0$$, il loro punto di intersezione coincide con:

$$A(2; -1) \text{ se } h = \_\_\_\_\_ \text{ e } k = \_\_\_\_\_;$$

$$B(-3; -2) \text{ se } h = \_\_\_\_\_ \text{ e } k = \_\_\_\_\_.$$

302 Trova la misura del segmento che le rette di equazioni \( y = x - 6 \) e \( y = -x + 5 \) staccano sull'asse delle \( x \). [1]
303 La retta di equazione

$$4x + 3y - 12 = 0$$

interseca gli assi cartesiani in due punti A e B. Calcola area e perimetro del triangolo AOB.

[6; 12]

304 Le rette \(r\) e s, rispettivamente di equazioni \(y = 2x + 3\) e \(y = 2x - 1\), staccano sulla retta \(t\) di equazione \(2x - 3y + 9 = 0\) un segmento \(AB\). Calcola la misura di \(AB\). [V13]
305 Stabilisci per quale valore di \(a\) le rette di equazioni \(x - y + a = 0\) e \(x - 3y = 0\) si intersecano in un punto di ascissa 3. [-2]

306 Determina le coordinate dei vertici A, B, C del triangolo i cui lati appartengono alle rette di equazioni $$2x - 6 = 0, y = 2$$ e $$y = -2x + 10$$. Calcola l'area e il perimetro del triangolo.

$$[A(3; 4), B(3; 2), C(4; 2); 1; 3 + \sqrt{5}]$$

307 Determinina il valore del parametro \(k\) per cui il punto di intersezione delle rette di equazioni \(3x + y + 4 = 0\) e \(x - 2y + 6 = 0\) appartiene alla retta di equazione \(y = (3 - k)x + 6\). [1]
308 Trova per quale valore di \(k\) le rette di equazioni \((k - 1)x + 2ky + 6 = 0\) e \(x - y + 2 = 0\) si intersecano sull'asse \(x\). [4]
309 Trova le intersezioni tra le rette di equazioni

$$2x - (k - 3)y + 8k - 2 = 0$$

e

$$x + (k + 1)y + k = 0,$$

al variare di k.

$$\left[ k = \frac{1}{3} : \text{rette coincidenti}; k \neq \frac{1}{3} : (-3k - 2; 2) \right]$$

233

ESERCIZI

Capitolo 4

PIANO CARTESIANO E RETTA

# MATEMATICA PER L'EDUCAZIONE CIVICA

# Prezzo di equilibrio

# EDUCAZIONE FINANZIARIA

In economia, la funzione della domanda rappresenta la quantità di un certo bene richiesta dai consumatori in funzione del suo prezzo, mentre la funzione dell'offerta rappresenta la quantità di bene immessa sul mercato. La funzione della domanda è decrescente: se aumenta il prezzo, i consumatori sono meno propensi all'acquisto. La funzione dell'offerta è invece crescente: all'aumentare del prezzo i produttori sono più propensi a immettere sul mercato una maggiore quantità di bene. Il prezzo di equilibrio è quello in cui le due funzioni hanno lo stesso valore.

ESEMPIO L'offerta e la domanda di legna da ardere sono descritte rispettivamente dalle equazioni $q = 2p - 10$ e $q = -\frac{3}{2}p + 32$, dove $q$ è la quantità di legna, in quintali, e $p$ è il prezzo, in €/quintale. Troviamo il prezzo di equilibrio. Rappresentiamo le due funzioni in un piano cartesiano $Opq$. Risolviamo il sistema delle loro equazioni.

$$\begin{cases} q = 2p - 10 \\ q = -\frac{3}{2}p + 32 \end{cases} \rightarrow \begin{cases} q = 2p - 10 \\ 7p = 84 \end{cases} \rightarrow \begin{cases} q = 14 \\ p = 12 \end{cases}$$

$p = 12$ €/quintale è il prezzo di equilibrio.

In corrispondenza del prezzo di equilibrio, la quantità offerta e la quantità domandata sono uguali entrambe a 14 quintali.

# ESERCIZIO

1 Trova il prezzo di equilibrio per il parcheggio di un'automobile per 24 ore in una città di mare, sapendo che l'offerta e la domanda sono descritte rispettivamente dalle equazioni $p - q = 6$ e $2q + 3p = 38$, dove $q$ è il numero complessivo di soste di 24 ore in un mese (in migliaia) e $p$ è il prezzo in euro di una singola sosta per giornata. [10 €/giorno]

![img-51.jpeg](img-51.jpeg)

![img-52.jpeg](img-52.jpeg)

# Interpreta graficamente le seguenti equazioni e risolvile algebricamente.

$$\boxed{310} \quad |x - 1| = 2|x| - 1$$

$$\left[ -2; \frac{2}{3} \right]$$

# RISOLVI IN 3 PASSI

1 Indica con $f(x)$ il primo membro e con $g(x)$ il secondo membro dell'equazione e rappresenta nello stesso sistema di assi cartesiani le funzioni $y = f(x)$ e $y = g(x)$ ottenute; ciascun grafico è l'unione di due semirette.
2 Osserva i punti di intersezione $A$ e $B$ dei due grafici. Le ascisse di $A$ e $B$ sono le soluzioni dell'equazione.
3 Poni a sistema le equazioni delle opportune semirette e risolvi algebricamente il sistema.

$$\boxed{311} \quad |x + 1| = -\frac{x}{2}$$

$$\left[ -2; -\frac{2}{3} \right]$$

$$\boxed{313} \quad |x| - 1 = -|x - 3|$$

[impossibile]

$$\boxed{312} \quad -\frac{|x|}{2} + 2 = |x + 2|$$

$$\left[ -\frac{8}{3}; 0 \right]$$

$$\boxed{314} \quad |1 - x| + 1 = \frac{|x + 1|}{2}$$

[1]

# Interpreta graficamente le seguenti disequazioni e risolvile algebricamente.

$$\boxed{315} \quad |x - 2| > |x| + 1$$

$$\left[ x < \frac{1}{2} \right]$$

$$\boxed{317} \quad \frac{2}{3}|x| - 1 \leq |x - 4|$$

$$[x \leq 3 \lor x \geq 9]$$

$$\boxed{316} \quad |x| - 1 \leq -|x + 2| + 3$$

$$[-3 \leq x \leq 1]$$

$$\boxed{318} \quad |x - 4| + 5 > \frac{|x + 5|}{3}$$

$$[\forall x \in \mathbb{R}]$$

ESERCIZIO

234

POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

R

# Problemi

EDUCAZIONE FINANZIARIA PROBLEMI DI SCELTA

![img-53.jpeg](img-53.jpeg)

319 LEGGI IL GRAFICO Una palestra aperta tutti i giorni, comprese le domeniche, propone tre tipi di tariffa mensile:

proposta 1: una quota fissa più 1,30 € per agli ingresso;
proposta 2:4,50 € per agli ingresso;
proposta 3: una quota fissa mensile.

Nella figura sono rappresentate le funzioni del costo delle tre proposte.

Associa a ogni proposta la retta che la rappresenta e determina le quote fisse della proposta 1 e della proposta 3. Quale proposta è la più conveniente per una persona che pensa di andare in palestra tre volte a settimana? [proposta 1]

320 A una tecnica specializzata nella riparazione e manutenzione di caldaie da riscaldamento domestico vengono offerte tre alternative di retribuzione.

![img-54.jpeg](img-54.jpeg)

A: stipendio fisso mensile di 1200 €.
B: 65 € per agli caldaia riparata.
C: fisso mensile di \(800\in +25\in\) per agli caldaia riparata.

Quale delle tre alternative risulta più conveniente per la tecnica, al variare del numero di caldaie riparate?

[A per 0 ≤ x < 16; C per 16 < x < 20; B per x > 20]

![img-55.jpeg](img-55.jpeg)

321 Una ditta di trasporti propone a un'azienda agricola le seguenti condizioni di spesa per il trasporto della verdura.

A: 9 € al quintale.
B: 6 € al quintale più una spesa fissa di 300 €.
C: 12 € al quintale fino a 40 quintali e 6,60 € per agli quintale eccedente.

Per quali quantità è più conveniente ciascuna delle condizioni?

[A per 0 < x < 90; C per 90 < x < 140; B per x > 140]

322 Corrado compra online capsule per il caffè servendosi di due aziende, SiCaffè e BuonCaffè, che nei loro siti vendono entrambe confezioni da 10 capsule a 3,60 € a confezione, offrendo sconti differenti in base alla quantità delle confezioni acquistate:

![img-56.jpeg](img-56.jpeg)

SiCaffé offre uno sconto di 0,20 € per agli confezione se si acquistano più di 36 confezioni;
BuonCaffé offre uno sconto se si acquistano più di 48 confezioni e lo sconto è di 0,50 € su agli confezione in più.
a. Quante confezioni di capsule ha acquistato Corrado quello mese se, per convenienza, ha scelto BuonCaffé?
b. Se Corrado ha valutato che era indifferente acquistare da una o dall'altra azienda, quante confezioni di capsule potrebbe aver ordinato? [a] da 37 a 79 confezioni; b) da 0 a 36 o 80 confezioni]

323 Un gruppo fotografico di Torino sta organizzando un'uscita per andare a vedere una mostra a Milano. I soci del gruppo sono 30, ma non si sa quanti parteciperanno.

Il biglietto di ingresso alla mostra costa 20 € a persona per gruppi di 10 o più persone, altrimenti costa 25 €. Inoltre, bisogna valutare quale mezzo di trasporto usare. Le possibilità sono:

treno: \(25\in\) a persona;
noleggio di un pullman: 300 € fissi e 10 € a persona, fino a 30 persone.

Valutando tutte le combinazioni possibili, quale opzione è la più conveniente in base al numero di persone?

[meno di 20 persone: treno; più di 20 persone: pullman; 20 persone: indifferente]

235

ESERCIZI

Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

324

EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA A un autotrasportatore vengono proposte due offerte di guadagno per il trasporto di una certa merce:

A: 115 € fissi più 0,25 € per agli quintale di merce trasportata;
B: 58 € fissi più 1,20 € per agli quintale di merce trasportata.

Sapendo che il massimo carico trasportabile è pari a 10 t, quale offerta è più conveniente per l'autotrasportatore in relazione alla quantità trasportata? [A per 0 q ≤ x < 60 q; B per 60 q < x ≤ 100 q]

325

EDUCAZIONE FINANZIARIA COSTO E RICAVO Per la vendita di hamburger in strada, Marco e Michela devono pagare una rata mensile di 300 € e 900 € all'anno per la licenza.

![img-57.jpeg](img-57.jpeg)

Hanno valutato che il costo medio di 100 hamburger è di 200 € e il prezzo medio di vendita di un panino è di 5 €.

Considera come orizzonte temporale un anno. Scrivi e rappresenta graficamente la funzione del costo complessivo e la funzione del ricavo.

Se Marco e Michela non vogliono andare in perdita, quanti hamburger devono vendere come minimo in un anno? [1500]

326

FISICA MOTO RETTILINEO Elena e Filippo abitano agli estremi opposti di una strada rettilinea e si muovono da casa per incontrarsi. La funzione che esprime la distanza s_F (in metri) percorsa da Elena rispetto al tempo t (in minuti) è s_F(t) = 50 · t; Filippo parte 2 minuti dopo e la funzione che esprime la sua distanza dalla casa di Elena rispetto al tempo è:

$$s_F(t) = \begin{cases} 700 & \text{se } 0 \le t \le 2 \\ 900 - 100 \cdot t & \text{se } t > 2 \end{cases}$$

a. Rappresenta graficamente le due funzioni. (Suggerimento. Per l'asse delle ordinate considera come unità di misura \(100\mathrm{m}\).)
b. Dopo quanto tempo si incontrano? [b) 6,0 min]

327

FISICA MOTO NEL PIANO Due corpi puntiformi si muovono in un piano con le seguenti leggi orarie:

A: $$\begin{cases} x(t) = 2t \\ y(t) = 4t + 1 \end{cases}$$, B: $$\begin{cases} x(t) = 3t + 1 \\ y(t) = 9t \end{cases}$$, con x e y in metri, t in secondi, t ≥ 0.

Ricava le traiettorie dei due corpi, rappresentate in un riferimento Oxy e determina il punto in cui le traiettorie si intersecano. Nel loro moto, i due corpi si incontrano? [(4; 9); no]

328

FISICA GRAFICO SPAZIO-TEMPO Nella figura sono rappresentati i grafici spazio-tempo per le leggi orarie del moto di due escursionisti.

![img-58.jpeg](img-58.jpeg)

a. Dopo i primi 20 minuti, chi ha percorso la distanza maggiore?
b. In che intervallo di tempo l'escursionista \(B\) è «in testa»?
c. In che istanti di tempo avvengono i sorpassi?
d. Scrivi le equazioni delle leggi orarie che descrivono i moti degli escursionisti \(A\) e \(B\).

# Rette parallele e rette perpendicolari

Teoria alle pagine 201 e 202

2 attività interattive

Determina il coefficiente angolare delle rette di ciascuno dei seguenti gruppi e stabilisci quali sono parallele e quali perpendicolari.

329

$$y = -3x + 1,$$

$$y + 3x - 2 = 0,$$

$$6y = -2x + 1,$$

$$3y - x - 5 = 0.$$

330

$$2y - 5x - 2 = 0,$$

$$y = -\frac{2}{5}x,$$

$$y = -\frac{2}{5}x - \frac{2}{5},$$

$$y = \frac{5}{2}.$$

331

$$3x - 2y + 1 = 0,$$

$$-6x + 4y + 7 = 0,$$

$$y = \frac{2}{3}x + 1,$$

$$-6x - 9y = 0.$$

236

POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

332 FAI UN ESEMPIO Per ciascuna delle seguenti rette, scrivi le equazioni di due rette parallele e di due perpendicolari:

a. $3y - 2 = 0$;

b. $3x - 5 = 0$;

c. $2x - 4y + 1 = 0$.

333 Dato il punto $A(4; -6)$, disegna le rette parallele agli assi passanti per $A$ e scrivi le loro equazioni.

334 TEST L'equazione della retta $r$ è $5x + y - 6 = 0$. Il coefficiente angolare di una retta perpendicolare a $r$ è:

A 5.

B -5.

C $\frac{1}{5}$.

D $-\frac{1}{5}$.

335 ASSOCIA a ciascuna retta $t$, nella prima riga, la retta $r$, nella seconda riga, parallela a $t$.

a. $3x - y + 1 = 0$

b. $x - 3y + 6 = 0$

c. $3x + y - 1 = 0$

d. $x = -3y$

1. $6y - 2x = 9$

2. $y + 1 = 3x$

3. $x + 3y - 6 = 0$

4. $y = -3x + 2$

336 ASSOCIA a ciascuna retta $r$, nella prima riga, la retta $s$, nella seconda riga, perpendicolare a $r$.

a. $5x + 2y - 6 = 0$

b. $5x - 2y = 5$

c. $2x + 5y - 3 = 0$

d. $y = 5x - 1$

1. $2x + 5y - 2 = 0$

2. $5y - 2x = 0$

3. $2y = 5x + 3$

4. $5y = 1 - x$

337 COMPLETA

a. La retta di equazione \( x + 2y + 1 = 0 \) è parallela alla retta di equazione \( x + 6y + 5 = 0 \).
b. La retta di equazione \( x = 3 \) è parallela all'asse
c. \(y = -\frac{3}{2} x + 2\) e l'equazione di una retta perpendiculara alla retta di equazione \(x + 9y - 1 = 0\)
d. Le rette di equazioni \(x + 10y + 7 = 0\) e \(3x - 5y - 15 = 0\) sono parallele.

Per ogni retta scrivi l'equazione di una retta parallela a essa e l'equazione di una retta perpendicolare a essa.

338 $y = -\frac{1}{3}x + 5$;

$y = 2x + \frac{1}{4}$;

$y = 2$;

$y = \frac{1}{5}x$.

339 $4x - 2y + 1 = 0$;

$3x + 1 = 0$;

$7x + y + 3 = 0$;

$x = -3$.

# OLTRE I FONDAMENTALI

# Studiare rette parallele e perpendicolari con parametri

Determiniamo per quali valori di $k$ le rette di equazioni $x - ky + 1 = 0$ e $(k - 1)x - 2ky - 5 = 0$ sono parallele e per quali valori di $k$ sono perpendicolari.

1 Scriviamo la condizione di parallelismo più opportuna da applicare.

Individuiamo i coefficienti $a, b, a_1, b_1$ delle rette:

$$\frac{1}{a} \cdot \frac{x - ky}{b} + 1 = 0 \quad \text{e} \quad \frac{(k - 1)x - 2ky - 5}{b_1} - 5 = 0.$$

La condizione di parallelismo da applicare è $ab_1 - a_1b = 0$, perché permette di trovare anche le rette parallele all'asse $y$, che sono invece escluse se consideriamo la condizione $m = m_1$.

Imponiamo che le rette siano parallele con la condizione di parallelismo $ab_1 - a_1b = 0$.

Deve essere:

$$\frac{1}{a} \cdot \frac{(-2k)}{b_1} - \frac{(k - 1)}{a_1} \cdot \frac{(-k)}{b} = 0 \rightarrow -2k + k(k - 1) = 0 \rightarrow k(-2 + k - 1) = 0 \rightarrow k = 0 \lor k = 3.$$

Per $k = 0$ le rette hanno equazioni $x + 1 = 0$ e $x + 5 = 0$.

Per $k = 3$ le rette hanno equazioni $x - 3y + 1 = 0$ e $2x - 6y - 5 = 0$.

Osserviamo che abbiamo ottenuto anche le rette parallele all'asse $y$.

2 Scriviamo e applichiamo la condizione di perpendicolarità.

Le rette sono perpendicolari se $aa_1 + bb_1 = 0$.

$$\frac{1}{a} \cdot \frac{(k - 1)}{a_1} + \frac{(-k)}{b} \cdot \frac{(-2k)}{b_1} = 0 \rightarrow k - 1 + 2k^2 = 0 \rightarrow 2k^3 + k - 1 = 0 \rightarrow k = -1 \lor k = \frac{1}{2}.$$

Per $k = -1$ le rette hanno equazioni $x + y + 1 = 0$ e $-2x + 2y - 5 = 0$.

Per $k = \frac{1}{2}$ le rette hanno equazioni $x - \frac{1}{2}y + 1 = 0$ e $-\frac{1}{2}x - y - 5 = 0$.

ESERCIZI

237

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

340 Stabilisci per quale valore di \(a\) le due rette \(-x + 2y - 1 = 0\) e \(ax + (a - 1)y = 1\) risultano parallele. [1]
341 Trova per quali valori di \(a\) le due rette \(ax - 2y - 3 = 0\) e \((2a + 3)x + y - 1 = 0\) sono perpendiculari. \([-2\circ \frac{1}{2} ]\)
342 Stabilisci per quale valore di \(a\) le due rette \(4x + (a - 1)y = 0\) e \(2ax + 2(a - 1)y + 1 = 0\) risultano:

a. parallele;

b. perpendicolari.

[a) a = 1 ∨ a = 4; b) a = -1]

VERIFICA CON PYTHON

Scrivi un programma che, acquisito in input un valore di a, verifichi se le rette sono parallele, perpendicolari o incidenti ma non perpendicolari.

343 Determinina per quale valore di \(a\) le due rette di equazioni \(2x + 4y - 3 = 0\) e \((2 - a)x + (a + 1)y + 1 = 0\) risultano perpendicolari. \([a = -4]\)
344 Determinina per quale valore di \(k\) la retta di equazione \((k + 2)x + (k + 3)y - 1 = 0\) risulta:

a. parallela all'asse \(x\)
b. parallela all'asse \(y\)

c. parallela alla retta di equazione \(x - 2y = 0\)
d. perpendicularare alla retta di equazione \(4x - 2y + 1 = 0\)

[a) k = -2; b) k = -3; c) k = -7/3; d) k = -1]

345 Determina per quale valore di a la retta di equazione (a + 1)x + (2a - 3)y + 2a = 0 risulta:

a. parallela alla retta \(3x - 1 = 0\)
b. parallela alla retta \(2y + 5 = 0\)
c. perpendicularare alla retta \(9x - 3y + 1 = 0\)
d. parallela alla retta \(y = -x + 2\)

[a) a = 3/2; b) a = -1; c) a = -6; d) a = 4]

346 Calcola a in modo che la retta di equazione

(a + 3) x + y - 2 = 0, con a ∈ ℝ:

a. sia parallela all'asse \(x\)
b. sia parallela all'asse \(y\)
c. intersechi la retta \(y + x - 1 = 0\) in un punto del primo quadrante;
d. formi con gli assi cartesiani un triangolo di area \(\frac{1}{4}\)

[a) a = -3; b) ∉ a ∈ ℝ; c) a > -1;

d) a = -11 ∨ a = 5]

Discuti al variare di a la posizione reciproca delle rette r e s.

347 \(r:2ax + 2y - 3 = 0\) （20 \(s:(a - 2)y - x + 2 = 0.\) （20 \([a = 1:r / s;a\neq 1:r\in s\) incidenti]
348 \(r:(a^2 -a)x - y + a^2 = 0\) （20 \(s:(2a - 2)x - y + 1 = 0.\) （20 \([a = 1:r\equiv s;a = 2:r / s;a\neq 1\wedge a\neq 2:r\in s\) incidenti]

# 4 Determinare l'equazione di una retta

Equazione di una retta passante per un punto e di coefficiente angolare noto

Teoria a pagina 203

1 attività interattiva

349 VERO O FALSO?

a. L'asse \(y\) non ha coefficiente angolare. [V] F
b. L'equazione \( y - 1 = m(x - 2) \) rappresenta tutte le rette passanti per il punto \( P(2;1) \). [V] F
c. Tutte le rette di equazione \(y - 1 = m(x - 2)\) passano per il punto \(P(2;1)\). [V] F
d. L'equazione \( y = mx - m \) rappresenta tutte le rette passanti per \( P(1;0) \), esclusa la retta \( x = 1 \). [V] F

350 Scrivi l'equazione della retta passante per il punto P(2; -5) e di coefficiente angolare m = -3.

COMPLETA LO SVOLGIMENTO

Sostituendo nella formula a lato, abbiamo:

y = (x - 2) → y = -3x + 1.

Retta passante per A(x₁; y₁)

e di coefficiente angolare m:

y - y₁ = m(x - x₁).

238

DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

Scrivi l'equazione della retta passante per A e di coefficiente angolare m e rappresentala.

351 A(-1; 2), m = -1.

352 A(3; -1/2), m = 3.

353 A(-2; -3), m = 1/2.

357 LEGGI IL GRAFICO Scrivi le equazioni delle due rette rappresentate in figura e trova le coordinate del punto in cui si intersecano.

![img-59.jpeg](img-59.jpeg)

358 Scrivi l'equazione della retta passante per l'origine e di coefficiente angolare -2 e rappresentala. Trova i punti della retta che hanno distanza 3√5 dall'origine. [(3; -6), (-3; 6)]

354 A(0; -2), m = -5.

355 A(4/3; 5/2), m = -3/2.

356 A(3; 0), m = 4.

359 Scrivi l'equazione della retta che passa per il punto P(0; 5) e ha coefficiente angolare uguale a quello della retta di equazione 2x - 3y + 1 = 0.

[y = 2/3 x + 5]

360 Trova l'equazione della retta r che forma con l'asse x un angolo di 45° e passa per il punto P di ascissa 2 appartenente alla bisettrice del secondo e quarto quadrante. [y = x - 4]

361 TEST La retta r passante per il punto P(1; 1) forma con la retta s di equazione y + 3 = 0 un angolo di 45°. Quale tra le seguenti è l'equazione della retta r?

A \(y = x + 1\)
B \(x = y\)
C \(x = y + 1\)
D \(y = -x\)

# Coefficiente angolare, note le coordinate di due punti

Teoria a pagina 204

362 Determina, se è possibile, il coefficiente angolare delle rette AB e CD, conoscendo le coordinate dei punti A(-1; 3), B(3; 5), C(-3; -2) e D(-3; 1).

# COMPLETA LO SVOLGIMENTO

Calcoliamo il coefficiente angolare m(AB) della retta passante per A e per B.

m(AB) = -3/(3 - 1) = 2/4 = 1/2

Dati P1(x1; y1) e P2(x2; y2), il coefficiente angolare della retta passante per P1 e P2 è m = (y2 - y1)/(x2 - x1).

Osserviamo che C e D hanno la stessa ascissa, quindi, se volessimo usare la stessa formula per m(CD), avremmo al denominatore xD - xC = -(-3) = .

La frazione perciò non esiste e non ha senso parlare di coefficiente angolare. La retta infatti è parallela all'asse e ha equazione x = -3.

Determina, se è possibile, il coefficiente angolare della retta passante per la coppia di punti indicata.

363 A(0; 3), B(2; 4).

364 A(1; 5), B(3; 6).

365 C(2; 5), D(4; 5).

366 A(1/3; -1/2), B(2/3; -3/2).

367 E(0; 2), F(0; -2).

368 A(3; -1), B(3; -3).

369 Il punto A(-1; 4) appartiene alla retta AB il cui coefficiente angolare è 2/3. Qual è l'ordinata del punto B se la sua ascissa è 5?

COMPLETA inserendo il valore mancante, sapendo che m è il coefficiente angolare della retta AB.

370 m = 3, A(1; 2), B(3; ).

371 m = , A(3; 2), B(4; 4).

372 m = -1/4, A(2; -1), B( ; -3/2).

373 m = -3, A(-6; -6), B( ; -2).

239

ESERCIZIO

Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

374 TEST Una retta interseca gli assi coordinati nei punti $P(-3; 0)$ e $Q(0; -1)$. Quanto vale il suo coefficiente angolare?

A -3

B $\frac{1}{3}$

C $-\frac{1}{3}$

D 0

# LEGGI IL GRAFICO

375 Scrivi il coefficiente angolare delle rette rappresentate nei seguenti grafici.

![img-60.jpeg](img-60.jpeg)

![img-61.jpeg](img-61.jpeg)

![img-62.jpeg](img-62.jpeg)

![img-63.jpeg](img-63.jpeg)

a

b

c

d

Scrivi le equazioni delle rette $r$, $s$ e $t$ rappresentate nelle figure.

![img-64.jpeg](img-64.jpeg)

![img-65.jpeg](img-65.jpeg)

![img-66.jpeg](img-66.jpeg)

In base alle indicazioni date in ogni figura, ricava $m$ e scrivi l'equazione della retta rappresentata.

![img-67.jpeg](img-67.jpeg)

![img-68.jpeg](img-68.jpeg)

![img-69.jpeg](img-69.jpeg)

![img-70.jpeg](img-70.jpeg)

383 FISICA GRAFICI SPAZIO-TEMPO La figura a lato rappresenta i grafici spazio-tempo di due corpi in moto uniforme.

![img-71.jpeg](img-71.jpeg)

a. Senza fare calcoli, quale corpo è più veloce? Perché?
b. Calcola la velocità dei due corpi.

[b) $v_A = 2,0 \text{ m/s}$; $v_R = 1,0 \text{ m/s}$]

384 Determina l'equazione della retta che passa per $C(-1; 2)$ e ha il coefficiente angolare uguale a quello della retta che passa per $A(2; 2)$ e $B(1; -4)$. [y = 6x + 8]

240

DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

# Retta passante per due punti

Teoria a pagina 205

1 attività interattiva

I FONDAMENTALI

Prova tu fai un esercizio simile interattiva

# Scrivere l'equazione della retta passante per due punti

Per ogni coppia di punti, scriviamo l'equazione della retta PQ:

a. $P(\sqrt{5}; 3), Q(\sqrt{5}; -6);$

b. $P(2; -1), Q(-\sqrt{2}; -1);$

c. $P\left(-\frac{1}{3}; 2\right), Q(3; -8).$

a. I punti \(P\) e \(Q\) hanno la stessa ascissa \(\sqrt{5} \rightarrow PQ\) ha equazione \(x = \sqrt{5}\).
b. I punti \(P\) e \(Q\) hanno la stessa ordinata \(-1\to PQ\) ha equazione \(y = -1\)
c. I punti \(P\) e \(Q\) hanno ascisse e ordinate diverse, quindi l'equazione di \(PQ\) e

$$\frac{y - y_P}{y_Q - y_P} = \frac{x - x_P}{x_Q - x_P} \rightarrow \frac{y - 2}{-8 - 2} = \frac{x - \left(-\frac{1}{3}\right)}{3 - \left(-\frac{1}{3}\right)} \rightarrow y - 2 = (-10) \cdot \frac{x + \frac{1}{3}}{\frac{10}{3}} \rightarrow$$

$$y - 2 = -3x - 1 \rightarrow y = -3x + 1.$$

Se $x_A \neq x_B$ e $y_A \neq y_B$,

$$\frac{y - y_A}{y_B - y_A} = \frac{x - x_A}{x_B - x_A}.$$

# Scrivi l'equazione della retta passante per i punti A e B.

385

A(3; 0),

B(0; 5).

388

A(1; 1),

B(-1; -1).

391

A(8; 8),

B(2; -2).

386

A(-5; 0),

B(7; -2).

389

A($\frac{1}{2}$; -6),

B(2; -3).

392

A($\frac{1}{3}$; -1),

B($2; \frac{2}{3}$).

387

A(2; -1),

B(0; -4).

390

A(5; 2),

B(-3; 2).

393

A(0; 0),

B(5; 4).

GENERALIZZA CON PYTHON

Scrivi un programma che, acquisite in input le coordinate di due punti A e B, con $x_A \neq x_B$ e $y_A \neq y_B$, fornisca l'equazione della retta AB, nella forma $y = mx + q$.

# LEGGI IL GRAFICO Scrivi le equazioni delle rette passanti per i punti A e B di ogni figura.

![img-72.jpeg](img-72.jpeg)

394

![img-73.jpeg](img-73.jpeg)

![img-74.jpeg](img-74.jpeg)

![img-75.jpeg](img-75.jpeg)

395

![img-76.jpeg](img-76.jpeg)

![img-77.jpeg](img-77.jpeg)

![img-78.jpeg](img-78.jpeg)

![img-79.jpeg](img-79.jpeg)

396

Scrivi l'equazione della retta passante per $A\left(\frac{5}{2}; -2\right)$ e $B\left(3; -\frac{3}{2}\right)$ e trova l'ordinata del suo punto C di ascis-

$$\left[ 2x - 2y - 9 = 0; y_C = -\frac{11}{2} \right]$$

241

ESERCIZIO

Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZIO

397

Determina il valore del parametro k affinché il punto A(8k - 6; 2k) appartenga alla retta passante per i punti P(1/2; 0) e Q(3; 5/3).

398

REALTÀ E MODELLI Nella loro azienda agricola Camilla e Petre producono farina biologica di grani antichi. Per produrre 50 kg di farina sostengono un costo di 90 €, mentre per produrre 200 kg i costi ammontano a 210 €. Il grafico della funzione che lega la quantità x di farina prodotta (in kg) ai costi complessivi y (in €) è una retta. Scrivi l'espressione analitica della funzione, calcola la spesa necessaria per produrre 400 kg di farina e determina quanta farina si può ottenere sostenendo dei costi di 1010 €.

[4x - 5y + 250 = 0; 370 €; 1200 kg]

![img-80.jpeg](img-80.jpeg)

399

![img-81.jpeg](img-81.jpeg)

FISICA MOTO RETTILINEO La figura a lato rappresenta il grafico velocità-tempo di due oggetti in moto rettilineo uniformemente accelerato. Scrivi le equazioni delle due rette e determina le accelerazioni dei due oggetti.

[v = 0,40t + 5,6; v = 0,25t + 1,0; aA = 0,40 m/s²; aB = 0,25 m/s²]

400

REALTÀ E MODELLI Un insetto nel piano Oxy parte dal punto (1; 9). Si muove dapprima fino al punto (2; 10), poi al punto (3; 11) e così via. Continua a muoversi in questo modo fino a che raggiunge un punto la cui coordinata y è il doppio della coordinata x. Quali sono le coordinate di questo punto?

(CAN, Canadian Open Mathematics Challenge)

[(8; (6))]

# MATEMATICA PER L'EDUCAZIONE CIVICA

# Energia del vento

# SOSTENIBILITÀ APIRIENTALE

L'energia eolica è una risorsa importante per un futuro sostenibile. Infatti, permette di generare elettricità con poche emissioni nocive, contribuendo così alla riduzione dell'inquinamento atmosferico. Inoltre, sfruttare l'energia del vento consente di ridurre la dipendenza dalle fonti energetiche fossili e di promuovere l'indipendenza energetica da altri Paesi.

![img-82.jpeg](img-82.jpeg)

ESERCIZIO In un Paese, in un certo anno che consideriamo l'anno 0, la potenza eolica installata (cioè la potenza totale degli impianti eolici presenti) era di 2 GW (gigawatt).

Negli anni seguenti, la funzione che esprime la potenza eolica installata, in GW, al variare del tempo, in anni, è stata, in modo approssimato, lineare. Dopo 10 anni la potenza eolica installata è di circa 10 GW.

Scrivi l'equazione della retta che rappresenta la funzione, indicando con y la potenza eolica installata e con x il numero degli anni. Che significato ha il coefficiente angolare della retta? [y = 0,8x + 2]

# UN PASSO IN PIÙ

- Cerca in rete dove sono maggiornente concentrati gli impianti eolici in Italia.
- Cerca informazioni sulla potenza elettrica totale generata in Italia e confrontala con quella proveniente dagli impianti eolici.

242

DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

401 REALTÀ E MODELLI Per il progetto di una scala è stato richiesto di disporre 9 gradini per ogni rampa e di attenersi alla legge di Blondel:

![img-83.jpeg](img-83.jpeg)

$$2a + p = 63,$$

dove $a$ e $p$ indicano, rispettivamente, la alzata e la pedata di ogni gradino, espresse in cm.

a. Calcola la pendenza della Scala (il coefficiente angolare della retta obliqua in figura espresso in percentuale).
b. Calcola la distanza tra il vertic superiore del primo gradino e il vertic superiore del nono gradino.

[a) circa 56%; b) circa 272 cm]

Stabilisci se i punti seguenti sono allineati; nel caso in cui lo siano, scrivi l'equazione della retta su cui giacciono.

402 \(A(1; - 1),\qquad B(5; - 7),\qquad C(-1;2).\)
[3x+2y-1=0]
403 \(A\left(\frac{1}{2}, - \frac{3}{2}\right),\qquad B(1; - 1),\qquad C(-1;0).\)
[non allineati]
404 \(A(-9;1)\) \(B(-3;0)\) \(C(3; - 1)\)

405 TEST L'equazione della retta passante per i punti $A(3; 0)$, $B(0; 2)$ e $C\left(\frac{3}{2}; 1\right)$ è:

A $3x + 2y - 6 = 0$.

B $2x + 3y - 6 = 0$.

C $2x - 3y + 6 = 0$.

D $2x - 3y = 0$.

I punti dei seguenti gruppi appartengono tutti a una stessa retta, tranne uno. Scrivi l'equazione della retta e individua il punto che non appartiene alla retta.

406 \(A(-1; - 5),\qquad B(2;10),\qquad C(-3; - 15),\qquad D(-10; - 2).\)
[1]
407 \(A(3;9)\) \(B(-2;6)\) \(C(4;12)\) \(D(1;3)\)

408 SPIEGA PERCHE Rebecca: «Per determinare se tre punti $A$, $B$ e $C$ sono allineati, verifico che la distanza $AC$ sia uguale alla somma di $AB$ e $BC$».

Lorenzo: «Io scriverei l'equazione della retta $AC$ e verificherei se $B$ appartiene a essa».

Matilde: «Io verificherei solamente se i coefficienti angolari delle rette $AB$, $BC$ e $AC$ sono uguali».

Tu cosa faresti? Perché?

409 Dati i punti \(A(-2;1)\) e \(B(3;3)\) ,trova le coordinate di tre punti appartenenti al segmento \(AB\)
410 Scrivi le equazioni dei lati del triangolo \( ABC \) di vertici \( A(-2;1), B(1;0) \in C(3;2) \).

$$\{x + 3y - 1 = 0; x - y - 1 = 0; x - 5y + 7 = 0\}$$

411 Determina le equazioni delle mediane del triangolo $ABC$ di vertici $A(-3; 0)$, $B(1; 2)$ e $C(1; 6)$.

$$\{5x - 2y + 7 = 0; x - y + 3 = 0; x + 2y - 5 = 0\}$$

412 Scrivi le equazioni dei lati del quadrilatero di vertici $A(-3; 1)$, $B(4; 1)$, $C(2; 6)$, $D(-1; 6)$ e verifica che è un trapezio isoscele. $[y = 1; 5x + 2y - 22 = 0; y = 6; 5x - 2y + 17 = 0]$

413 LEGGI IL GRAFICO Utilizzando i dati della figura a lato, scrivi le equazioni dei lati del parallelogramma e quelle delle diagonali.

![img-84.jpeg](img-84.jpeg)

$$[y = -2; 5x - 2y - 29 = 0; y = 3; 5x - 2y + 6 = 0;$$

$$x + y - 3 = 0; 5x - 9y - 8 = 0]$$

414 Scrivi le equazioni dei lati del triangolo equilatero che ha un lato sull'asse $x$ e il centro nel punto $\left(0; \frac{\sqrt{3}}{3}\right)$.

$$[y = 0, y = -\sqrt{3}x + \sqrt{3}, y = \sqrt{3}x + \sqrt{3}]$$

243

ESERCIZIO

Capitolo 4

PIANO CARTESIANO E RETTA

# LEGGI IL GRAFICO

Esprimi analiticamente le funzioni rappresentate dai seguenti grafici.

415

![img-85.jpeg](img-85.jpeg)

416

![img-86.jpeg](img-86.jpeg)

417

![img-87.jpeg](img-87.jpeg)

Deduci dai grafici:

a. le equazioni di \( f(x) \in g(x) \);
b. per quali valori di \(x\) si ha \(f(x) > g(x)\)

418

![img-88.jpeg](img-88.jpeg)

419

![img-89.jpeg](img-89.jpeg)

420

![img-90.jpeg](img-90.jpeg)

421

Disegna il grafico delle funzioni

$$f(x) = \begin{cases} -\frac{3}{2}x + 2 & \text{se } x < 2 \\ 2x - 5 & \text{se } x \ge 2 \end{cases} \quad \text{e} \quad g(x) = \begin{cases} x + 2 & \text{se } x < 1 \\ 3 & \text{se } x \ge 1 \end{cases}$$

e indica per quali valori di $x$ si ha $f(x) = g(x)$ e $f(x) < g(x)$.

$$[x = 0 \lor x = 4; 0 < x < 4]$$

# Con le relazioni di parallelismo e di perpendicolarità

# I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere le equazioni di una retta parallela e di una retta perpendicolare a una retta data

Data la retta $r$ di equazione $2y + x - 8 = 0$, determiniamo l'equazione della parallela $s$ e della perpendicolare $t$ passanti per $A(1; -1)$.

1 Scriviamo in forma esplicita l'equazione di $r$ e ricaviamo il suo coefficiente angolare.

![img-91.jpeg](img-91.jpeg)

$$y = -\frac{1}{2}x + 4 \rightarrow m = -\frac{1}{2}$$

2 Determiniamo $s$ e $t$ utilizzando la formula $y - y_1 = m(x - x_1)$.

s ha lo stesso coefficiente angolare di $r$.

$$y + 1 = -\frac{1}{2}(x - 1) \rightarrow$$

$$y = -\frac{1}{2}x - \frac{1}{2}$$

t ha coefficiente angolare pari a $-\frac{1}{m}$.

$$y + 1 = 2(x - 1) \rightarrow y = 2x - 3$$

Le condizioni di parallelismo e perpendicolarità danno informazioni sul coefficiente angolare.

Data una retta $r: y = m_1x + q$:

- una retta s parallela a r ha \(m_{1} = m_{1}\)
- una retta t perpendicular a r ha \(m_{t} = -\frac{1}{m_{t}}\)

ESERCITI

244

FAI IL PUNTO SULLE COMPETENZE

Per ciascuna retta, scrivi l'equazione della parallela e della perpendicolare passanti per il punto A.

422 $$y = \frac{1}{4}x, \quad A(1; -1).$$

423 $$2x + 3y - 1 = 0, \quad A(-3; 0).$$

424 $$3x + 6y + 2 = 0, \quad A(5; 1).$$

425 Fra le rette parallele alla retta r di equazione $$3x + 6y - 5 = 0$$, individua quella che passa per il punto P(3; 1) e quella passante per l'origine. $$[2y + x - 5 = 0; 2y + x = 0]$$

426 Fra le rette passanti per il punto Q(-3; -5), individua l'equazione della retta parallela alla retta passante per A(3; 2) e B(1; 1). $$\left[y = \frac{1}{2}x - \frac{7}{2}\right]$$

427 Scrivi l'equazione della retta r che passa per l'origine degli assi ed è perpendicolare alla retta s passante per i punti A(2; 0) e B(0; -5). $$[2x + 5y = 0]$$

428 Scrivi l'equazione della retta che passa per il punto C(-2; 3) ed è perpendicolare alla retta passante per A(2; 5) e B(-3; -1). $$[5x + 6y - 8 = 0]$$

429 Sia M il punto medio del segmento di estremi A(3; 2) e B(1; 6). Scrivi l'equazione della retta r passante per M e parallela alla bisettrice del primo e terzo quadrante. Determina poi il punto di intersezione tra la retta r e la retta s di equazione $$y = 3x - 2$$. $$[y = x + 2; M(2; 4)]$$

LEGGI IL GRAFICO Scrivi le equazioni di ciascuna coppia di rette parallele delle figure.

![img-92.jpeg](img-92.jpeg)

![img-93.jpeg](img-93.jpeg)

![img-94.jpeg](img-94.jpeg)

![img-95.jpeg](img-95.jpeg)

# FAI IL PUNTO SULLE COMPETENZE

Prima di iniziare, esercitati su laZ Esercizi

# Posizione reciproca di due rette
Retta per un punto, retta per due punti

LEGGI IL GRAFICO ASSOCIA a ogni equazione di una retta il grafico della retta a essa parallela.

a. $$2x - 8y + 1 = 0$$

b. $$2x + y = 0$$

c. $$y = 3x + 1$$

d. $$2x + 4y + 4 = 0$$

![img-96.jpeg](img-96.jpeg)

2 Considera le equazioni lineari nelle incognite x e y:

$$kx - y + k - 2 = 0; \quad 2x - (k + 1)y + 3 = 0.$$

a. Determina i valori del parametro reale \(k\) per cui le equazioni rappresentano due rette parallele e disegna le rette individuate.
b. Intersecandosi a due a due, le rette del punto a individuo un quadrilatero: classificato e calculane il perimetro.

$$\left[a) k = -2 \vee k = 1; \text{b) parallelogramma, } 2\left(\frac{\sqrt{2}}{3} + \frac{5}{6}\sqrt{5}\right)\right]$$

>SEGUE

245

ESERCIZI

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

3 TEST Sia r la retta che passa per i punti A(1; -6) e B(-1; -8). Quale delle seguenti affermazioni è corretta?

A Il punto \(C(0; -6)\) appartiene al segmento \(AB\)
B I punti \(A, B \in D(0;7)\) sono allineati.
La retta di equazione \(2x - 2y + 7 = 0\) è perpendicular a \(r\).
La retta r è parallela alla bisettrice del I e III quadrante.

4 TEST Per quale valore di k ∈ ℝ il punto P(-1; k) determina con l'origine O una retta parallela alla retta di equazione y = 2x + 3?

A -2 B -1 C 1 D 2

5 LEGGI IL GRAFICO Scrivi un sistema di disequazioni le cui soluzioni sono gli insiemi di punti indicati in figura.

![img-97.jpeg](img-97.jpeg)

6 Considera il punto P(k - 1; 2 - k), dove k ∈ ℝ. Determina per quali valori di k:

a. la retta per \(P\) e \(Q(3;3)\) è perpendicular alla retta di equazione \(2x + 4y - 2 = 0\)
b. la retta per \(P\) con coefficient angolare 3 ha equazione \(y = 3x\)

[a) k = 7/3; b) k = 5/4]

7 Stabilisci per quali valori di a le rette di equazioni 3ax + y - 3 = 0 e y = 6x + 2a:

a. sono parallele;
b. sono perpendicular;
c. si intersecano in un punto di ascisa \(-2\)

[a) a = -2; b) a = 1/18; c) a = -15/4]

8 LEGGI IL GRAFICO

![img-98.jpeg](img-98.jpeg)

a. Scrivi l'espressione analitica della funzione rappresentata nella figura.
b. Determinina le coordinate del punto di intersezione \(D\) fra la retta perpendicular ad \(AB\) e passante per \(A\) e la retta perpendicular a \(BC\) e passante per \(C\).
c. Verifica che \(ABCD\) è un rettangolo e calculane l'area.

[b) D(1; -8); c) A_ABCD = 78]

9 VERO O FALSO? La retta r forma un angolo di 60° con il semiasse positivo delle ascisse e interseca l'asse y in un punto di ordinata positiva.

a. La retta \(q\): \(6x - 6y - 7 = 0\) interseca \(r\) in un punto che appartiene al secondo quadrante.
b. La retta s: \(y = -\frac{\sqrt{3}}{3} x + 2\) è perpendicular a r.
c. La bisettrice del II e IV quadrante interseca la retta \(r\) in un punto del secondo quadrante.
d. Tutte le rette con coefficient angolare \(\sqrt{3}\) sono parallele a \(r\)

10 EDUCAZIONE FINANZIARIA COSTO E RICAVO Un'azienda familiare produce e vende marmellate. Ha valutato che producendo 10 kg di marmellate alla settimana deve sostenere un costo di 260 €, mentre producendone 50 kg il costo è di 500 €.

![img-99.jpeg](img-99.jpeg)

a. Se la funzione del costo ha come grafico una retta e la funzione del ricavo è \( y = px \), dove \( p \) è il prezzo di vendita, in €/kg, e \( x \geq 0 \) è la quantità, in kg, di marmellate prodotta e venduta, quanto deve valere \( p \) affinché l'azienda non sa sempre in perdita?
b. Se l'azienda vende le marmellate a 11 €/kg, quanti kg di marmellate deve produrre e vendere perché il costo sa uguali al ricavo? [a] \( p > 6 \) €/kg; b) 40 kg]

246

DISTANZA DI UN PUNTO DA UNA RETTA

Paragrafo 5

# 5 Distanza di un punto da una retta

Teoria a pagina 206

434 TEST È vera solo una delle seguenti proposizioni relative al punto $P(1; -2)$ e alle rette $r$ e $s$, rispettivamente di equazioni $2x + y = 0$ e $x + y - 2 = 0$. Quale?

A \(P\) e equidistante da r e da s.
La distanza di \(P\) da \(r\) è maggiore della distanza di \(P\) da s.
\(\boxed{C}\) \(P\) appartiene a s ma non a r.
D \(P\) appartiene a r ma non a s.

Distanza $d$ di $P(x_0, y_0)$ dalla retta di equazione $ax + by + c = 0$:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

435 TEST Il triangolo di vertici $A(-1; -2)$, $B(6; 5)$ e $C(k; -3)$ ha area 28. Qual è il valore di $k$?

A 6.
C 10.
B \(60 - 10\)
D-6o10.

Determina la distanza del punto $P$ dalla retta data.

436 \(P(2; - 6)\) \(3x + 4y = 0.\) （18
437 \(P(2; - 4)\) \(2x - y + 2 = 0.\) （2√5]

438 \(P(-1;4)\) \(y = -\frac{1}{3} x + 2.\) （ \(\frac{\sqrt{10}}{2}\)
439 \(P(4;2)\) \(y = -x - 2.\) （4√2]

440 Stabilisci quale delle seguenti rette ha minore distanza dal punto $P(-1; 3)$:

$$r: x = -3; \quad s: y = -x; \quad t: y = x + 1.$$ [5]

441 Calcola la distanza del punto \(P(0;6)\) alla retta che passa per i punti \(A(2;3)\) e \(B\left(\frac{1}{2};1\right)\). [17]
442 Considera il triangolo \( ABC \) di vertici \( A(-3;3) \), \( B(1; -3) \), \( C(3;1) \). Calcola la misura dell'altezza relativa al lato \( AB \) e l'area del triangolo.

$$\left[ \frac{14\sqrt{13}}{13}; 14 \right]$$

443 Determina l'area del triangolo di vertici $A(4; 0)$, $B(-2; 6)$ e $C(8; 8)$. [36]

# RISOLVI IN 3 PASSI

1 Determina l'equazione della retta \(AB\) e scrivila in forma implicita.
2. Trova la misura dell'altezza relativa al lato \(AB\) come distanza tra il punto \(C\) e la retta \(AB\).
3 Determinina la misura del segmento \(AB\) e calcola l'area del triangolo.

444 Determina la distanza fra le rette parallele di equazioni $y = 2x + 7$ e $y = 2x - 3$. [2√5]

# RISOLVI IN 2 PASSI

1. Considera un punto a piacere su una delle due rette.
2. Calcola la distanza fra il punto scelto e l'altra retta.

445 Calcola la distanza tra le due rette parallele di equazioni $2x - 4y + 1 = 0$ e $y = \frac{1}{2}x + 2$. [7√5/10]

446 Calcola la distanza fra la retta passante per $A(-2; 0)$ e $B(3; 1)$ e la retta di equazione

$$x - 5y - 3 = 0. \quad \left[ \frac{5\sqrt{26}}{26} \right]$$

447 Calcola la misura delle altezze del triangolo di vertici $A(4; 3)$, $B(11; 4)$ e $C(7; 8)$.

$$\left[ \frac{16}{5}\sqrt{2}; \frac{16}{17}\sqrt{34}; \sqrt{32} \right]$$

448 Per quali valori del parametro \(k\) la distanza del punto \(P(k - 1;k)\) alla retta di equazione \(x - 2y - 2 = 0\) e \(\sqrt{5}\) ? \([k = 2\lor k = -8]\)
449 Per quali valori del parametro \(k\) la distanza del punto \(P(1 - 2k;3 + k)\) alla retta di equazione

$$12x - 5y - 2 = 0 \text{ è } \frac{24}{13}? \quad \left[ k = \frac{19}{29} \lor k = -1 \right]$$

450 Data la retta di equazione

$$(2 + 3k)x + (1 - k)y - 3 - 2k = 0,$$

trova per quali valori di $k$ la sua distanza dal punto $P(4; 4)$ è uguale a $\frac{9}{5}\sqrt{5}$.

$$\left[ k = 0 \lor k = -\frac{3}{7} \right]$$

451 Calcola le coordinate dei punti della retta di equazione $x - 3y - 2 = 0$ che hanno distanza $2\sqrt{5}$ dalla retta di equazione $y = 2x + 1$.

$$[(-7; -3), (5; 1)]$$

452 Fra tutti i triangoli $ABC$ di base $AB$, con $A(1; 0)$ e $B(0; 3)$, considera quelli per i quali il vertice $C$ appartiene alla retta $3y - x = 0$ e la cui area vale $\frac{19}{6}$. Trova le coordinate di $C$.

$$\left[ C_1(-1; -\frac{1}{3}), C_2\left(\frac{14}{5}; \frac{14}{15}\right) \right]$$

ESERCIZI

247

Capitolo 4

PIANO CARTESIANO E RETTA

# 6 Luoghi geometrici e retta

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un luogo geometrico

Scriviamo l'equazione del luogo geometrico dei punti del piano che hanno distanza $$\frac{3}{\sqrt{5}}$$ dalla retta $$r$$ di equazione $$2x + y + 3 = 0$$ e rappresentiamo tale luogo nel piano cartesiano.

Indichiamo con $$(x; y)$$ le coordinate di un generico punto $$P$$ del luogo cercato.

Detta $$H$$ la proiezione di $$P$$ sulla retta $$r$$, la distanza di $$P$$ da $$r$$ è:

$$\overline{PH} = \frac{|2 \cdot x + 1 \cdot y + 3|}{\sqrt{2^2 + 1^2}} = \frac{|2x + y + 3|}{\sqrt{5}}.$$

Poiché $$\overline{PH} = \frac{3}{\sqrt{5}}$$, allora:

![img-100.jpeg](img-100.jpeg)

$$\frac{|2x + y + 3|}{\sqrt{5}} = \frac{3}{\sqrt{5}} \rightarrow |2x + y + 3| = 3 \rightarrow 2x + y + 3 = \pm 3 \rightarrow$$

$$2x + y + 3 = -3 \quad \vee \quad 2x + y + 3 = 3 \rightarrow$$

$$2x + y + 6 = 0 \quad \vee \quad 2x + y = 0.$$

Il luogo cercato è costituito dall'unione di due rette, parallele alla retta data, di equazioni:

$$2x + y + 6 = 0 \quad \text{e} \quad 2x + y = 0.$$

Tutti i punti di un luogo geometrico soddisfano una stessa caratteristica. Traduci in termini analitici questa caratteristica per ottenere l'equazione.

453 Determinina e rappresenta l'equazione del luogo geometrico dei punti del piano che hanno distanza 1 alla retta di equazione \(3x + 4y + 5 = 0\)
\([3x + 4y = 0 \lor 3x + 4y + 10 = 0]\)
454 Scrivi l'equazione del luogo dei punti per i quali la somma dei quadrati delle distance dai due punti \(A(1;1)\) e \(B(1; - 1)\) è doppi rispetto al quadrato della distance dall'origine \(O\)
[1] \(x = 1\)
455 Dati i punti \(A(2;5)\) e \(B(6;5)\) , determina il luogo dei punti \(P\) tali che l'area del triangolo \(ABP\) sua 8.

$$[y = 1 \lor y = 9]$$

456 Sono dati i punti $$A(0; 1)$$, $$B(1; 0)$$ e $$C(4; 2)$$. Determina e rappresenta l'equazione del luogo dei punti $$P$$ del piano tali che:

$$\overline{PA}^2 + \overline{PB}^2 = 2\overline{PC}^2.$$

$$[7x + 3y - 19 = 0]$$

457 Date le rette parallele di equazioni \(x - 3y + 2 = 0\) e \(x - 3y + 6 = 0\), scrivi l'equazione del luogo geometrico dei punti equidistanti dalle due rette.
\([x - 3y + 4 = 0]\)
458 Determinina le equazioni delle due rette del piano distanti fra loro \(2\sqrt{5}\) ed equidistanti alla retta \(r\) di equazione \(x - 2y - 1 = 0\)
\([x - 2y + 4 = 0, x - 2y - 6 = 0]\)
459 Determinina l'equazione del luogo descritto dai punti \(P(k - 3;2k - 1)\) al variate di \(k\)

# COMPLETA LO SVOLGIMENTO

Scriviamo le equazioni parametriche del luogo:

$$\begin{cases} x = \_\_\_\_ - 3 \\ y = 2k - 1 \end{cases}$$

Troviamo la sua equazione cartesiana eliminando il parametro $$k$$ dalle due equazioni parametriche:

$$\begin{cases} k = x + 3 \\ y = 2 \_\_\_\_ - 1 \end{cases} \rightarrow y = 2x + \_\_\_\_.$$

ESERCIZIO

248

LUOGHI GEOMETRICI E RETTA

Paragrafo 6

Determina l'equazione del luogo descritto dal punto P al variare di k.

460

$$P(k - 9; -1)$$

$$[y = -1]$$

463

$$P\left(\frac{2k - 1}{k}; \frac{k + 3}{k}\right)$$

$$[y + 3x - 7 = 0, x \neq 2]$$

461

$$P\left(2k + 3; 1 - \frac{k}{2}\right)$$

$$[x + 4y - 7 = 0]$$

464

$$P(1 - k^2; 2 + 2k^2)$$

$$[y = 4 - 2x]$$

462

$$P\left(\frac{k - 4}{3}; 2|k| + 8\right)$$

$$[y = 2 \cdot |3x + 4| + 8]$$

465

$$P\left(\frac{1 - k}{1 + k}; \frac{k}{2(1 + k)}\right)$$

$$[4y + x - 1 = 0, x \neq -1]$$

466

Determina il luogo geometrico descritto dal baricentro del triangolo di vertici $A(2; k - 3)$, $B(2k + 1; 6)$, $C(-5k + 1; 2k)$ al variare di $k$. [3x + 3y - 7 = 0]

467

FISICA MOTO NEL PIANO La torretta di un pantografo da incisione scorre con velocità costante $V_s$ lungo il braccio trasportatore, che a sua volta si muove in direzione perpendicolare con velocità costante di modulo $V_s$. La punta si trova inizialmente in A.

a. Determinina l'equazione della traiettoria descritta alla punta nel riferimento in figura, dove le coordinate sono in cm. Traccia il grafico nel piano cartesian.
b. Quanto è lunga l'incisione tracciata in 40 s? [a) \(2x + 3y - 411 = 0\); b) \(144\mathrm{cm}\)

![img-101.jpeg](img-101.jpeg)

# Asse di un segmento

Teoria a pagina 207

Determina l'equazione dell'asse del segmento che ha per estremi le seguenti coppie di punti.

468

$$A(-2; 1),$$

$$B(4; 3).$$

# COMPLETA LO SVOLGIMENTO

# Primo metodo

![img-102.jpeg](img-102.jpeg)

L'asse del segmento è la retta perpendicolare al segmento passante per il punto medio.

Determiniamo le coordinate del punto medio M di AB:

$$x_M = \frac{+4}{2} = 1, \quad y_M = \frac{1 +}{2} = 2 \rightarrow M(1; 2).$$

Calcoliamo il coefficiente angolare della retta AB:

$$m_{AB} = \frac{y_B - y_A}{x_B - x_A} = \frac{-1}{4 + 2} = \frac{1}{3}.$$

Il coefficiente angolare di una retta perpendicolare ad AB è $m = -3$. L'equazione dell'asse del segmento AB è:

$$y - 2 = 2(x - 1) \rightarrow y = -3x + 3 + 2 \rightarrow y = -3x + 5.$$

# Secondo metodo

L'asse del segmento AB è il luogo geometrico dei punti del piano equidistanti da A e da B.

Indichiamo con $P(x; y)$ un generico punto dell'asse. Vale l'uguaglianza: $\overline{PA} =$

Calcoliamo le distanze di P da A e da B:

$$\overline{PA} = \sqrt{(x + 2)^2 + (y - 3)^2}, \quad \overline{PB} = \sqrt{(x - 3)^2 + (y - 3)^2}.$$

Uguagliamo i quadrati delle distanze e ritroviamo l'equazione dell'asse:

$$x^2 + y^2 - 2y + 5 = x^2 + y^2 - 8x + 25 \rightarrow 12x + 4y - 20 = 0 \rightarrow 3x + y - 5 = 0.$$

469

$$A(2; 3),$$

$$B(4; 5).$$

$$[y = -x + 7]$$

471

$$A(-2; -\frac{1}{3}),$$

$$B(0; \frac{1}{3}).$$

$$[y = -3x - 3]$$

470

$$A(1; 1),$$

$$B(-1; 3).$$

$$[y = x + 2]$$

472

$$A(-2; -6),$$

$$B(2; 0).$$

$$[y = -\frac{2}{3}x - 3]$$

249

ESERCITA

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

473 Determinina sulla retta di equazione \(3x + y = 0\) il punto equidistante dai punti \(A(2; - 1)\in B(4;3)\) . \([(-1;3)]\)
474 Dati due punti \(A(2;3),B(4;1)\) e la retta \(r\) di equazione \(3x - y + 5 = 0\) ,determina su \(r\) un punto C in modo che il triangolo ABC sua isoscele sulla base AB e calcula l'area del triangolo ABC. \([C(-3; - 4);12]\)
475 Sia C il punto in cui l'asse del segmento avente per estremi i punti \(A(-3;3)\) e \(B(1;5)\) in contra l'asse \(x\). Calco la l'area di ABC. [10]
476 Calcola l'area del triangolo isoscele \( ABC \) di base \( BC \), sapendo che \( B(-4;1) \), \( C(0; -1) \) e che il vertic A appariene alla retta di equazione \( 3x + 2y - 15 = 0 \). [15]
477 Trova per quali valori di \(k\) il punto \(P(k - 5;1 - 2k)\) appartiene all'asse del segmento di estremi \(A(-2;4)\) e \(B(1; - 2)\). \(\left[k = \frac{9}{10}\right]\)
478 Il segmento \(AB\) ha per estremi il punto \(A(1; - 2)\) e il punto \(B\), che si trova sull'asse \(x\). Trova l'ascissa di \(B\), sapendo che l'asse del segmento \(AB\) interseca l'asse \(y\) nel punto di ordinata 11. \([x_8 = -7\lor x_8 = 7]\)

# Bisettrici degli angoli formati da due rette

Teoria a pagina 207

479 Considera le rette r e s di equazioni

$$r: x + 2y - 1 = 0, \quad s: 2x + y + 2 = 0.$$

Scrivi l'equazione delle bisettrici degli angoli formati dalle due rette.

# COMPLETA LO SVOLGIMENTO

Se il punto P(x; y) è un generico punto di una bisettrice, allora deve avere la stessa __________ dalle rette r e s, cioè deve valere l'uguaglianza $$\overline{PH} = \overline{PK}$$.

Calcoliamo le distanze di P da r e da s:

$$\overline{PH} = \frac{|x + 2y - 1|}{\sqrt{5}}, \quad \overline{PK} = \frac{|2x + y + 2|}{\sqrt{5}}.$$

Uguagliamo le due distanze:

![img-103.jpeg](img-103.jpeg)

$$\frac{|x + 2y - 1|}{\sqrt{5}} = \frac{|2x + y + 2|}{\sqrt{5}} \rightarrow |x + 2y - 1| = |2x + y + 2|.$$

Questa equazione è equivalente alle due equazioni

$$x + 2y - 1 = \underline{\quad} (2x + y + 2), \text{ cioè:}$$

$$x + 2y - 1 = -(2x + y + 2) \vee x + 2y - 1 = 2x + y + 2 \rightarrow$$

$$3x \underline{\quad} + 1 = 0 \vee \underline{\quad} + y - 3 = 0.$$

Le bisettrici degli angoli formati da r e s hanno per equazioni:

$$3x + 3y + 1 = 0 \quad \text{e} \quad -x + y - 3 = 0.$$

Le bisettrici degli angoli formati da due rette sono perpendicolari fra loro.

# Scrivi le equazioni delle bisettrici degli angoli formati dalle coppie di rette.

480 $$2x + 3y - 1 = 0, \quad 2x - 3y + 3 = 0.$$

$$\left[x = -\frac{1}{2}; y = \frac{2}{3}\right]$$

481 $$x + 6y + 2 = 0, \quad 6x + y - 1 = 0.$$

$$[5x - 5y - 3 = 0; 7x + 7y + 1 = 0]$$

482 $$3x + 5y - 3 = 0, \quad 5x - 3y + 1 = 0.$$

$$[2x - 8y + 4 = 0; 8x + 2y - 2 = 0]$$

483 $$x + y + 3 = 0, \quad x = 0.$$

$$[(1 \pm \sqrt{2})x + y + 3 = 0]$$

484 Dato il triangolo ABC di vertici A(0; 3), B(6; 1), C(5; 8), trova la bisettrice dell'angolo $$A\widehat{C}B$$ e verifica che è anche mediana e altezza. $$[y = 3x - 7]$$

250

LUOGHI GEOMETRICI E RETTA

Paragrafo 6

6

# Punti notevoli di un triangolo

Determina l'incentro dei triangoli ABC.

485 O(0; 0), A(8; 0), B(0; 6).

486 A(0; -2), B(6; 1), C(0; 4).

487 A(0; 3), B(4; 0), C(0; -3).

488 A(-1; 0), B(5; 0), C(2; 4).

489 Determina le coordinate dell'incontro del triangolo di vertici A(0; 4), B(-3; 0) e C(16/3; 0).

Calcola il raggio della circonferenza inscritta.

[(2; 2)]

$$\left[ \left( \frac{3}{2} (\sqrt{5} - 1); 1 \right) \right]$$

$$\left[ \left( \frac{3}{2}; 0 \right) \right]$$

$$\left[ \left( 2; \frac{3}{2} \right) \right]$$

punto di incontro di

baricentro

circocentro

ortocentro

incentro

mediane

assi

altezze

bisettrici

$$\left[ \left( \frac{1}{3}; \frac{5}{3} \right); r = \frac{5}{3} \right]$$

Determina il circocentro dei triangoli ABC.

490 A(-2; 1), B(2; 5), C(4; -1).

$$\left[ \left( \frac{3}{2}; \frac{3}{2} \right) \right]$$

RISOLVI IN 3 PASSI

1 Indica con \((x,y)\) le coordinate del circumocentro \(D\) del triangolo, che è il centro della circonferenza circoscritta e quando è equidistante dai tre vertici.
2 Calcola le distance \(\overline{DA}\) \(\overline{DB}\) e \(\overline{DC}\)
3 Scrivi e risolvi il systemà \(\left[\frac{\overline{DA} = \overline{DB}}{\overline{DB} = \overline{DC}}\right]\)

491 A(-3; 0), B(1; 4), C(-3; 6). [(-2; 3)]

492 A(5; -1), B(-1; 1), C(-2; -4). [(21/16; -33/16)]

493 Trova le coordinate dell'ortocentro del triangolo di vertici A(3; 5), B(1; 0), C(9; 8). [(-6; 14)]

494 Dato il triangolo di vertici A(6; 0), B(3; 6) e C(0; 2), determina le coordinate dell'ortocentro e del baricentro. [(2; 3), (3; 8/3)]

495 Verifica che il triangolo ABC di vertici A(1; 1), B(4; 7) e C(-5; 4) è un triangolo rettangolo e:

a. scrivi le equazioni dei lati;
b. determina l'ortocentro;
c. determina il circumocentro.

$$\left[ \begin{array}{l} \text{a) } 2x - y - 1 = 0, x - 3y + 17 = 0, x + 2y - 3 = 0; \end{array} \right.$$

$$\left. \begin{array}{l} \text{b) } (1; 1); \text{c) } \left( -\frac{1}{2}; \frac{11}{2} \right) \end{array} \right]$$

496 Trova le coordinate del baricentro e del circocentro e l'area del triangolo di vertici A(2; 1), B(8; 1) e C(5; 4). [(5; 2); (5; 1); 9]

497 Verifica che il triangolo di vertici

$$A(3; 0), B\left(\frac{18}{5}; \frac{9}{5}\right) \text{ e } C\left(\frac{24}{5}; -\frac{3}{5}\right)$$

è rettangolo isoscele. Determina poi il centro e il raggio della circonferenza circoscritta al triangolo.

$$\left[ \left( \frac{21}{5}; \frac{3}{5} \right); \frac{3}{5} \sqrt{5} \right]$$

498 Dato il triangolo di vertici A(-1; -1), B(-1; 5), C(8; 2), verifica che è un triangolo isoscele e trova il baricentro, il circocentro e l'ortocentro.

$$\left[ (2; 2), (3; 2), (0; 2) \right]$$

499 Verifica che nel triangolo ABC, di vertici A(-2; -2), B(4; -2) e C(1; 6), il baricentro, l'ortocentro e il circocentro sono allineati.

500 Calcola le coordinate dell'incontro, del circocentro, del baricentro e dell'ortocentro del triangolo di vertici A(0; 8), B(6; 0) e C(0; 0).

$$\left[ (2; 2); (3; 4); \left( 2; \frac{8}{3} \right); (0; 0) \right]$$

501 Dopo aver verificato che il triangolo di vertici A(1; 2), B(7; 2), C(4; 5) è un triangolo isoscele, trova le coordinate dell'incontro, del baricentro e dell'ortocentro. [(4; 3√2 - 1); (4; 3); (4; 5)]

502 È dato il triangolo di vertici A(-1; 0), B(3; 2), C(1; 3).

a. Determina le coordinate del baricentro \(G\) del circumocentro \(D\) dell'ortocentro \(H\)
b. Verifica che \(G, D, H\) sono allineati e che \(G\) divide il segmento \(DH\) in due parti tali che \(GH \cong 2DG\) (teorema di Eulero).

$$\left[ \text{a) } G\left( 1; \frac{5}{3} \right), D\left( \frac{9}{8}; \frac{3}{4} \right), H\left( \frac{3}{4}; \frac{7}{2} \right) \right]$$

251

ESERCIZI

Capitolo 4 PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

Prima di iniziare,
esercitati su laZ Esercizi

# Distanza di un punto da una retta e luoghi geometrici

1 Sia \(r_a\) la retta di equazione \((a + 1)x + (a - 2)y - 7a + 2 = 0\), con \(a \in \mathbb{R}\). Determinina per quale valore di a la distanza fra \(r_a\) e il punto \(P(2;3)\) è \(\sqrt{2}\). \(\left[a = \frac{1}{2}\right]\)
2 Determina i punti \(A\) e \(B\) della retta \(r\): \(3x - y + 2 = 0\) che hanno distanza \(4\sqrt{2}\) alla retta \(s\): \(x + y + 2 = 0\), con \(x_{A} < x_{B}\). Detti \(H\) e \(K\) i piedi delle perpendiculari a s condotte rispettovamente da \(A\) e da \(B\) e detto \(C\) il punto di intersezione fra \(r\) e \(s\), dimostra che i triangoli \(AHC\) e \(BKC\) sono congruenti e calculane l'area.

[A(-3; -7), B(1; 5); 8]

3 Un rombo \(ABCD\) ha area 30 e due vertici opposti hanno coordinate \(A(-7;4)\) e \(C(5; - 2)\). Trova le coordinate degli altri due vertici, \(B\in D\), e il raggio della circonferenza inscritta nel rombo. \(\left[(-2; - 1),(0;3);\frac{3}{2}\sqrt{2}\right]\)
4 Sia \(G\) il baricentro del triangolo di vertici \(A(2; - 1),B(-4; - 3)\in C(k - 5;2k + 2)\) . Trova per quali valori di \(k\) la distanza tra \(G\) e il lato \(AB\) vale \(\frac{7}{10}\sqrt{10}\) \(\left[k = 1\vee k = -\frac{37}{5}\right]\)
5 VERO FALSO? Considera il triangolo di vertici \(A(2;1)\) \(B(7;3)\in C(4;6)\)

a. Il triangolo è isoscele.
b. Incentro, circocentro e ortocentro apparpengono a una retta passante per \(A\)
c. L'asse del lato \(AC\) ha equazione \(2x + 5y = 23\)
d. La retta di equazione \(x + y = 8\) divide il triangolo in due poligoni equivalenti.

V F
V F
V F
V F

6 LEGGI IL GRAFICO ASSOCIA a ogni retta la sua equazione facendo riferimento al triangolo ABC in figura.

![img-104.jpeg](img-104.jpeg)

a. Bisettrice dell'angolo \(\widehat{A}\)
1. \(12x + 2y - 3 = 0\)
b. Asse di \(AB\)
2. \(2x + 12y = 43\)
c. Altezza relativa ad \(AB\)
3. \(x - y + 4 = 0\)
d. Asse di AC.
4. \(6x + y + 5 = 0\)

7 Scrivi l'equazione del luogo dei baricentri dei triangoli di vertici \(A(2k + 4; k - 1)\), \(B(k + 1; k + 4)\) e \(C(k + 3; 2k + 3)\) al variate di \(k \in \mathbb{R}\). [3x - 3y = 2]
8 Dati i punti \(A(-2; - 1)\in B(2;2)\) , determina il luogo \(\gamma\) dei punti tali che il triangolo ABC abbia area 10.

[3x - 4y + 22 = 0 ∨ 3x - 4y - 18 = 0]

9 Considera il triangolo di vertici A(-6; -4), B(1 - 3k/2; 2k + 4) e C(-5; 3). Trova per quali valori di k il circocentro del triangolo ha coordinate (-2; -1). Determina poi il raggio della circonferenza circoscritta.

[k = -1; r = 5]

10 Considera il triangolo di vertici A(4k; 4k²), B(4k; -1) e C(0; 1), k ≠ 0. Detto P il punto di intersezione tra la mediana relativa ad AB e l'asse di BC, determina l'equazione del luogo γ descritto dal punto P al variare del parametro k. Trova poi, se esistono, le coordinate dei punti di γ appartenenti alla bisettrice del I e III quadrante.

[y = 3/16 x², x ≠ 0; (16/3; 16/3)]

11 FISICA COMPOSIZIONE DI MOTI Un nuotatore si tuffa in un fiume e nuota perpendicolarmente alle sponde con velocità di modulo v_N = 0,8 m/s, mentre la corrente del fiume scorre a una velocità di modulo v_F = 1,5 m/s con la direzione indicata nella figura a lato.

![img-105.jpeg](img-105.jpeg)

a. Determinina l'equazione della traiettoria descritta dal nuotatore nel piano cartesianopappresentato.
b. Sapendo che il fume è长大o \(16\mathrm{m}\) ,calcola il tempo necessario per atraversarlo e la distanza totale percorsa dal nuotatore.

[a) 8x - 15y = 0; b) 20 s, 34 m]

ESERCIZI

252

PROBLEMI CON LE RETTE

RIEPILOGO

# RIEPILOGO Problemi con le rette

# 503 VERO O FALSO?

a. L'equazione $|x| + |y| = 2$ individua nel piano cartesiano un quadrato di area 8.

V F

b. Le due rette di equazioni $x + 2y + 1 = 0$ e $x - 2y + 1 = 0$ sono simmetriche rispetto all'asse $x$.

V F

c. La bisettrice degli angoli acuti formati dalle due rette di equazioni $4x - 3y + 1 = 0$ e $3x = 4y + 2$ è la retta $x + y + 3 = 0$.

V F

d. Le due rette di equazioni $y = 3x + 5$ e $y = -3x + 5$ sono simmetriche rispetto all'asse $y$.

V F

504 Considera la retta passante per $A(0; 5)$ e $B(-2; -3)$. Determina su tale retta un punto $C$ la cui ascissa è tripla dell'ordinata. Considera la retta parallela all'asse $x$ passante per $A$ e la retta parallela all'asse $y$ passante per $B$. Determina il punto $D$ di intersezione di queste due rette e calcola l'area del triangolo $DAC$.

$$\left[ C \left( - \frac { 1 5 } { 1 1 } ; - \frac { 5 } { 1 1 } \right) ; D ( - 2 ; 5 ) ; \frac { 6 0 } { 1 1 } \right]$$

505 I lati di un quadrilatero $ABCD$ appartengono alle rette di equazioni: $x - y = 0$, $x + y - 2 = 0$, $x + y - 6 = 0$, $x - y - 4 = 0$. Determina le coordinate dei vertici, verifica che $ABCD$ è un quadrato e calcolane area e perimetro.

$$[ A ( 1 ; 1 ) , B ( 3 ; 3 ) , C ( 5 ; 1 ) , D ( 3 ; - 1 ) ; 8 ; 8 \sqrt { 2 } ]$$

506 Da un punto $A(-5; -4)$ conduci la parallela $r$ e la perpendicolare $s$ alla retta $t$ di equazione $y = 2x + 1$. Detto $B$ il punto di intersezione di $s$ e $t$ e detti $C$ e $D$ i punti di intersezione rispettivamente di $t$ e $r$ con l'asse delle ordinate, stabilisci che tipo di quadrilatero è $ABCD$ e calcolane l'area.

[trapezio rettangolo; 20]

507 Un parallelogramma $ABCD$ ha i lati $AB$, $BC$ e $DA$ che si trovano rispettivamente sulle rette di equazioni $2x + y - 2 = 0$, $4x - 7y - 4 = 0$ e $4x - 7y + 14 = 0$.

Sapendo che $C$ ha coordinate $(8; 4)$, determina le coordinate degli altri vertici del parallelogramma e del punto di incontro delle diagonali.

$$[ A ( 0 ; 2 ) , B ( 1 ; 0 ) , D ( 7 ; 6 ) , M ( 4 ; 3 ) ]$$

508 Il vertice $A$ di un triangolo $ABC$ ha coordinate $(-2; 3)$; si sa che l'altezza uscente dal vertice $C$ ha equazione $x - y - 2 = 0$ e che l'equazione del lato $BC$ è $2x - 3y - 2 = 0$. Calcola le coordinate degli altri due vertici del triangolo e la sua area.

$$\left[ C ( 4 ; 2 ) , B ( 1 ; 0 ) ; \frac { 1 5 } { 2 } \right]$$

# LEGGI IL GRAFICO

509 Deduci dal grafico:

a. le equazioni di \(f(x)\in g(x)\)
b. per quali valori di \(x\) si ha \(f(x) <   g(x)\)

![img-106.jpeg](img-106.jpeg)

![img-107.jpeg](img-107.jpeg)

511 LEGGI IL GRAFICO Utilizzando i dati della figura stabilisci se il triangolo $ABC$ è rettangolo.

510 Il quadrilatero $ABCD$ della figura è un quadrato. Trova le coordinate di $D$. [(2; 8)]

512 ASSOCIA a ciascuna coppia di rette la proprietà soddisfatta da entrambe le rette.

![img-108.jpeg](img-108.jpeg)

a. \(3x + y - 2 = 0\mathrm{e}y = 3x + 2.\)
b. \(3x - 2y + 4 = 0\mathrm{e}2x + 3y - 6 = 0.\)
c. \(2y - x - 1 = 0\mathrm{e}y = 2x + 2.\)
d. \(6x - 3y + 1 = 0\mathrm{e}2x - y + 3 = 0.\)

1. Intersecano l'asse \(x\) nel punto di ascissa \(-1\).
2. Sono perpendiculari.
3. Hanno la stessa distanza dall'origine.
4. Sono parallele.

ESERCIZI

253

Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

513 Verifica che il quadrilatero di vertici A(3; 0), B(13; 4), C(9; 6), D(4; 4) è un trapezio e che il segmento che congiunge i punti medi dei lati obliqui è parallelo alle due basi e congruente alla loro semisomma.

514 Determina i vertici e l'area del parallelogramma ABCD che ha due lati consecutivi sulle rette di equazioni 3x + y - 5 = 0, 5x - y - 11 = 0 e un vertice nel punto A(4; 1).

[B(3; -4), C(2; -1), D(3; 4); 8]

515 Il triangolo ABC ha i lati sulle rette di equazioni:

r: y = x + 2,

s: y = -1/2 x + 7/2,

t: 7y - x - 2 = 0.

Determina il perimetro, l'area e il baricentro. Verifica inoltre che il triangolo che si ottiene congiungendo i punti medi dei lati ha il perimetro uguale alla metà di quello di ABC.

[8√2 + 2√5; 9; (4/3; 4/3)]

516 EUREKAI Un quadrato, con un vertice nel punto A(1; 2), ha un lato sulla retta di equazione x - 2y + 3 = 0. Individua le coordinate degli altri tre vertici del quadrato, sapendo che uno di essi sta sull'asse x, mentre gli altri sono interni al primo quadrante. [(2; 0), (4; 1), (3; 3)]

517 Due triangoli congruenti hanno ciascuno area 24. I loro vertici sono determinati dalle intersezioni delle rette di equazioni y = -4, x = 0 e y = 3/4 x + b. Determina i due possibili valori di b.

(CAN, Canadian Open Mathematics Challenge)
[b = 2, b = -10]

523 Dato il triangolo di vertici A(-1; 2), B(-9; 2), C(-5; -1), verifica che è un triangolo isoscele e determina il baricentro, l'incontro, il circocentro e l'ortocentro.

524 Rappresenta nello stesso piano cartesiano le seguenti funzioni:

f(x) = |x - 2| + 3 e g(x) = {2x + 4 se x ≤ 1; 1/3 (-x + 19) se x > 1}

Trova poi i vertici e l'area del quadrilatero che si forma dall'intersezione dei loro grafici.

[(1; 6), (4; 5), (2; 3), (1/3; 14/3), 17/3]

Trova l'area della figura individuata nel piano cartesiano dai seguenti sistemi di disequazioni.

525

{2y ≥ 3x - 3; 3y ≤ 2x + 3; y ≥ -x + 1}

[5/2]

526

{y + x ≥ 0; y - 2 ≤ 0; 4y ≥ x - 5; y ≤ 5 - x}

[25/2]

254

FASCI DI RETTE

Paragrafo 7

527 Nel sistema di disequazioni $$\begin{cases} x - y + 1 \leq 0 \\ x + y \geq 0 \\ 3y - x + k \leq 0 \end{cases}$$ trova:

a. per quali valori di \(k\) il systemammette soluzione;
b. il valore di \( k \) per cui la regione di piano soluzione del systemà è un triangolo rettangolo che ha ipotenusa lunga \( \frac{\sqrt{10}}{10} \). [a) \( k \leq -2 \); b) \( k = -\frac{12}{5} \)]

528 Un rombo ha due lati che si trovano sulle rette di equazioni \(3x - 4y + 12 = 0\) e \(x + 2 = 0\), il raggio della circonferenza inscritta è \(\frac{13}{4}\) e il suo centro ha coordinate positive. Determina i vertici, il perimetro e l'area del rombo. \(\left[A\left(-2;\frac{3}{2}\right),B\left(\frac{9}{2};\frac{51}{8}\right),C\left(\frac{9}{2};\frac{29}{2}\right),D\left(-2;\frac{77}{8}\right),\frac{65}{2};\frac{845}{16}\right]\)
539 Disegna i grafici delle funzioni \( y = |x - 1| + |x + 4| - 2 \) e \( y = x - 2|x - 2| + 4 \) e trova i loro punti di intersezione. \(\left[A(1;3),B\left(\frac{7}{3};\frac{17}{3}\right)\right]\)
530 Data la retta \(r\) di equazione \(x - 2y + 6 = 0\) e il punto \(A(5;1)\), sua \(B\) il punto in cui \(r\) in contra la retta \(s\) per \(A\) parallela all'asse delle ascisse e sua \(P\) un generico punto su \(r\). Indicato con \(M\) il punto medio di \(AP\) e con \(H\) la proiezione di \(P\) su \(s\), determina le coordinate di \(P\) affinché si abbia:

$$\overline{PH}^2 + \overline{HM}^2 = \frac{9}{16} \overline{BP}^2.$$

$$[P_1(0; 3) \text{ e } P_2(-40; -17)]$$

# 7 Fasci di rette

# Fascio improprio

Teoria a pagina 208

1 attività interattiva

531 TEST Una sola delle seguenti equazioni non rappresenta un fascio improprio. Quale?

A $$y = -2x + 2 + a$$

C $$y = 3x + 5 - k$$

B $$2x - 4ky = 9$$

D $$ky - kx = 2$$

532 AL VOLO Scrivi l'equazione del fascio improprio a cui appartiene l'asse y.

# I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un fascio improprio di rette

Scriviamo l'equazione del fascio improprio di rette contenente la retta di equazione $$2x + y - 3 = 0$$ e disegniamo alcune rette del fascio.

Scriviamo l'equazione della retta in forma esplicita, per ricavare il suo coefficiente angolare m:

![img-109.jpeg](img-109.jpeg)

$$y = -2x + 3 \rightarrow m = -2.$$

Il fascio di rette ha equazione $$y = -2x + q$$.

Disegniamo le rette corrispondenti a tre valori di q, per esempio 0, 2, -2. Le rette corrispondenti sono:

$$y = -2x; \quad y = -2x + 2; \quad y = -2x - 2.$$

Le rette di un fascio improprio sono tutte parallele, perciò hanno lo stesso coefficiente angolare e cambia solo l'ordinata all'origine.

533 Scrivi l'equazione del fascio improprio contenente la retta di equazione $$8x - 4y + 6 = 0$$ e disegna alcune rette del fascio.

255

ESERCIZI

Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

534

Disegna cinque rette del fascio di equazione $y = 3x + k$, con $k \in \mathbb{R}$.

GENERALIZZA CON PYTHON

Scrivi un programma che chieda in input il coefficiente angolare della retta di equazione $y = mx + k$ e disegni le rette del fascio per $k = -7, -4, -1, 2, 5$.

535

Scrivi l'equazione del fascio di rette parallele alla retta di equazione $y = -4x + 5$ e l'equazione del fascio di rette perpendicolari alle precedenti. Rappresenta alcune rette di ciascun fascio.

536

AL VOLO Dato il fascio di equazione $y = 2x + 3k + 1$, stabilisci per quali valori di $k$ si ottengono la retta del fascio passante per l'origine e la retta passante per il punto (0; 4).

537

Scrivi l'equazione del fascio improprio contenente la retta che passa per i punti $A(-3; 2)$ e $B(1; -1)$ e rappresenta altre due rette del fascio.

$$\left[ y = -\frac{3}{4}x + k \right]$$

538

Scrivi l'equazione del fascio improprio contenente la retta $2x - 5y - 10 = 0$ e determina l'equazione della retta del fascio passante per il punto $(-4; -1)$.

$$\left[ 2x - 5y + 3 = 0 \right]$$

# Fascio proprio

Teoria a pagina 209

1 attività interattiva

539

Quali delle seguenti equazioni rappresentano un fascio proprio di rette di centro $P(-1; 2)$?

a. $y = -2x + q$

b. $y = mx + 2 + m$

c. $my + x - 2m + 1 = 0$

d. $y = mx + m - 2$

Determina per ogni fascio proprio il relativo centro e scrivi l'equazione della retta esclusa.

540

$$mx + y - 2m + 1 = 0$$

543

$$6kx + 10k - 3y = 0$$

541

$$6mx - 6y - 10m + 3 = 0$$

544

$$3y - 6m + mx + 3 = 0$$

542

$$3y - mx + 2 = 0$$

545

$$5y + 5m + 2 - 5mx = 0$$

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un fascio proprio di rette di centro assegnato

Scriviamo l'equazione completa del fascio proprio di rette passante per il punto $P(-3; \frac{4}{3})$ e disegniamo le rette del fascio aventi coefficiente angolare $m = 0$ e $m = 1$.

Usando l'equazione del fascio per $P$, otteniamo

$$y - \frac{4}{3} = m(x + 3) \rightarrow y = mx + 3m + \frac{4}{3},$$

a cui dobbiamo aggiungere la retta parallela all'asse $y$, di equazione $x = -3$.

L'equazione completa del fascio è quindi:

![img-110.jpeg](img-110.jpeg)

$$y = mx + 3m + \frac{4}{3} \vee x = -3, \quad \text{con } m \in \mathbb{R}.$$

Troviamo le rette del fascio con coefficiente angolare 0 e 1:

se \(m = 0\) ， \(y = \frac{4}{3}\)
se \(m = 1\) \(y = x + 3 + \frac{4}{3}\rightarrow y = x + \frac{13}{3}.\)

Poiché le due rette passano per $P$, per disegnarle basta determinare un solo altro punto su ciascuna.

L'equazione della retta generica passante per $P(x_0; y_0)$, $y - y_0 = m(x - x_0)$, con $m$ variabile, non rappresenta tutte le rette per $P$: manca la retta parallela all'asse $y$, di equazione $x = x_0$.

256

FASCI DI RETTE

Paragrafo 7

![img-111.jpeg](img-111.jpeg)

Scrivi l'equazione completa del fascio proprio di rette passante per ciascun punto indicato e disegna le rette aventi coefficiente angolare $m = 0$, $m = 2$, $m = -3$.

546 $A(2; -3)$

547 $D(7; -3)$

548 $Q\left(-\frac{1}{4}; \frac{3}{4}\right)$

GENERALIZZA CON PYTHON

Scrivi un programma che acquisisca in input le coordinate di un punto $P$, centro di un fascio di rette, e disegni quelle di coefficienti angolari interi da $-3$ a $3$.

549 Scrivi l'equazione del fascio proprio con il centro nel punto di intersezione delle rette \( r \) e \( s \) rispettovamente di equazioni \( x - y - 3 = 0 \) e \( 3x - 5y - 5 = 0 \).
550 Stabilisci se le rette di equazioni \( x - 2y + 6 = 0 \), \( x + 4y - 6 = 0 \) e \( 3x + 2y + 2 = 0 \) appartengono allo stesso fascio; in caso affirmativo, stabilisci il tipo di fascio e scrivi la sua equazione.
551 Scrivi l'equazione del fascio proprio con il centro in \(P(3; - 3)\) e determina l'equazione della retta del fascio:

a. parallela alla retta di equazione \(x - 3y + 5 = 0\)
b. perpendicularare alla retta di equazione \(6x + 3y - 4 = 0\)

c. passante per il punto $Q(-2; 7)$.

[a) $x - 3y - 12 = 0$; b) $x - 2y - 9 = 0$; c) $2x + y - 3 = 0$]

Per ciascuno dei seguenti fasci di rette indica se si tratta di un fascio proprio o improprio e, nel caso di un fascio proprio, determina il suo centro.

552 $2x - 2ky + 1 = 0$

RISOLVI IN 4 PASSI

1 Scrivi l'equazione del fascio in forma esplicita per mettere in evidenza il coefficiente angolare \(m\)
2 Classifica il fascio: se \(m\) non dipende dal parametro \(k\), il fascio è improprio, altrimenti è proprio.
3 Se il fascio è proprio, determina due rette del fascio assegnando valori a piacere al parametro \(k\).
4 Risolvi il systemà formato delle equazioni delle due rette e determina il centro del fascio.

553 $3kx - ky - 6 = 0$

555 $y = 2kx + x + 1$

557 $kx + 2ky - 3 = 0$

554 $2x + y + k - 5 = 0$

556 $y = (2 - k)x + k$

558 $(k - 1)x + 2ky - k = 0$

559 Quali delle seguenti rette appartengono al fascio di equazione $(1 - k)x + y + k = 0$?

a. $y = -1$

b. $3x + y - 2 = 0$

c. $2x + y - 2 = 0$

d. $6x - 2y - 8 = 0$

560 TEST Per quale valore di $k \in \mathbb{R}$ una retta del fascio di equazione $(k - 1)x - (3 - 3k)y + 2k - 3 = 0$ è parallela alla bisettrice del primo e terzo quadrante?

A $k = 1$

B $k = -1$

C $\forall k \in \mathbb{R}$

D $\nexists k \in \mathbb{R}$

561 Dato il fascio di equazione $2x - (2 + 2k)y + k + 1 = 0$, determina per quale valore di $k$ si ha una retta:

a. passante per il punto \((0; - 3)\)
b. parallela alla retta di equazione \(x - y + 1 = 0\)
c. perpendicularare alla retta di equazione \(y = 2x + 5\)

[a) $-1$; b) $0$; c) $-3$]

562 Dato il fascio di equazione $(1 - 2k)x + (3 + k)y + 2 - k = 0$, determina l'equazione della retta del fascio:

a. parallela all'asse $x$;

b. parallela all'asse $y$;

c. passante per l'origine.

[a) $y = -\frac{3}{7}$; b) $x = -\frac{5}{7}$; c) $3x - 5y = 0$]

563 Determina l'equazione della retta appartenente al fascio di equazione $(1 + k)x + (1 + k)y + 3k - 1 = 0$:

a. passante per l'origine;

c. che interseca l'asse delle ascisse per $x = 1$.

b. passante per $(-2; -5)$;

[a) $x + y = 0$; b) $x + y + 7 = 0$; c) $x + y - 1 = 0$]

564 Dato il fascio di equazione $5kx - (k + 4)y - 2 = 0$, determina l'equazione della retta che appartiene al fascio:

a. perpendicularare alla retta di equazione \(3x + 5y - 1 = 0\)
b. parallela alla retta di equazione \(x - y = 0\)

c. passante per il punto $\left(-\frac{1}{5}; 1\right)$.

[a) $5x - 3y - 1 = 0$; b) $5x - 5y - 2 = 0$; c) $15x + y + 2 = 0$]

257

ESERCIZIO

Capitolo 4 PIANO CARTESIANO E RETTA

# Fasci generati da due rette

Teoria a pagina 209

565 Scrivi l'equazione del fascio generato dalle rette r e s di equazioni x - 2y + 1 = 0, x + y - 2 = 0; stabilisci il tipo di fascio e determina la retta del fascio passante per il punto P(3; -2).

# COMPLETA LO SVOLGIMENTO

Scriviamo l'equazione del fascio generato dalle rette r e s combinando linearmente le loro equazioni:

$$x - 2y + 1 + k(x + y - 2) = 0 \rightarrow x - 2y + 1 + kx + ky - 2k = 0.$$

Raccogliamo x e y: (1 + k) x + (k - 2) y + 1 - 2k = 0.

Osserviamo che le rette non sono parallele perché

Nella combinazione lineare, è indifferente scrivere prima l'equazione di r o quella di s.

$$m_r = \_\_\_\_\_ \text{ e } m_s = \_\_\_\_\_$$

Il fascio è \_\_\_\_\_ e il centro è il punto C di intersezione tra le generatrici r e s.

$$\begin{cases} x - 2y + 1 = 0 \\ x + y - 2 = 0 \end{cases} \rightarrow \begin{cases} x = 2y - 1 \\ 2y - 1 + y - 2 = 0 \end{cases} \rightarrow \begin{cases} x = 2y - 1 \\ 3y = 3 \end{cases} \rightarrow \begin{cases} x = 1 \\ y = 1 \end{cases} \rightarrow C(1; 1)$$

Per determinare l'equazione della retta del fascio passante per P(3; -2) sostituiamo le coordinate di P alla x e alla y nell'equazione del fascio:

$$(1 + k) 3 + (k - 2) \_\_\_\_\_ + 1 - 2k = 0 \rightarrow 3 + 3k - 2k + 4 + 1 - 2k = 0 \rightarrow k = 8.$$

Sostituiamo k = 8 nell'equazione del fascio e otteniamo l'equazione richiesta:

$$\_\_\_\_\_ + 6y - 15 = 0 \rightarrow 3x + 2y - 5 = 0.$$

566 Scrivi l'equazione del fascio di rette le cui generatrici hanno equazioni 3x + 2y - 1 = 0 e 6x + 4y + 3 = 0, stabilisci di che fascio si tratta e determina l'equazione della retta del fascio che interseca l'asse y nel punto di ordinata 1. [fascio improprio; 3x + 2y - 2 = 0]

567 Scrivi l'equazione del fascio generato dalle rette di equazioni 3x + y - 1 = 0 e x + 2y + 3 = 0, stabilisci se è proprio o improprio e individua l'equazione della retta del fascio che passa per P(4; 1).

[fascio proprio di centro C(1; -2); x - y - 3 = 0]

568 Dopo aver scritto l'equazione del fascio generato dalle rette di equazioni 3x - 2y + 4 = 0 e 2x + y - 2 = 0, stabilisci se è proprio o improprio e determina l'equazione della retta del fascio parallela alla bisettrice del primo e terzo quadrante. [fascio proprio di centro C(0; 2); x - y + 2 = 0]

569 Nel fascio di rette le cui generatrici hanno equazioni 2x + 3y - 7 = 0 e x + 4y - 1 = 0 determina la retta di coefficiente angolare m = -4. [y = -4x + 19]

570 Determina l'equazione della retta che interseca l'asse y nel punto di ordinata -3 e che appartiene al fascio generato dalle rette di equazioni 2x - y + 2 = 0 e -2x + y = 0. [2x - y - 3 = 0]

571 Fra le rette del fascio le cui generatrici hanno equazioni 3x - 2y - 3 = 0 e 3x - 4y = 0, determina quella parallela alla retta di equazione 3x + 4y + 2 = 0. [3x + 4y - 12 = 0]

572 REALTÀ E MODELLI La meridiana solare rappresentata in figura segna le ore utilizzando l'ombra che un'asta proietta sul sistema di linee dipinto su una parete. Considera le due linee evidenziate in colore rosso, di estremi A(0; 5), B(3; 44/7) e C(3; 0), D(5; 4) nel riferimento Oxy, quindi:

![img-112.jpeg](img-112.jpeg)

a. ricava l'equazione del fascio proprio di rette che ha per generatrici le rette \(AB\) e \(CD\), assegnando alla retta \(CD\) il ruolo di generatrice corrispondente al valore nullo del parametro;
b. determina il centro del fascio;
c. ricava l'equazione della retta del fascio che corrisponde a un'ora intermedia tra la VII e la VIII,cioe la retta passante per l'origine \(O\) del riferimento.

[a) (2 + 3k)x - (1 + 7k)y + 35k - 6 = 0; b) C(7; 8); c) 8x - 7y = 0]

ESERCIT

258

FASCI DI RETTE

Paragrafo 7

# Studio di un fascio di rette

OLTRE I FONDAMENTALI

# Studiare un fascio di rette

Studiamo il fascio di rette di equazione:

$$(k + 1)x + (2k + 1)y + k + 2 = 0.$$

# 1 Determiniamo le generatrici per individuare la natura del fascio.

Svolgiamo i calcoli e raccogliamo k.

$$\begin{array}{l} kx + x + 2ky + y + k + 2 = 0 \rightarrow \\ x + y + 2 + k(x + 2y + 1) = 0 \end{array}$$

Le generatrici hanno equazioni:

$$\begin{array}{l} t: x + y + 2 = 0; \text{—— generatrice che si ottiene per } k = 0 \\ u: x + 2y + 1 = 0. \text{—— generatrice che non si ottiene} \\ \text{per alcun valore reale di } k \end{array}$$

Le generatrici non hanno lo stesso coefficiente angolare.

Infatti $m_t = -1$ e $m_u = -\frac{1}{2}$, quindi non sono parallele.

Si tratta quindi di un fascio proprio.

Se fosse improprio, lo studio sarebbe concluso.

Le generatrici si ottengono separando i termini che contengono il parametro k da quelli che non lo contengono e raccogliendo k.

La seconda generatrice non si può ottenere dall'equazione del fascio per alcun valore di k. Possiamo dire che si ottiene dall'equazione

$$\frac{1}{k}(ax + by + c) + (a'x + b'y + c') = 0 \text{ per } k \to \pm \infty.$$

La posizione reciproca delle due generatrici definisce la natura del fascio.

In alternativa, potremmo analizzare la natura del fascio anche considerando il coefficiente angolare dell'equazione iniziale: se varia con k il fascio è proprio, altrimenti è improprio.

# 2 Determiniamo il centro del fascio.

Per trovare il centro si possono intersecare due rette qualsiasi del fascio, per esempio le generatrici oppure le due rette parallele agli assi, che si ottengono annullando il coefficiente di x e quello di y nell'equazione iniziale.

Le rette del fascio si intersecano nel centro. Per trovare le sue coordinate mettiamo a sistema le equazioni delle generatrici:

$$\left\{\begin{array}{l} x + y + 2 = 0 \\ x + 2y + 1 = 0 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -y - 2 \\ -y - 2 + 2y + 1 = 0 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -y - 2 \\ y = 1 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -3 \\ y = 1 \end{array}\right. \rightarrow C(-3; 1).$$

# 3 Stabiliamo il senso di rotazione delle rette del fascio al crescere di k.

Per esempio, per k = -1 otteniamo la retta di equazione y = 1, che rappresentiamo nel piano cartesiano.

![img-113.jpeg](img-113.jpeg)

Per decidere se il senso di rotazione delle rette del fascio è orario o antiorario è sufficiente rappresentare, oltre alle due generatrici, una retta qualsiasi del fascio: si parte, per esempio, dalla seconda generatrice, che si ottiene per k → ±∞, e si osserva in quale verso si deve ruotare per incontrare valori crescenti di k.

La seconda generatrice u è origine di due semipiani: ne scegliamo uno e vediamo che al crescere di k le rette ruotano attorno al centro C in senso antiorario, come indica la freccia arancione.

ESERCIZI

259

Capitolo 4

PIANO CARTESIANO E RETTA

Studia i seguenti fasci di rette individuandone le generatrici e, se si tratta di un fascio proprio, determina il centro e il senso di rotazione delle rette del fascio al crescere di k.

573 $kx - (k - 2)y + 4k - 6 = 0$

577 $(2k + 2)x - (k + 1)y - k = 0$

574 $(2k - 1)x - ky - 8k + 2 = 0$

578 $4kx + 2(1 - k)y + 5k - 1 = 0$

575 $(3 - k)x + (k + 1)y + 4k - 8 = 0$

579 $kx + 3ky + 1 - k = 0$

576 $ky + 2 = (k - 1)x$

580 $y = 2kx + 4k - 1 + ky$

581 Dato il fascio di rette di equazione $(k + 1)x + 2(k + 1)y - 2 = 0$:

a. stabilisci se si tratta di un fascio proprio o improprio, individuando l'eventuale centro;
b. determinina la retta del fascio passante per \(A(1;0)\)
c. determinina la retta che, incontrando l'asse \(x\), forma con l'origine un segmento lungo \(\frac{1}{3}\).

[a) fascio improprio; b) $x + 2y - 1 = 0$; c) due soluzioni: $k = -7, k = 5$]

582 Dato il fascio di rette di equazione $(k - 3)x + (2k + 2)y + 1 - 3k = 0$, determina:

a. le equazioni delle generatrici e il centro;
b. le rette del fascio che incontrano l'asse \(x\) in un punto \(A\) tale che \(\overline{AO} = 3\)
c. il valore di \(k\) corrispondente alla retta parallela all'asse \(x\).

[a) $-3x + 2y + 1 = 0, x + 2y - 3 = 0, C(1; 1)$; b) $x - 4y + 3 = 0, x + 2y - 3 = 0$; c) $k = 3$]

583 Dimostra che le equazioni $(x - y + 6) + k(x + y + 4) = 0$ e $(2x - y + 11) + h(x + 5) = 0$ rappresentano (a meno delle rette escluse) lo stesso fascio. Quali sono, nei due casi, le equazioni delle rette escluse? Sia $r_k$ la retta che si ottiene per un generico valore di $k$ con la prima equazione. Calcola, in funzione di $k$, il valore da assegnare a $h$ nella seconda equazione per ottenere la stessa retta.

$$\left[ x + y + 4 = 0, x + 5 = 0; h = \frac{3k - 1}{1 - k} \right]$$

584 Scrivi l'equazione della retta appartenente al fascio proprio di rette di centro (1; 1) che forma con le rette $x + y + 1 = 0$ e $x = 2$ un triangolo di area 2. $[y = -2x + 3; y = -10x + 11]$

585 Determina la retta comune ai due fasci di equazioni $y = mx - 2m + 1$ e $(2 - k)x - (k + 1)y - 3 = 0$, e indica i relativi valori di $m$ e $k$. $[y = 2x - 3, m = 2, k = 0]$

586 Considera il triangolo individuato dai centri $A, B, C$ dei tre fasci di rette di equazioni:

$$y = m(x - 1), \quad kx - y + 3k - 1 = 0, \quad y = hx - 4h - 3.$$

a. Determinina l'area di \( ABC \).
b. Trova per quali valori di \( m \) le rette del primo fascio intersecano il triangolo.
c. Determinina il valore di \( m \) corrispondente alla retta del primo fascio che passa per il baricentro di \( ABC \).

[a) $\frac{15}{2}$; b) $m \le -1 \lor m \ge \frac{1}{4}$; c) $4$]

587 Scrivi l'equazione del fascio generato dalle rette di equazioni $2x + y - 1 = 0$ e $4x + 2y + 3 = 0$ e trova:

a. l'equazione della retta che passa per il punto \(P(2;0)\)
b. le equazioni delle rette che incontrano gli assi in due punti \(A\) e \(B\) tali che l'area del triangolo AOB sua 1;
c. l'equazione della retta perpendicularare alla retta di equazione \(x - 3y - 1 = 0\)

[a) $2x + y - 4 = 0$; b) $2x + y - 2 = 0, 2x + y + 2 = 0$; c) non esiste]

588 Studia il fascio di rette di equazione $(k + 1)x + (2 - 3k)y - 7 + 3k = 0$ e determina:

a. le rette paralleleagli assicartesiani;
b. la retta del fascio parallela alla retta di equazione \(y = x - 3\)
c. la retta passante per il punto \(A(4;1)\)
d. le rette che hanno distanza dall'origine uguate a \(\frac{4}{5}\sqrt{5}\)

[a) $y = 2; x = 3$; b) $x - y - 1 = 0$; c) $x + y - 5 = 0$; d) $2x - y - 4 = 0, 2x - 29y + 52 = 0$]

ESERCIT

260

FASCI DI RETTE

Paragrafo 7

589

Dato il fascio proprio di rette di equazione $mx - y + m + 2 = 0$, determina per quali valori di $m$ si hanno rette che intersecano il segmento di estremi $A(3; 6)$ e $B(-2; -4)$. Calcola poi l'area del triangolo $ABC$, con $C$ centro del fascio, e i valori di $m$ che individuano nel fascio la mediana $CM$ e l'altezza $CH$ del triangolo.

$$\left[ m \leq 1 \vee m \geq 6; 10; -\frac{2}{3}; -\frac{1}{2} \right]$$

590

Siano dati i due fasci di rette $r$: $hx - y + 3h = 0$ e $s$: $x - 2hy + h = 0$.

a. Determinina la retta comune ai due fasci.
b. Scrivi, al variate di \( h \), le coordinate del punto di intersezione \( P \) tra le rette \( r \in s \).
c. Trova il valore di \( h \) per cui il punto \( P \) coincide con l'origine degli assi.
d. Detti \(A\in B\) i rispetti centri dei fasci, trova l'area del triangolo ABO.

$$\left[ a) x - 6y + 3 = 0; b) P \left( \frac{-6h^2 + h}{2h^2 - 1}; \frac{h^2 - 3h}{2h^2 - 1} \right); c) 0; d) \frac{3}{4} \right]$$

591

Studia il fascio di rette di equazione $(2k + 1)x + (3 + k)y + 1 - 2k = 0$, determinando le equazioni delle generatrici e le coordinate del centro $C$. Calcola il valore di $k$ corrispondente alla retta:

a. parallela alla retta di equazione \(x + y - 1 = 0\)
b. passante per \(P(5;1)\)
c. passante per \(Q\), essendo \(Q\) un punto del primo quadrante, vertice del triangolo isoscele PCQ di base PC e area \(\frac{441}{40}\). [generatrici: \(x + 3y + 1 = 0, 2x + y - 2 = 0; C\left(\frac{7}{5}; -\frac{4}{5}\right)\); a) 2; b) -1; c) - \(\frac{67}{18}\)]

592

a. Studia le caratteristiche del fascio di rette di equazione \((2 + k)x - (1 + k)y - 5 - k = 0\) e individua il centro e le generatrici.
b. Determinina per quale valore del parametro \(k\) si ottiene la retta s del fascio perpendicolare alla retta di equazione \(x - 2y + 5 = 0\)
c. Individua la retta del fascio che forma un angolo di \(135^{\circ}\) con la direzione positiva dell'asse delle ascisse.
d. Stabilisci per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \(A(1;6)\in B(4;5)\)

$$\left[ a) C(4; 3), x - y - 1 = 0, 2x - y - 5 = 0; b) k = -\frac{4}{3}, s: y = -2x + 11; c) y = -x + 7; d) -\frac{3}{2} \leq k \leq -1 \right]$$

593

a. Studia il fascio di rette di equazione \((2 + k)x + (k - 1)y - 1 - 2k = 0\), individuandone il centro e le generatrici.
b. Trova per quali valori di \(k\) si ottengono le rette che formano con gli assi cartesiani un triangolo di area \(\frac{1}{2}\).
c. Calcola per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \(A(1; - 2)\in B(4;3)\)

$$\left[ a) C(1; 1), 2x - y - 1 = 0, x + y - 2 = 0; b) k = \frac{-5 \pm 3\sqrt{5}}{10}; c) k \leq -\frac{4}{5} \vee k \geq 1 \right]$$

594

a. Studia il fascio di rette di equazione \((k + 2)x - (1 - 2k)y + 5 = 0\),indicando con a la retta del fascio che non viene rappresentata da alcun valore di \(k\)
b. Determinina la retta \( r \) del fascio che interseca l'asse \( y \) nel punto avente per ordinata la soluzione positiva dell'equazione \( t^4 - 4t^2 = 0 \).
c. Individua la retta s del fascio di equazione \(x + (k + 1)y - 3 + k = 0\) perpendicular alla retta r.
d. Calcola l'area del quadrilatero convesso individuato delle rette \( r \), \( s \), \( a \) e alla retta \( b \) del secondo fascio che non corrisponde ad alcun valore di \( k \).

[a) fascio proprio di centro $(-2; 1)$, a: $x + 2y = 0$; b) $r$: $x - 2y + 4 = 0$; c) $s$: $2x + y - 7 = 0$; d) $12$]

595

a. Nel fascio di rette di equazione \(2x + 5y + k = 0\) individua le rette \(r\in s\) \((k_{r} < k_{s})\) che passano per i punti dell'asse \(y\) le cui ordinate sono soluzioni dell'equazione \(t^2 -2t - 8 = 0\)
b. Determinina i punti di intersezione \(A\) e \(B\) della retta \(8x + 5y + 10 = 0\) con le rette \(r\in s\)
c. Determinina, nel quarto quadrante, il punto \(C\) appartenente alla retta s tale che il segmento \(BC\) abbia lunghezza \(\sqrt{29}\).
d. Individua il quarto vertice \(D\) del parallelogramma \(ABCD\) e calculane perimetro e area.

$$\left[ a) 2x + 5y - 20 = 0, 2x + 5y + 10 = 0; b) A(-5; 6), B(0; -2); c) C(5; -4); d) D(0; 4); 2(\sqrt{29} + \sqrt{89}); 30 \right]$$

261

ESERCIZI

Capitolo 4

PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

# Fasci di rette

Prima di iniziare,
esercitati su laZ Esercizi

1 Dato il fascio di rette di equazione $$(2k - 1)x + (3 - k)y + 2k - 1 = 0$$, determina il centro e le generatrici. Trova poi le rette del fascio che, intersecando gli assi cartesiani, formano un triangolo rettangolo isoscele.

$$[C(-1; 0), x - 3y + 1 = 0, 2x - y + 2 = 0; x - y + 1 = 0, x + y + 1 = 0]$$

2 Sono dati due fasci di rette, $$r_A: x + (k - 1)y + 2 - 2k = 0$$ e $$r_B: (1 - k)x + (2k - 1)y - 1 = 0$$.

a. Verifica che sono entrambi propri e determina i centri \(A\in B\)
b. Detto \(C\) il punto di interszione fra le rette \(r_A\) e \(r_B\) per \(k = -1\), calcola l'area del triangolo ABC.
c. Trova il valore di \( k \) per cui \( r_A \) è parallela a \( r_B \) e il valore di \( k \) per cui \( r_A \) è perpendicularare a \( r_B \).

$$[a) A(0; 2), B(2; 1); b) \mathcal{A} = 14; c) k = 0, k = 1]$$

3 Dato il fascio improprio di rette contente la retta \(r\): \(3x - 2y + 3 = 0\), determina le rette \(s\) e \(t\) del fascio che distano \(\sqrt{13}\) da \(r\). Detti \(A\) e \(C\) i punti di intersezione di \(s\) e \(t\) con l'asse \(y\), calcola l'area del rettangolo che ha diagonale \(AC\) e due lati che giaccioni su \(s\) e su \(t\). \([3x - 2y + 16 = 0, 3x - 2y + 10 = 0; \mathcal{A} = 78]\)
4 Considera il fascio generato delle rette \(r\): \(2x + 3y = 0\) e \(s\): \(x - y - 5 = 0\).

a. Verifica che si tratta di un fascio proprio e ricavane il centro \(C\)
b. Scrivi l'equazione del fascio in modo che la retta s corrisponda al valore nullo del parametro \(k\) e che il fascio ruoti in senso antiorario al crescere di \(k\).
c. Determinina il valore di \(k\) per cui si ottiene la retta del fascio parallela alla bisettrice del II e IV quadrante.

$$[a) C(3; -2); b) (2k + 1)x + (3k - 1)y - 5 = 0; c) k = 2]$$

5 Considera il fascio di rette di equazione $$2(k + 1)x - (k + 1)y + 2 - 4k = 0$$, con $$k \neq -1$$, e il segmento di estremi $$A(1; 3)$$ e $$B(5; 1)$$.

a. Determinina i valori di \(k\) per cui le rette intersecano il segmento \(AB\).
b. Esiste una retta del fascio che passa per il punto medio di \(AB\)?

$$[a) k \leq -\frac{11}{5} \vee k \geq \frac{1}{5}; b) \text{ no}]$$

6 Determina per quali valori di $$k$$ la retta del fascio di equazione $$(k - 3)x + (k - 1)y + 3 - 2k = 0$$, intersecando gli assi cartesiani, forma un triangolo rettangolo di area 2.

$$\left[ k = \frac{3}{4} \vee k = \frac{7 \pm \sqrt{7}}{4} \right]$$

7 Studia il fascio di rette di equazione $$(k - 1)x + 2ky - 3k + 1 = 0$$ e determina le equazioni delle rette generatrici, le coordinate del suo centro $$C$$ e l'equazione della retta del fascio che non viene rappresentata da alcun valore di $$k$$. Calcola poi i valori di $$k$$ per cui la retta del fascio:

a. interseca il segmento di estremi \(A(-3;2)\) e \(B(0;3)\)
b. passa per il baricentro del triangolo \( ABC \)
c. è parallela alla retta del fascio di equazione \( y = kx + 3k + 2 \)
d. è perpendicularare alla retta del fascio di equazione \( y = kx + 3k + 2 \).

$$\left[ x + 2y - 3 = 0, x = 1, C(1; 1), x + 2y - 3 = 0; a) k \leq -\frac{1}{3} \vee k \geq 2; b) k = -5; c) k = \frac{1}{2} \vee k = -1; d) k = 3 \right]$$

8 FISICA OTTICA GEOMETRICA Lungo le due direzioni degli assi cartesiani $$x$$ e $$y$$ del sistema di riferimento rappresentato a lato sono posti due specchi piani perpendicolari.

![img-114.jpeg](img-114.jpeg)

Nel punto $$S(4; 7)$$ è posta una sorgente luminosa puntiforme che irraggia luce in ogni direzione.

a. Ricava un'equazione del fascio proprio delle rette che descrivono le direzioni dei raggi luminosi prodotti alla sorgente \(S\)
b. Determinina l'equazione della retta del fascio che corrisponde alla direzione del raggio luminoso \(r\) che incide con un angolo di \(45^{\circ}\) sullo specchio verticale.
c. Ricava le equazioni delle due rette che corrispondono alle direzioni del raggio \(r^{\prime}\), riflesso di \(r\) dallo specchio verticale, e di \(r^{\prime}\), riflesso di \(r^{\prime}\) dallo specchio orizzontale. Qual è la posizione reciproca tra \(r^{\prime}\) e \(r^{\prime \prime}\)

$$[a) mx - y - 4m + 7 = 0; b) y = x + 3; c) y = -x + 3, y = x - 3, \text{ sono parallele}]$$

ESERCIZI

262

MATEMATICA PER LE STEM

MATEMATICA PER LE STEM

# Terremoti e piano di Benioff in sezione

SCIENZE DELLA TERRA

I geologi studiano fenomeni che talvolta hanno effetti catastrofici, come terremoti ed eruzioni vulcaniche.

Tra i fenomeni geologici più importanti c'è la subduzione, cioè il progressivo slittamento di una placca di litosfera al di sotto di un'altra.

Quando questo avviene, la placca in subduzione viene trascinata in profondità lungo un piano inclinato, chiamato piano di Benioff.

Nella zona di subduzione si registrano numerosi terremoti e nel piano di Benioff si allineano gli ipocentri, i punti in profondità da cui si propagano i sismi.

![img-115.jpeg](img-115.jpeg)

ESEMPIO Rappresentiamo in un piano cartesiano la sezione di una placca di subduzione. In sezione il piano di Benioff è rappresentato da un segmento della retta g, sulla quale si trovano gli ipocentri I₁ e I₂.

![img-116.jpeg](img-116.jpeg)

Nell'origine O si trova una città. L'asse x rappresenta la superficie terrestre e contiene il punto S in cui inizia la subduzione. Gli epicentri E₁ ed E₂ sono le proiezioni sull'asse x degli ipocentri.

Troviamo a quale distanza dalla città ha inizio la subduzione.

Usiamo la formula per determinare l'equazione della retta passante per due punti:

$$\frac{y + 60}{-78 + 60} = \frac{x - 200}{224 - 200} \rightarrow y = -0,75x + 90. \text{ — retta } I_1 I_2$$

Per y = 0, otteniamo il punto in cui ha inizio la subduzione rispetto alla città O(0; 0):

$$x_5 = \frac{90}{0,75} = 120. \text{ — ascissa di S}$$

Equazione della retta passante per I₁(x₁; y₁) e I₂(x₂; y₂):

$$\frac{y - y_1}{y_2 - y_1} = \frac{x - x_1}{x_2 - x_1}.$$

La zona di subduzione ha inizio a 120 km dalla città.

Il coefficiente angolare di I₁I₂ è m = -0,75. Da questo valore ricaviamo un'informazione in più: il piano di Benioff ha un'inclinazione del 75%, verso il basso rispetto alla superficie terrestre.

# ESERCIZI

RISOLVI CON PYTHON Scrivi un programma per calcolare la profondità di un sisma localizzato sul piano di Benioff dell'esempio precedente, quando è notà la distance del suo epicentro da O. Tieni presente che otre i 700 km di profondità i fenomeni sismici scompaiano.
2 Molti fenomeni di subduzione avengono negli oceani e i terremoti che ne derivano possono causare pericolosi tsunami. Aiutandoti con una ricerca in rete, crea un'infografica sul rischio tsunami. Condense le informazioni più rilevanti in frasi concise e presta attenzione all'aspetto grafico, scegliendo fotografie, disegni e icone che rendano più accattivante la tua infografica e ne incoraggino la lettura. Puoi fare esta attività anche in gruppo (2-3 persone).

ESERCIZI

263

Capitolo 4 PIANO CARTESIANO E RETTA

# FONDAMENTALI ALLA PROVA

Fai questi esercizi anche su laZ Esercizi

PUNTI NEL PIANO CARTESIANO Determina per quali valori di \(k\) il punto \(P(k - 3;8 - k)\) appartiene:
a. all'asse delle ordinate; b. al secondo quadrante.
2 DISTANZA FRA DUE PUNTI Determina il perimetro del triangolo di vertici \(A(-3;3),B(1;0)\in C(1;2).\)
3 AREA DI UN POLIGONO Calcola l'area del quadrilatero di vertici \(A(2; - 2),B(1;9),C(-2;3)\in D(-1; - 4).\)
4 PUNTO MEDIO DI UN SEGMENTO Associa ogni coppi di punti al punto medio del segmento di cui sono estremi.

a. $A(3; -2)$ e $B(-5; 4)$.

b. $A(-3; 5)$ e $B(3; 7)$.

c. $A(-7; 1)$ e $B(3; 3)$.

d. $A(5; 3)$ e $B(7; -3)$.

1. $M(-2; 2)$.

2. $M(0; 6)$.

3. $M(6; 0)$.

4. $M(-1; 1)$.

5 BARICENTRO DI UN TRIANGOLO Determina le coordinate del baricentro del triangolo di vertici \(A(6; - 2),B(1;3)\) e \(C(2; - 4)\)
6 EQUAZIONE DELLA RETTA La retta di equazione \(3x - 5y + 6 = 0\)

A forma un angolo ottuso con l'asse \(x\)
B interseca l'asse \(y\) in un punto di ordinata negativa.
\(\boxed{\mathbb{C}}\) passa per l'origine degli assi.
D passa per il punto \(P(-12; - 6)\)

![img-117.jpeg](img-117.jpeg)

7 DAL GRAFICO ALL'EQUAZIONE Scrivi le equazioni delle rette $s$, $t$ e $w$ rappresentate nel grafico.

8 RETTE PARALLELE E PERPENDICOLARI Stabilisci quali rette sono parallele tra loro e quali perpendicolari tra loro.

a. \(y = -7x + 3\)
b. \(14x + 2y + 3 = 0\)
c. \(x - 7y + 2 = 0\)
d. \(7x - y + 5 = 0\)

9 DETERMINARE L'EQUAZIONE DI UNA RETTA Determina l'equazione della retta passante per il punto \(P(-1;6)\) e di coefficiente angolare \(-4\)
10 DETERMINARE L'EQUAZIONE DI UNA RETTA Scrivi l'equazione della retta che passa per i punti di coordinate \((5; -2)\in (3;8)\)
11 DETERMINARE L'EQUAZIONE DI UNA RETTA Determina l'equazione della retta passante per \(A(3;1)\) e perpendicolare alla retta che passa per \(B(-2;0)\in C(-4;6)\).
12 DISTANZA DI UN PUNTO DA UNA RETTA Calcola la distanza del punto \(Q(-3;2)\) alla retta di equazione \(4x + 3y - 1 = 0\)
13 FASCI DI RETTE Stabilisci se le seguenti affirmazioni sono vere o false.

a. Il fascio improprio di rette contenti la retta \(2y + 14x + 7 = 0\) ha equazione \(y = -7x + q\)
b. L'equazione \( y = m(x - 5) \) rappresenta, al variate di \( m \), tutte le rette passanti per \( A(5;0) \).
c. L'equazione \(3kx - 2ky - 4 = 0\) , con \(k\neq 0\) , rappresenta un fascio improprio di rette.
d. L'equazione \(x - y + k(1 - x) = 0\) rappresenta un fascio proprio di centro (1; 1).

VERIFICA LE COMPETENZE

264

COMPETENZE ALLA PROVA

# COMPETENZE ALLA PROVA

![img-118.jpeg](img-118.jpeg)

laZ Tutor di matematica

https://tutor.zanichelli.it/matematica

Se hai acquistato l'edizione con Tutor, allenati con esercizi e percorsi interattivi.

![img-119.jpeg](img-119.jpeg)

RECUPERO

INVALSI

GARE

ESAME

UNIVERSITÀ

## Argomentare e dimostrare

1 Dimostra che, se due fasci di rette hanno in comune due rette distinte, alla rappresentano lo stesso fascio.
2 Considera i segmenti \(OP\) di estremi \(O(0;0)\) e \(P(k;k + 1)\). Al variate di \(k\) l'insieme degli assi dei segmenti \(OP\) forma un fascio di rette? Giustifica la risposta e, in caso sa affermativa, scrivi l'equazione del fascio. [no]
3 Dimostra che il triangolo formato da una retta \( ax + by + c = 0 \) (con \( a \neq 0 \) e \( b \neq 0 \)) con gli assi cartesiani ha sempre area uguali a \( \frac{c^2}{2|ab|} \).
4 Considera un triangolo rettangolo qualsiasi e, fissato un opportuno sistema di riferimento, dimostra che il punto medio dell'ipotenusa è equidistante dai tre vertici.

5 Dimostra che le rette su cui giacciono i lati di un angolo la cui bisettrice coincide con l'asse \(y\) hanno coefficienti angolari opposti.
E dato un triangolo isoscele di baricentro \(O(0;0)\) e vertice \(P(0;k)\). Dimostra che al variate di \(k\neq 0\) la retta su cui giace la base del triangolo appartiene al fascio improprio di equazione \(y = -\frac{k}{2}\).
7 Dimostra analiticamente che congiungendo i punti medi di due lati di un triangolo si ottiene un segmento parallelo al terzo lato e congruente alla meta diesso.
8 Dato un trapezio qualsiasi, fissa un opportuno si stema di riferimento e verifica che il segmento congiungente i punti medi dei lati obliqui è congruente alla semisomma delle due basi.

9 Dimostra che la distanza $d$ tra due rette parallele, $ax + by + c = 0$ e $a'x + b'y + c' = 0$, con $a = a'$ o $b = b'$, è data da: $d = \frac{|c - c'|}{\sqrt{a^2 + b^2}}$. Calcola la distanza tra le due rette $4x + y - 10 = 0$ e $y = -4x + 28$. $\left\{\frac{18\sqrt{17}}{17}\right\}$

10 VERO O FALSO?

a. Tutte le rette di un fascio proprio hanno la stessa direzione.
b. La retta \( y = -2x \) appartiene al fascio improprio di equazione \( 4x + 2y - k = 0 \).
c. L'equazione \( y = mx + 1 \) rappresenta il fascio proprio con centro in (0; 1).
d. Nel fascio di equazione \( y = (k - 2)x + k - 1 \) la retta parallela all'asse \( y \) si ottiene per \( k = 2 \).

V F
V F
V F
V F

## Analizzare e interpretare dati e grafici

11 LEGGI IL GRAFICO Scrivi le equazioni delle funzioni rappresentate nei grafici.

![img-120.jpeg](img-120.jpeg)

![img-121.jpeg](img-121.jpeg)

![img-122.jpeg](img-122.jpeg)

265

VERIFICA LE COMPETENZE

Capitolo 4 PIANO CARTESIANO E RETTA

# LEGGI IL GRAFICO

12 Trova le equazioni delle rette a, b, c della figura.

13 Il triangolo ABC della figura è isoscele?

![img-123.jpeg](img-123.jpeg)

![img-124.jpeg](img-124.jpeg)

[si]

Disegna il grafico delle seguenti funzioni.

14 $$y = \begin{cases} 3 & \text{se } x < -1 \\ -3|x| + 6 & \text{se } -1 \le x < 2 \\ 3x - 6 & \text{se } x \ge 2 \end{cases}$$

15 $$y = \sqrt{4 - 4x + x^2}$$

16 $$y = \begin{cases} \left| \frac{1}{2}x + 4 \right| & \text{se } x < 0 \\ x + 2 & \text{se } 0 \le x < 2 \\ 4 & \text{se } x \ge 2 \end{cases}$$

17 $$y = \frac{\sqrt{(x-3)^2}}{3-x} + x$$

18 LEGGI IL GRAFICO Descrivi con un sistema di disequazioni la parte di piano evidenziata nella figura e poi calcolane l'area. Tracciata per C la parallela a DA che interseca il lato AB in E, calcola il rapporto tra le aree di AECD e EBC.

19 a. Rappresenta graficamente la curva di equazione $$\frac{1}{2}|x|-|y|+2=0$$.

b. Nello stesso sistema di riferimento rappresenta anche la curva di equazione

![img-125.jpeg](img-125.jpeg)

$$2|x|-|y|-4=0.$$

c. Calcola l'area della parte di piano racchiusa dai due grafici.
d. Indica come il secondo grafico cui èsso ottenuto a partire dal primo.

[c] 32]

Rappresenta nel piano l'insieme delle soluzioni dei seguenti sistemi di disequazioni.

20 $$\begin{cases} y \le 3 \\ 2y + 2 \ge x \\ \frac{3}{2}x \ge 3 - y \\ x - 4 < 0 \end{cases}$$

21 $$\begin{cases} y \ge |2-x| \\ x > 1 \\ y - 4 \le 0 \end{cases}$$

22 $$\begin{cases} y - x - 1 \ge 0 \\ 2y < x + 4 \\ y \ge -x - 1 \end{cases}$$

23 LEGGI IL GRAFICO Trova quali valori può assumere il coefficiente angolare delle rette per A in modo che attraversino il triangolo colorato. Determina l'equazione della retta parallela all'asse y che divide il triangolo in due parti equivalenti.

![img-126.jpeg](img-126.jpeg)

$$\left[ \frac{1}{6} < m < \frac{2}{3}; x = 6 - 3\sqrt{2} \right]$$

VERIFICA LE COMPETENZE

266

COMPETENZE ALLA PROVA

# Risolvere problemi

24

a. Verifica che il triangolo di vertici \(A(5;4)\) \(B(-1;6)\in C(7; - 2)\) e isoscele sulla base \(BC\)
b. Dimostra che le equazioni dell'altezza e della mediana relative a \(BC\) coincidono.
c. Trova il baricentro, l'ortocentro e il circocentro del triangolo.

$$\left[ c \left( \frac{11}{3}; \frac{8}{3} \right), (11; 10), (0; -1) \right]$$

25

Determina i vertici del quadrato PQRS che ha come diagonale il segmento di estremi $P(1; -3)$ e $R(-5; 1)$.

$$[Q(0; 2); S(-4; -4)]$$

26

a. Scrivi l'equazione della retta \( r \) passante per i punti \( A(4;0) \in B(0;6) \) e l'equazione della retta \( s \), parallela alla bisettrice del primo e terzo quadrante, passante per \( C(-1;0) \).
b. Nel fascio di rette generato da \( r \) e \( s \) determina la retta di coefficiente angolare \( -\frac{7}{8} \) e trova su diessa il punto \( D \) di ordinata \( -4 \). Calcola l'area del quadrilatero ABCD.
c. Verifica che il triangolo \(ABD\) è isoscele e determina il circocentro \(E\).

$$[a) \ r: 2y + 3x - 12 = 0, \ x: x - y + 1 = 0; \ b) \ 7x + 8y - 38 = 0, \ D(10; -4); \ 25; \ c) \ E(17; 13)]$$

27

a. Studia il fascio di rette di equazione \((k - 1)x + (1 - k)y + 2 - k = 0\),indicando la retta \(r\) del fascio che non viene rappresentata da nessun valore del parametro \(k\)
b. Individua le coordinate dei vertici \(C_1\) e \(C_2\) dei due triangoli isosceli, di area 24, aventi base \(AB\) con \(A\) e \(B\) appartenenti alla retta \(r\) e con l'ascissa che è soluzione dell'equazione \(x^2 - 2x - 3 = 0\).
c. Calcola l'area del quadrilatero \(AC_{1}BC_{2}\)

[a) fascio di rette parallele alla bisettrice del primo e terzo quadrante;

$$x - y - 1 = 0; \ b) \ C_1(-5; 6), \ C_2(7; -6); \ c) \ 48]$$

28

L'equazione di una retta che non passa per l'origine e non è parallela agli assi può sempre essere scritta nella forma $\frac{x}{p} + \frac{y}{q} = 1$, detta equazione segmentaria della retta.

a. Spiega il significato dei coefficienti \( p \) e \( q \) dell'equazione e indica la loro relazione con i coefficienti \( a, b \) e \( c \) dell'equazione della retta in forma implicita \( ax + by + c = 0 \).
b. Scrivi l'equazione segmentaria della retta di equazione \(2x - 3y + 6 = 0\)

$$\left[ b \right] - \frac{x}{3} + \frac{y}{2} = 1]$$

29

a. Studia il fascio di rette di equazione \((2k + 1)x + (k - 1)y + 8k + 7 = 0\) e individua la retta \(r\) del fascio che non viene rappresentata da alcun valore del parametro reale \(k\).
b. Determinina la retta s del fascio parallela alla retta di equazione \(5x + y = 0\)
c. Trova le rette \(t_1\) e \(t_2\) del fascio che formano con gli assi cartesiani nel secondo quadrante un triangolo di area 36.
d. Stabilisci per quali valori del parametro \(k\) le rette del fascio dato intersecano il segmento di estremi \(A(-8;0)\in B(-3;5)\)

[a) fascio proprio di rette di centro $(-5; 2), 2x + y + 8 = 0; \ b) \ 5x + y + 23 = 0;$

$$c) \ t_1: 2x - y + 12 = 0; \ t_2: 2x - 25y + 60 = 0; \ d) \ k \le -\frac{1}{8} \lor k \ge \frac{1}{7}]$$

30

Sono dati i punti $A(-2; 1), B(1; -1), D(2; 7)$ e la retta $r$ di equazione $2x - y - 7 = 0$.

a. Verifica che il triangolo \(ABD\) è rettangolo in \(A\).
b. Trova un punto \(C\) su \(r\) in modo che il quadrilatero \(ABCD\) sua un trapezio avente \(BC\) e \(AD\) come basi.
c. Calcola l'area del trapezio trovato. [b) C(9; 11); c) 39]

31

Siano $A(1; 3), B(4; 1), C(3; 5)$ i vertici di un triangolo. Determina le coordinate del baricentro e del circocentro e l'area del triangolo. Determina sul lato $AB$ un punto $P$ in modo che il rapporto tra l'area dei triangoli

$APC$ e $PBC$ sia $\frac{4}{5}$.

$$\left[ \left( \frac{8}{3}; 3 \right), \left( \frac{31}{10}; \frac{29}{10} \right); 5; P \left( \frac{7}{3}; \frac{19}{9} \right) \right]$$

32

Siano $r, s, t$ rispettivamente le rette di equazioni $y = 2, 4x - 3y + 2 = 0$ e $x + y - 10 = 0$. Si sa che $r$ e $s$ rappresentano le rette sulle quali giacciono due lati di un parallelogramma e che $t$ è la retta alla quale appartiene una diagonale. Determina i vertici, il perimetro e l'area del parallelogramma. Verifica inoltre che congiungendo i punti medi dei lati si ottiene un parallelogramma e calcola la sua area.

$$[(1; 2), (8; 2), (11; 6), (4; 6); 24; 28; 14]$$

VERIFICA LE COMPETENZE

267

Capitolo 4

PIANO CARTESIANO E RETTA

VERIFICA LE COMPETENZE

33 Del triangolo ABC sono noti i vertici A(1; 1) e B(15; 8) e l'incentro F(3; 7). Determina le coordinate del vertice C. Verifica poi che il triangolo è rettangolo e trova il circocentro D.

$$\left[ C \left( - \frac { 1 7 } { 3 } ; \frac { 4 3 } { 3 } \right) ; D \left( \frac { 1 4 } { 3 } ; \frac { 6 7 } { 6 } \right) \right]$$

34 Sono dati i punti A(2; 3) e B(4; 0). Determina l'equazione del luogo geometrico dei punti P tali che $$\left| \overline { { P A } } ^ { 2 } - \overline { { P B } } ^ { 2 } \right| = 2$$ e calcola il perimetro e l'area del trapezio che il luogo forma con gli assi cartesiani.

$$\left[ 4 x - 6 y - 5 = 0 \lor 4 x - 6 y - 1 = 0 ; \frac { 3 \sqrt { 1 3 } + 1 0 } { 6 } ; \frac { 1 } { 2 } \right]$$

# Costruire e utilizzare modelli

![img-127.jpeg](img-127.jpeg)

35 EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA Serena e Helene cercano il centro sportivo più conveniente per le loro partite a tennis. Stanno valutando tre centri che propongono le seguenti tariffe:

A: \(10\in\) per agli ora di utilizzo del Campo da tennis;
B: \(10\in\) per l'accesso al Campo e \(5\in\) all'ora;
C: \(12\in\) per la prima ora e poi \(5\in\) per agli ora après la prima. Fatta eccezione per i \(12\in\) per la prima ora della tariffa C, tutte le altre tariffe orarie sono frazionabili.

a. Scrivi le espressioni delle tre funzioni del costo al variate del tempo di utilizzo del Campo.
b. Per quale tempo di utilizzo Serena e Helene pagherebbero la stessa cifra al centro A e al centro C?
c. Fra i tre centri sportivi ce n'e uno che non conviene scegliere qualunque sua la durata dell'utilizzo del campo. Quale?

$$\left[ \begin{array} { l l } { \mathrm { a ) } \mathrm { A : } y = 1 0 x , \mathrm { B : } y = 1 0 + 5 x , \mathrm { C : } y = \left\{ \begin{array} { l l } { 1 2 } & { \mathrm { s e } 0 \leq x \leq 1 } \\ { 5 x + 7 } & { \mathrm { s e } x > 1 } \end{array} \right. ; \mathrm { b ) } 1 \mathrm { o r a } \mathrm { e } 2 4 \mathrm { m i n } ; \mathrm { c ) } \mathrm { B } } \end{array} \right]$$

36 FISICA MOTO NEL PIANO Una barca salpa dal molo P, rappresentato in figura, con una velocità v di 20 km/h, in direzione est. Un vento diretto verso nord, con velocità costante w di 30 km/h, devia la traiettoria della barca. Determina le coordinate del punto Q in cui si troverà la barca dopo 30 minuti.

![img-128.jpeg](img-128.jpeg)

![img-129.jpeg](img-129.jpeg)

$$\left[ x _ { Q } = 1 3 \mathrm { k m } ; y _ { Q } = 1 9 \mathrm { k m } \right]$$

37 FISICA MOTO NEL PIANO Durante un allenamento si chiede ai giocatori di correre a zigzag da A a O seguendo il percorso indicato in figura, con i tratti rettilinei a due a due paralleli, e poi di tornare in A lungo la linea di bordo campo.

Se i giocatori tengono una velocità media di 12,5 km/h, quanto tempo impiegano per completare il percorso due volte?

[5 minuti e 10 secondi]

# Accetti la sfida?

Altri esercizi simili su la2 Tutor di matematica

38 Al variare del parametro reale k, in quanti punti la retta di equazione

$$( 2 + k ) x + ( 3 + k ) y - 3 k - 6 = 0$$

interseca i lati del quadrilatero concavo di estremi A(2; 3), B(2; 0), C(1; 2) e D(0; 2)?

$$\left[ 1 \text { p u n t o : } k = - 2 \lor k = - \frac { 7 } { 2 } ; 2 \text { p u n t i : } k < - \frac { 7 } { 2 } \lor - 2 < k < 0 ; 3 \text { p u n t i : } k = 0 ; 4 \text { p u n t i : } k > 0 \right]$$

268

PROVE DI VERIFICA

# PROVE DI VERIFICA

Risultati delle prove

# Prova A

1 ora

Il tuo punteggio: ... / 100

1 Sul segmento di estremi $A(4; -1)$ e $B(8; -4)$ determina un punto $P$ tale che $\overline{PA} = 3\overline{PB}$.

2 Rappresenta i grafici delle seguenti funzioni:

a. $y = \frac{\sqrt{x^2}}{x} + |x - 3|$

b. $y = \begin{cases} |2x + 1| & \text{se } x \le 0 \\ -x + 3 & \text{se } x > 0 \end{cases}$

3 Dati i punti $A(2k; 1 - 2k)$, $B(k + 3; k - 3)$ e $C(4 - k; k)$, trova per quali valori di $k \in \mathbb{R}$:

a. il punto medio di \(AB\) appartiene all'asse \(x\)
b. il segmento \(AC\) non interseca l'asse \(y\)
c. il baricentro del triangolo \( ABC \) si trovava sulla retta di equazione \( y = -x + 1 \)
d. \(\overline{AB} <  \sqrt{5}.\)

4 Studia il fascio di rette di equazione $x - 4ay + 2ax + 2 = 0$ e trova per quali valori di $a \in \mathbb{R}$ la retta corrispondente del fascio:

a. ha coefficiente angolare positivo;
b. interseca l'asse \(x\) in un punto di ascisa negativa;
c. è perpendicularare alla retta che passa per \((0;1)\) e \((-2;3)\).

5 Trova l'area della figura individuata mettendo a sistema le disequazioni:

$y - 3 \le 0; \quad y \le 6 - x; \quad x + y \ge 0; \quad y + 12 > 2x.$

# Prova B

1 ora

Il tuo punteggio: ... / 100

1 REALTÀ E MODELLI Un giardiniere deve disporre sei cespugli di rose in modo che ciascuno disti 5 dm dai due adiacenti e dal centro $O$ del giardino.

![img-130.jpeg](img-130.jpeg)

Per aiutarsi, scava per terra due piccoli solchi, come se fossero assi cartesiani di origine $O$. Posto il primo cespuglio in $(-5; 0)$, dove pianterà gli altri?

2 Il parallelogramma $ABCD$ ha il vertice $A(1; 4)$ e il punto di incontro delle diagonali $P(4; 3)$. Il vertice $B$ è sull'asse $x$ e sulla retta di equazione $2y - x - 2 = 0$. Trova i vertici $B, C, D$, il perimetro e l'area del parallelogramma.

3 Trova l'equazione della retta $t$ comune ai due fasci

$r: (3h - 1)x + 2hy - 6 = 0 \quad \text{e} \quad s: kx + (k - 1)y - k = 0, \quad \text{con } h, k \in \mathbb{R},$

e calcola l'area del triangolo formato da $t$ e dagli assi coordinati. Verifica poi che l'ortocentro, il baricentro e il circocentro del triangolo sono allineati.

![img-131.jpeg](img-131.jpeg)

4 LEGGI IL GRAFICO Scrivi le equazioni delle rette $r, s$ e $t$ rappresentate nel grafico e indica le coordinate dei punti $A, B, C$.

5 Rappresenta il grafico della funzione

$y = \begin{cases} |x - 1| & \text{se } x < 2 \\ -\frac{1}{2}x + 2| + 1 & \text{se } x \ge 2 \end{cases}$

VERIFICA LE COMPETENZE

269

Capitolo 4

PIANO CARTESIANO E RETTA

# VERSO L'ESAME

# Problemi di matematica

# RISOLVIAMO UN PROBLEMA

# Un trapezio e un fascio di rette

Consideriamo il trapezio ABCD in figura e la retta di equazione y = mx, con m ≥ 0.

![img-132.jpeg](img-132.jpeg)

a. Indichiamo per quali valori di \( m \) la retta interseca il segmento \( DC \) e calculiamo l'area del triangolo \( DEF \) in funzione di \( m \).
b. Troviamo per quale valore di \( m \) l'area di \( DEF \) è \( \frac{1}{2} \) e per tale valore troviamo il perimetro di \( DEF \) e l'ortocentro.
c. Calcoliamo il valore di \( m \), con \( 0 \leq m \leq 1 \), per cui la retta di equazione \( y = mx \) divide il trapezio ABCD in due poligoni equivalenti.
d. Se l'angolo \( \alpha \) che la retta forma con l'asse \( x \) è di \( 30^{\circ} \), quanto valgono le aree dei due poligoni in cui la retta divide il trapezio?

a. Troviamo i valori richiesti per il parametro m e calcoliamo l'area di DEF in funzione di m.

Troviamo le equazioni delle rette passanti per l'origine che passano per C e D.

Retta per C(6; 6): 6 = m · 6 → m = 1 → y = x.

Retta per D(2; 4): 4 = m · 2 → m = 2 → y = 2x.

La retta y = mx interseca CD per 1 ≤ m ≤ 2.

Troviamo le coordinate di F intersecando le rette DC ed EF.

La retta DC ha equazione:

$$\frac{y-6}{4-6} = \frac{x-6}{2-6} \rightarrow \frac{y-6}{-2} = \frac{x-6}{-4} \rightarrow y = \frac{x-6}{2} + 6 \rightarrow y = \frac{x+6}{2}.$$

Risolviamo il sistema seguente.

$$\left\{\begin{array}{l} y=mx \\ y=\frac{x+6}{2} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ mx=\frac{x+6}{2} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ x(2m-1)=6 \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ x=\frac{6}{2m-1} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=\frac{6m}{2m-1} \\ x=\frac{6}{2m-1} \end{array}\right.\rightarrow F\left(\frac{6}{2m-1}; \frac{6m}{2m-1}\right), \quad \text { con } 1 \leq m \leq 2.$$

Troviamo le coordinate di E intersecando le rette AD ed EF.

$$\left\{\begin{array}{l} y=mx \\ x=2 \end{array}\right.\rightarrow\left\{\begin{array}{l} x=2 \\ y=2m \end{array}\right.\rightarrow E(2; 2m)$$

Calcoliamo $$\overline{DE} = y_D - y_E = 4 - 2m$$ e la distanza h fra F e DE:

$$h = x_F - x_D = \frac{6}{2m-1} - 2 = \frac{6-4m+2}{2m-1} = \frac{8-4m}{2m-1}.$$

L'area del triangolo DEF è:

$$\frac{1}{2} \overline{DE} \cdot h = \frac{1}{2}(4-2m) \cdot \frac{8-4m}{2m-1} = 4 \frac{(2-m)^2}{2m-1}, \quad \text { con } 1 \leq m \leq 2.$$

b. Troviamo il valore richiesto per m e calcoliamo perimetro e ortocentro di DEF.

Poniamo l'area di DEF = 1/2.

$$4 \frac{(2-m)^2}{2m-1} = \frac{1}{2} \rightarrow 8(4+m^2-4m) = 2m-1 \rightarrow 8m^2-34m+33 = 0 \rightarrow$$

$$m = \frac{17 \pm \sqrt{25}}{8} = \frac{17 \pm 5}{8} \rightarrow m_1 = \frac{3}{2}, m_2 = \frac{11}{4}; \text { solo } m_1 = \frac{3}{2} \text { è accettabile, perché } m_2 > 2.$$

Calcoliamo il perimetro del triangolo DEF.

Per $$m = \frac{3}{2} \rightarrow F\left(3; \frac{9}{2}\right)$$ ed E(2; 3).

VERSO L'ESAME

270

VERSO L'ESAME

$$\overline{DE} = 4 - 3 = 1$$

$$\overline{DF} = \sqrt{(3 - 2)^2 + \left(\frac{9}{2} - 4\right)^2} = \sqrt{1 + \frac{1}{4}} = \frac{\sqrt{5}}{2}$$

$$\overline{EF} = \sqrt{(3 - 2)^2 + \left(\frac{9}{2} - 3\right)^2} = \sqrt{1 + \frac{9}{4}} = \frac{\sqrt{13}}{2}$$

Il perimetro è $1 + \frac{\sqrt{5}}{2} + \frac{\sqrt{13}}{2}$.

- Determiniamo ora l'ortocentro $H$ di $DEF$ intersecando le altezze da $E$ e $F$.

La retta passante per $F$ e perpendicolare a $DE$ ha equazione $y = \frac{9}{2}$.

La retta passante per $E$ e perpendicolare alla retta $DF$ (che ha coefficiente angolare $\frac{1}{2}$) ha equazione:

$$y - 3 = -2(x - 2) \rightarrow y = -2x + 7.$$

Le coordinate di $H$ si ottengono risolvendo il seguente sistema.

$$\begin{cases} y = \frac{9}{2} \\ y = -2x + 7 \end{cases} \rightarrow \begin{cases} y = \frac{9}{2} \\ 2x = 7 - \frac{9}{2} \end{cases} \rightarrow x = \frac{5}{4} \rightarrow H\left(\frac{5}{4}; \frac{9}{2}\right)$$

c. Cerchiamo $m$ in modo che la retta di equazione $y = mx$ divida $ABCD$ in due poligoni equivalenti.

- Se $0 \le m \le 1$, la retta di equazione $y = mx$ interseca il segmento $CB$ in $G$ e il segmento $DA$ in $L$.

Troviamo le coordinate di $G$:

$$\begin{cases} y = mx \\ x = 6 \end{cases} \rightarrow \begin{cases} y = 6m \\ x = 6 \end{cases} \rightarrow G(6; 6m).$$

![img-133.jpeg](img-133.jpeg)

$L$ ha invece coordinate $(2; 2m)$.

- L'area del trapezio $ABCD$ è:

$$\frac{(\overline{BC} + \overline{AD}) \cdot \overline{AB}}{2} = \frac{(6 + 4) \cdot 4}{2} = 20.$$

- L'area del trapezio $ABGL$ è:

$$\frac{(\overline{BG} + \overline{AL}) \cdot \overline{AB}}{2} = \frac{(6m + 2m) \cdot 4}{2} = 16m, \quad \text{con } 0 \le m \le 1.$$

- Se la retta di equazione $y = mx$ divide il trapezio in due poligoni equivalenti, deve essere:

$$16m = \frac{20}{2} \rightarrow m = \frac{5}{8}, \text{valore accettabile.}$$

d. Calcoliamo le aree dei due poligoni se $\alpha = 30^\circ$.

Se $\alpha = 30^\circ$, allora è $G\left(6; 6\frac{\sqrt{3}}{3}\right)$ e $m = \frac{\sqrt{3}}{3}$, pertanto $ABGL$ ha area $16\frac{\sqrt{3}}{3}$ e $LGCD$ ha area $20 - 16\frac{\sqrt{3}}{3}$.

39

# LEGGI IL GRAFICO

![img-134.jpeg](img-134.jpeg)

a. Nel triangolo \( ABC \) della figura \( G \) è il baricentro. Determina le coordinate di \( C \) e scrivi l'equazione della retta \( DE \) che passa per \( C \).
b. Dimostra che \( ABDE \) è un trapezio e calculane l'area.
c. Congiungi i punti medi \(M\) e \(N\) dei lati obliqui del trapezio e verifica che il segmento ottenuto è parallelo alle basi e congruente alla loro semisomma.
d. Verifica che l'asse \(y\) è bisettrice dell'angolo \(\widehat{BAC}\)

[a) $C(7; -4)$, $DE: x - y - 11 = 0$; b) $105$]

271

VERSO L'ESAME

Capitolo 4 PIANO CARTESIANO E RETTA

VERCO LEGALE

40 In un triangolo ABC il vertice B ha coordinate (6; -1), la mediana CM e l'altezza CD hanno equazione rispettivamente y + 8x = 16 e y = 4x + 4. Determina:

a. le coordinate di \(A\in C\)
b. lortocentro \(H\) e il baricentro \(G\) del triangolo;
c. l'area del triangolo;
d. l'equazione della retta parallela al lato \(AB\) che, intersecando i due lati \(AC\) e \(CB\), individua con il vertice \(C\) un triangolo che ha area uguali a \(\frac{1}{4}\) di quella di \(ABC\).

[a) A(-2; 1), C(1; 8); b) H(-17/31; 56/31), G(5/3; 8/3); c) 31; d) 8y + 2x = 35]

41 Studia il fascio di rette di equazione

3kx - (1 + 2k)y - 6 = 0

al variare di k in R.

a. Determina, tra le rette del fascio, quale che incontrando gli assi cartesiani forma il triangolo OAB che ha incentro nel punto \((1; - 1)\) e quale che forma il triangolo OCD che ha baricentro in \(\left(-\frac{8}{3}; - 4\right)\).
b. Calcola il rapporto tra le aree dei triangoli OAB e OCD.
c. Indica per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \((-8;0)\) e \((4;0)\).

[fascio di centro (-4; -6), generatrici 2y - 3x = 0 e y + 6 = 0; a) 3x - 4y - 12 = 0; 3x + 2y + 24 = 0;

b) 1/8; c) k ≤ -1/4 ∨ k ≥ 1/2]

42 Rappresenta graficamente la funzione

y = √(x² - 4x + 4) + |x + 1|.

a. Determina le coordinate dei punti del grafico \(A, B\) e \(C\) le cui ascisse \((x_{A} < x_{B} < x_{C})\) sono soluzioni dell'equazione \(x^{3} + 2x^{2} - 5x - 6 = 0\).
b. Individua il punto \(D\) in modo tale che il quadrilatero \(ABCD\) sua un trapezio isoscele e calculane l'area.
c. Verifica che congiungendo i punti medi dei lati del trapezio si ottiene un rombo che ha l'area uguali alla meta di quella del trapezio.

[a) A(-3; 7), B(-1; 3), C(2; 3); b) D(4; 7); 20]

43 Date le rette di equazioni

2x + 2ay + 1 - a = 0 e (a + 1)x - ay + 1 = 0:

a. discuti al variate di \(a\) le posizioni reciproche delle due rette;
b. determinai centri \(C_1\in C_2\) dei fasci individuati da ciascuna equazione;
c. considera il punto \(P\) di ascisa 3 sull'asse del segmento \(C_1C_2\) e determina per quali valori di a si ottengo no le rette \(C_1P\) e \(C_2P\);
d. determinina il baricentro \(G\) e lortocentro \(H\) del triangolo \(C_1C_2P\).

[a) a = 0 ∨ a = -2: rette parallele, a ≠ 0 ∧ a ≠ -2: rette incidenti; b) C₁(-1/2; 1/2), C₂(-1; -1);

c) a₁ = 7/4, a₂ = -8/9; d) G(1/2; -2/3), H(-3/5; -3/10)]

![img-135.jpeg](img-135.jpeg)

44 LEGGI IL GRAFICO

a. Utilizzando i dati della figura scrivi le equazioni delle rette \( r, s \), \( a, b \) e determina le aree dei due triangoli colorati.
b. Verifica se i baricentri dei due triangoli sono allineati con \(C\)
c. Nel fascio generato dalle rette \(r\) e \(s\) trova per quale valore di \(k\) le rette del fascio intersecano entrambi i triangoli.

[a) r: y = 1/2 x - 2; s: y = -2x + 2; a: x = -3/2; b: x = 3; 961/80; 49/20;

c) k ≥ 0]

272

VERSO L'ESAME

# LEGGI IL GRAFICO

45

![img-136.jpeg](img-136.jpeg)

Il triangolo $ABC$ della figura ha l'ortocentro in $H\left(-\frac{7}{2}; -\frac{5}{2}\right)$.

a. Trova le coordinate di \(A, B \in C\).
b. Determinina sul segmento \(BC\) il punto \(P\) tale che

$$\overline{PA}^2 = \frac{6}{5} \overline{PB}^2 + 4 \overline{BO}^2.$$

c. Da $P$ traccia la parallela ad $AB$ che interseca in $Q$ il lato $AC$. Calcola il rapporto tra le aree dei triangoli $ABC$ e $PQC$.

[a) $A(-5; -2)$, $B(0; 1)$, $C(-2; -5)$; b) $P(-1; -2)$; c) 4]

46

Scrivi l'equazione della retta $r$ della figura e considera su $r$ un punto $C$ variabile.

![img-137.jpeg](img-137.jpeg)

a. Determinina il baricentro \(G\) del triangolo \(ABC\) e scrivi l'equazione del luogo descritto da \(G\). Calcola le coordinate di \(C\) quando \(G\) ha ascisa 3.
b. Determinina \(C\) nel primo quadrante in modo che \(\overline{AC} = \sqrt{17}\) e trova l'ortocentro \(H\) di \(ABC\).
c. Trova \(C\) in modo che il triangolo \(ABC\) sua isoscele, con base \(AB\), e determina l'incentro di \(ABC\).

$$\left\{ r: y = 2x; \text{a) } G\left(\frac{x_C}{3} + 2; \frac{2x_C}{3}\right); y = 2x - 4; C(3; 6); \text{b) } C(2; 4), H\left(2; \frac{3}{4}\right); \text{c) } C(3; 6), \text{incentro: } \left(3; \frac{2}{3}(\sqrt{10} - 1)\right) \right\}$$

47

È dato il punto $A(-2; 1)$.

a. Siano \(P(x;0)\) un punto dell'asse \(x\in Q\) il punto del piano di ascisa \(x\in\) ordinata \(y = \overline{PO}^2 -\overline{PA}^2\) , con O origine degli assi. Scrivi l'equazione del luogo geometrico \(r\) descritto da \(Q\) al variate della posizione di \(P\)
b. Del triangolo \( ABC \) si sa che r è l'equazione dell'altezza uscente dal vertic B e che il lato BC appartiene alla bisettrice del I e III quadrante. Determinina le coordinate dei vertici B e C del triangolo.
c. Determinina le coordinate del baricentro \(G\) e del circoentro \(K\) del triangolo \(ABC\).

$$\left\{ \text{a) } r: y = -4x - 5; \text{b) } B(-1; -1), C(2; 2); \text{c) } G\left(-\frac{1}{3}; \frac{2}{3}\right), K\left(\frac{1}{6}; \frac{5}{6}\right) \right\}$$

48

a. Nel fascio di rette di equazione

$$2(k+1)x + (k-1)y - 11k - 1 = 0,$$

individua le rette generatrici del fascio e indica con $C$ il centro del fascio.

b. Scrivi l'equazione della retta \( r \) del fascio, relativa a un valore positivo del parametro \( k \), che forma con gli assi cartesiani nel primo quadrante un triangolo di area \( \frac{98}{3} \).
c. Determinina la retta s del fascio perpendicular alla retta r.
d. Sia \(D\) l'intersezione della retta s con l'asse delle ordinate. Sia \(CD\) il lato di un quadrato, tutto situato nel primo quadrante. Trova gli altri vertici A e B del quadrato.

$$\left[ \text{a) } 2x - y - 1 = 0, 2x + y - 11 = 0, C(3; 5); \text{b) } 3x + y - 14 = 0; \text{c) } x - 3y + 12 = 0; \text{d) } A(1; 1), B(4; 2) \right]$$

49

Considera le rette $r_1: x + y = 2\sqrt{3} + 1$ e $r_2: x + \frac{\sqrt{3}}{3} y = 3$.

a. Determinina un'equazione del fascio proprio generato da \(r_1 \in r_2\).
b. Trova la retta s del fascio con coefficiente angolare positivo che forma con l'asse x un angolo di \(60^{\circ}\)
c. Determinina le equazioni delle bisettrici \(b_{1}\) e \(b_{2}\) dell'angolo formato alla retta s e dall'asse x.
d. Detto \(C\) il centro del fascio e \(A\) il punto di intersezione di s con l'asse \(x\), trova i punti \(B\) e \(D\) tali che \(ABCD\) sua un rettangolo per cui due lati appartengono alle rette \(b_{1}\) e \(b_{2}\).

$$\left\{ \text{a) } y - kx + k - 2\sqrt{3} = 0; \text{b) } y = \sqrt{3}x + \sqrt{3}; \text{c) } b_1: y = -\sqrt{3}(x+1), b_2: y = \frac{\sqrt{3}}{3}(x+1); B(2; \sqrt{3}), D(-2; \sqrt{3}) \right\}$$

273

VERSO L'ESAME

Capitolo 4

PIANO CARTESIANO E RETTA

VENTO LEGALE

50

a. Trova per quale valore di \( k \) la retta di equazione \( y + x - 4 + k(y - x) = 0 \) interseca in \( A \) l'asse \( x \in B \) l'asse \( y \) in modo che l'ascissa di \( A \) sa negativa e che l'area del triangolo \( AOB \) sa 1.
b. Determinina le coordinate dell'incentro \(Q\) del triangolo AOB.
c. Trova le coordinate del circocentro \(H\) di AOB.
d. Calcola l'area del quadrilatero OAQH.

$$\left[ a) k = 3; b) Q \left( \frac{\sqrt{5} - 3}{2}; \frac{3 - \sqrt{5}}{2} \right); c) H \left( -1; \frac{1}{2} \right); d) \frac{7 - \sqrt{5}}{8} \right]$$

51

Considera i punti $A(5; 1)$ e $B(1; 2)$. Le rette $r, s$ e $t$ passano per il punto $A$, inoltre:

la retta r e parallela all'asse x;
la retta s e perpendicularare all'asse x;
la retta t ha pendenza (coefficiente angolare) 1.

a. Determinina le equazioni delle tre rette.
b. Considera una retta \( f \) di equazione \( y = kx + d \), con \( k, d \in \mathbb{R} \), che forma con l'asse \( x \) un angolo \( \alpha \). Sapendo che la retta \( f \) passa per il punto \( B \), determina per quale valore di \( \alpha \in ]0^{\circ}; 90^{\circ} \) le rette \( f \in r \) non si intersecano.
c. La retta \(g\) passa per il punto \(B\) e ha la stessa inclinazione della retta \(t\). Trova il punto di intersezione della retta \(s\) con la retta \(g\).

(Austria, tratto da Haupttermin, AHS, maggio 2019, prova 6 di compensazione, esercizio 1)

$$\left[ a) y = 1, x = 5, y = x - 4; b) \not\exists \alpha; c) (5; 6) \right]$$

52

Le rette $r: x - 2y + 4 = 0$ e $s: x + y - 5 = 0$ si intersecano nel punto $A$, mentre $B$ è il punto in cui $r$ interseca l'asse delle ordinate. Considera una generica retta $t$ del fascio proprio di centro $B$ e l'eventuale punto di intersezione $C$ tra la retta $t$ e la retta $s$.

a. Trova la retta \(t\) del fascio in modo che il baricentro del triangolo ABC abbia ascissa 1.
b. Trova le rette \(t_x\) e \(t_y\) del fascio tali che il circocentro del triangolo ABC appartenga o all'asse \(x\) o all'asse \(y\).
c. Indicati con \(G\) il baricentro del triangolo ABC determinato al punto a e con \(O_1\) e \(O_2\) i circocentri dei triangoli ABC determinati al punto b, calcola l'area del triangolo \(GO_1O_2\).

$$\left[ a) t: y = 2x + 2; b) t_x: y = -\frac{3}{7}x + 2, t_y: y = -3x + 2; c) \frac{9}{16} \right]$$

# Problemi di matematica e realtà

![img-138.jpeg](img-138.jpeg)

53

EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA Per trasportare un certo tipo di merce tra due luoghi fissati ci sono tre possibili alternative:

su rotaia con una spesa fissa di \(200\in\) una spesa variable di \(400\in\) per tonnellata trasportata;
su gomma con mezzi speciali forniti da un'impresa di trasporto, che preveDE una spesa fissa di \(400\in\) e una spesa variabile di \(360\in\) per tonnellata trasportata;
via mare con una spesa fissa di \(480\in\) e una spesa variable di \(320\in\) per tonnellata trasportata.

Il costo a tonnellata è frazionabile in tutte le tre alternative.

Determina l'alternativa più conveniente in base alla quantità $x$, in tonnellate, di merce da trasportare.

[$x < 3,5$ rotaia, $x = 3,5$ rotaia o mare, $x > 3,5$ mare]

![img-139.jpeg](img-139.jpeg)

54

Un'azienda può produrre croissant utilizzando tre linee di produzione, con caratteristiche differenti. La linea A necessita di 14 minuti per l'avviamento e produce 5 centinaia di croissant al minuto; la linea B richiede 10 minuti per avviarsi e prepara 4 centinaia di croissant al minuto; la linea C impiega 12 minuti per avviarsi e confeziona 3 centinaia di croissant al minuto. Quale linea consente di impiegare meno tempo, in funzione del numero di croissant da produrre?

[meno di 8000: B; più di 8000: A]

274

VERSO L'ESAME

# EDUCAZIONE FINANZIARIA

55

PROBLEMA DI SCELTA Per il noleggio giornaliero di un'automobile si può scegliere fra tre diverse tariffe. La tariffa A comporta una quota fissa di 30 € e costa 0,25 € a kilometro percorso; la tariffa B comporta una quota fissa di 10 € e costa 0,60 € a kilometro percorso; la tariffa C non ha quota fissa, costa 0,40 € a kilometro percorso, però ha un vincolo minimo di 150 km, ovvero la spesa ha un costo minimo corrispondente a un percorso di 150 km.

Dopo aver rappresentato i grafici del costo del noleggio in funzione dei kilometri percorsi, stabilisci qual è la tariffa più conveniente nei diversi casi.

[B: tra 0 e 57,14 km; A: tra 57,14 e 120 km e dopo i 200 km; C: tra 120 e 200 km]

56

DOMANDA E OFFERTA La quantità di grano offerta e quella richiesta nella piazza di Granopoli il 4 luglio 2015 hanno esibito andamenti lineari in funzione del prezzo, secondo le modalità riportate nella figura.

a. Determinina le equazioni della quantità dell'offerta e della domanda in funzione del prezzo unitario (prezzo in €/q, quantità in tonnellate).
b. Qual è il prezzo di equilibrio in cui le due quantità sono uguali? Quanto valgono?

![img-140.jpeg](img-140.jpeg)

|  incremento di prezzo = 1€/q  |   |   |
| --- | --- | --- |
|  aumento offerta: 6 tonnellate  |   |   |
|  diminuzione domanda : 9 tonnellate  |   |   |
|  prezzo | offerta | domanda  |
|  24,67 €/q | 20 tonnellate | 70 tonnellate  |

[a) $y_{eff} = 6x - 128,02$, $y_{dom} = -9x + 292,03$; b) 28,00 €/q, 40 t]

57

COSTO E RICAVO In un borgo medievale Alessandro prepara e vende marmellate di frutta biologica al prezzo di 7 € al vasetto. Per quanto riguarda i costi, ha rilevato che variano linearmente con la produzione come segue.

produzione 300 vasetti
costo complessivo 1800 €

produzione 500 vasetti
costo complessivo 2600 €

Ha la possibilità di aumentare la produzione fino a 700 vasetti e pertanto decide di effettuare una piccola campagna pubblicitaria che gli verrebbe a costare 300 €. Determina:

a. la funzione del costo e quella del ricavo nella situazione attuale e la quantità per cui esse si uguagliano;
b. la funzione del costo che tiene conto della spesa per la pubblicità e la quantità che nella nuova situazione uguaglia costi e ricavi.

Rappresenta graficamente le due situazioni precedenti e commenta il risultato.

[a) $y_c = 4x + 600$, $y_r = 7x$, 200 vasetti; b) $y_c = 4x + 900$, 300 vasetti]

58

FUNZIONE DEL COSTO L'impresa Textil vuole studiare l'andamento del costo di produzione, in un settore dove vengono fabbricati piccoli tappeti di cotone, in relazione al tempo e al numero di addetti. Ha preso in considerazione la produzione di 100 unità e in base ai dati rilevati in passato ha determinato quanto segue.

costo 4000 €
tempo lavorazione 48 ore
numero addetti 6

costo 3700 €
tempo lavorazione 120 ore
numero addetti 2

Determina:

a. la funzione che esprime il costo $y$ in funzione del numero delle ore $t$, supponendo che sia lineare;
b. la funzione che esprime il numero degli addetti $n$ in funzione del numero delle ore $t$, supponendo che sia lineare, e il costo nel caso in cui si utilizzino 3 addetti.

Rappresenta graficamente le due funzioni lineari $y$ e $n$ in funzione di $t$, supponendo che $n$ possa assumere valori non naturali.

[a) $y = -\frac{25}{6}t + 4200$; b) $n = -\frac{t}{18} + \frac{26}{3}$, 3775 €]

VERSO L'ESAME

275

Capitolo 4

PIANO CARTESIANO E RETTA

![img-141.jpeg](img-141.jpeg)

Agatha si trova nella città di Seattle, dove deve incontrare l'amico Bob. Agatha è all'incrocio tra la 6th Avenue e Pike Street, mentre Bob la aspetta nei pressi del Seattle Art Museum, all'incrocio tra la 2nd Avenue e University Street. Utilizza il riferimento Oxy e le misure riportate sulla mappa, assumendo che le strade del quartiere si intersechino perpendicolarmente.

a. Determinina le coordinate di Agatha e Bob.
b. Qual è la minima distanza che Agatha deve percorrere per raggiungere Bob?

a) A(300; 300), B(600; 180); b) $$\frac{1620\sqrt{13}}{13}$$ m $$\simeq 449,3$$ m

60 Un giardiniere ha l'incarico di tagliare l'erba di un giardino il cui modello è indicato in figura.

![img-142.jpeg](img-142.jpeg)

a. Quanto tempo è necessario per tosare il giardino se mediamente il giardiniere impiega 1 min per \(50\mathrm{m}^2\)
b. Quale sarebbe il preventivo di spesa se il giardiniere volesse piantare delle piccole betulle lungo tutto il perimetro del giardino a una distance di 2,5 m l'une dall'altra, sapendo che il costo medio è di 4,50 € ciascuna? (Calcola il perimetro using due metodi: l'usuale formula della distance nel piano

cartesiano, approssimando il risultato con la calcolatrice, e il metodo diretto, misurando i lati della figura con un righello e trasformando le lunghezze con il rapporto di scala.)

c. Il giardiniere vuole installare una fontana in corrispondenza del baricentro del triangolo ACD. Dove andrà collocata?

a) 10 ore; b) 1512 €; c) $$\left(\frac{650}{3}; 100\right)$$

# Problemi di matematica e fisica

# RISOLVIAMO UN PROBLEMA

# Monoposto in pista

Una monoposto da corsa di massa M = 600 kg percorre il rettilineo di un circuito: per i primi 4 secondi si muove con accelerazione costante, per i 5 successivi mantiene la velocità raggiunta. La velocità iniziale è 43,2 km/h, mentre dopo 1,8 s è 108 km/h.

![img-143.jpeg](img-143.jpeg)

a. Deduciamo la funzione che descrive la velocità (espressa in m/s) in funzione del tempo (espresso in s) e rappresentiamo il grafico velocità-tempo.
b. Ipotizzando che sulla monoposto agisca una forza resistente \(\vec{F}_R\) parial \(80\%\) del suo peso, calculiamo la forza che il motore esercita sulla monoposto nella parte iniziale del rettilineo.

a. Deduciamo la funzione v(t) e tracciamo il suo grafico.

Nei primi 4 secondi, dato che l'accelerazione è costante, il grafico velocità-tempo è lineare. In particolare, è un segmento della retta che passa per i punti (t₀; v₀) e (t₁; v₁), con t₀ = 0 s, v₀ = 43,2 km/h = 12 m/s, t₁ = 1,8 s e v₁ = 108 km/h = 30 m/s. Ricaviamo la relazione tra v e t:

$$\frac{v - v_0}{v_1 - v_0} = \frac{t - t_0}{t_1 - t_0} \rightarrow \frac{v - 12}{18} = \frac{t}{1,8} \rightarrow v(t) = 10t + 12.$$

VERTO I ESAME

276

VERSO L'ESAME

Nell'istante \(t_2 = 4\) s la monoposto ha raggiunto la velocità \(\nu_{2} = \nu (4) = 52\mathrm{m / s}\)
- Nei successivi 5 secondi, dato che la velocità è costante, il grafico è un segmento parallelo all'asse delle ascisse.
Concludiamo che:

![img-144.jpeg](img-144.jpeg)

$$v(t) = \begin{cases} 10t + 12 & \text{se } 0 \le t \le 4 \\ 52 & \text{se } 4 < t \le 9 \end{cases}$$

- Tracciamo il grafico di $v(t)$.

b. Calcoliamo la forza esercitata dal motore nella parte iniziale del rettilineo.

- Il modulo $a$ dell'accelerazione nei primi 4 secondi è la pendenza del grafico della velocità, ovvero:

$$a = 10 \text{ m/s}^2.$$

- Le forze agenti sulla monoposto sono la forza $\vec{F}_m$ dovuta all'azione del motore e la forza resistente $\vec{F}_R$, e la forza totale è $\vec{F} = \vec{F}_m + \vec{F}_R$.

Detta $M$ la massa della monoposto e $a$ l'accelerazione nella fase iniziale del rettilineo, si ha:

$$F = Ma \quad \text{e} \quad F_R = 0,80 \text{ Mg}.$$

- Applichiamo la seconda legge della dinamica.

Le due forze hanno la stessa direzione e il verso opposto, quindi:

$$F_m - F_R = F = Ma \rightarrow F_m - 0,80 \text{ Mg} = Ma \rightarrow F_m = M(a + 0,8g) = 10700 \text{ N} \simeq 11 \cdot 10^3 \text{ N}.$$

61

![img-145.jpeg](img-145.jpeg)

MOTO RETTILINEO Il grafico a fianco rappresenta la legge oraria $s_A(t)$ del moto di Angela, che percorre in bicicletta un tratto di strada rettilineo.

a. Determinina la velocità di Angela e scrivi l'equazione di \( s_A(t) \). Qual è il significato fisico del punto (0; -10)?
b. Paolo si muove con la sua moto nella stessa direzione e nelle stesso verso alla velocità di \(20\mathrm{m / s}\). Scrivi la legge oraria \(s_{\mathrm{p}}(t)\) del moto di Paolo se, all'istante \(t = 1\) s, \(s_{\mathrm{p}}\) vale 0, e rappresentala graficamente.
c. I due grafici si intersecano nel punto \(Q\). Trova le sue coordinate e indica il suo significato fisico.

[a) $5,0 \text{ m/s}$; $s_A(t) = 5t - 10$; b) $s_P(t) = 20t - 20$; c) $Q(0,67; -6,7)$]

62

CAPACITÀ TERMICA Il grafico rappresenta la temperatura $T$, in gradi Celsius, di un blocco di zinco in funzione del calore $Q$, in kilojoule, scambiato dal blocco con l'esterno.

$C$ = capacità termica (in kJ/°C)

$C = m \cdot c$

$Q = C \Delta T$

![img-146.jpeg](img-146.jpeg)

![img-147.jpeg](img-147.jpeg)

a. Scrivi l'equazione della retta.
b. Determinina la capacité termica \(C\) del blocco di zinco. Che relazione c'è tra \(C\) e il coefficiente angolare della retta data?
c. Determinina la massa \(m\) dello zinco, sapendo che il calore specifico dello zinco è di \(0,38\mathrm{kJ / kg}\cdot {}^{\circ}\mathrm{C}\)
d. Come cambierebbe il grafico se i blocchi di zinco fosso due, ognuno di massa \(m\) e con temperatura iniziale di \(10^{\circ}\mathrm{C}\)?

[a) $T = 10 + 0,80Q$; b) $C = 1,25 \text{ kJ/°C}$; c) $m = 3,3 \text{ kg}$; d) $T = 10 + 0,40Q$]

277

VERSO L'ESAME

Capitolo 4 PIANO CARTESIANO E RETTA

![img-148.jpeg](img-148.jpeg)

VERCO I STAME

63 MOTO RETTILINEO Un punto materiale si muove secondo la legge oraria

$$s(t) = |-2 + t| + |-1 + t|, \quad \text{con } 0 \le t \le 5,0,$$

dove la posizione s è espressa in metri e il tempo t in secondi.

a. Rappresenta il grafico di \( s(t) \) e descivi il moto del punto materiale.
b. Qual è lo spostamento nell'intervallo considerato?
c. Determinina la velocità \( v(t) \) al variate di \( t \) e rappresenta il suo grafico.
d. Calcola la velocità media nell'intero tragitto.

[b) 4,0 m; d) 0,80 m/s]

64 DILATAZIONE TERMICA La variazione di volume $\Delta V = V - V_0$ di un liquido è legata al coefficiente di dilatazione $\alpha$ della sostanza e alla variazione di temperatura $\Delta T = T - T_0$ secondo la relazione:

$$\Delta V = \alpha V_0 \Delta T,$$

dove il volume è misurato in litri, la temperatura in °C, $V_0$ è il volume iniziale e $T_0$ la temperatura iniziale.

Nella fase di sperimentazione di un farmaco un'azienda farmaceutica prova a trattare 50 litri di glicerina ($\alpha = 0,53 \cdot 10^{-3} \text{°C}^{-1}$) a diverse temperature controllate $T_0$.

a. Scrivi la relazione \(V(T)\) e stabilisci se, considerando \(T_{0}\) come parametro, descive un fascio di rette proprio o improprio. Determinina l'eventuale centro o coefficiente angolare del fascio.
b. Una volta trattata, la glicerina passa alla temperatura \(T_{0}\) alla temperatura di \(25^{\circ}C\) e il suo volume si riduce del \(2.8\%\). Determinina la corrispondente retta del fascio.
c. Durante il trattamento descritto nel punto b l'azienda decide di immagazzinare la glicerina in cinque contentitori uguali. Come diventa la funzione \( V(T) \) per ciascun contentitore?

[a) improprio; $m = 2,7 \cdot 10^{-2} \text{ L} \cdot \text{°C}^{-1}$; b) $V(T) = 2,7 \cdot 10^{-2} T + 48$; c) $V(T) = 5,4 \cdot 10^{-3} T + 9,6$]

65 CONSERVAZIONE DELL'ENERGIA Un carrello di massa $m = 15$ kg, inizialmente in cima a un piano inclinato di altezza h, scivola senza attrito.

![img-149.jpeg](img-149.jpeg)

In figura sono rappresentate l'energia potenziale gravitazionale $U(x)$ e l'energia meccanica $E$ in funzione dello spostamento x lungo il piano inclinato.

a. Scrivi l'espressione analitica dell'energia potenziale, dell'energia meccanica e dell'energia cinetica \(K(x)\) , e rappresenta quest'ultima nel piano cartesian.
b. Determinina l'altezza \(h\) e l'angolo di inclinazione del piano.
c. Stabilisci dopo quanti metri di scivolamento lungo il piano l'energia cinetica è uguali all'energia potenziale e calcola il loro valore.

$$\begin{array}{l} E(x) = U(x) + K(x) \\ U(x) = m \cdot g \cdot h(x) \end{array}$$

[a) $U = -5,0 \cdot 10^{-2} x + 5$; $E = 5$; $K = 5,0 \cdot 10^{-2} x$; b) $h = 34 \text{ m}$; $\alpha = 20^\circ$; c) $50 \text{ m}$; $U = K = 2,5 \text{ kJ}$]

66 MOTO NEL PIANO Per aiutare un bagnante in difficoltà (punto C), due bagnini, partendo entrambi nello stesso momento dal punto A, decidono di adottare due diverse strategie: il primo corre sulla spiaggia e nuota direttamente verso C, entrando in acqua nel punto B; il secondo decide di entrare in acqua nel punto B', compiendo il percorso $AB'C$.

Entrambi corrono a una velocità di 3,0 m/s e nuotano a una velocità di 1,8 m/s.

![img-150.jpeg](img-150.jpeg)

a. Calcola l'ascissa di \(C\) nel riferimento in figura.
b. Quale delle due strategie comporta il percorso più breve? Quale consente di arrivare prima al bagnante?
c. Considera quale altra scelta per il punto \(B\), e verifica che il tempo di percorrenza è maggiore di 29 s.

[a) 52 m; b) $d_{ABC} = 65 \text{ m}, t_{ABC} = 31 \text{ s}$;

$d_{AB'C} = 68 \text{ m}, t_{AB'C} = 29 \text{ s}$]

278

VERSO L'ESAME

# Quesiti

67 Determina per quali valori di \(k\) i punti \(A\left(\frac{3k}{5};2\right),B\left(-7;\frac{7 + k}{3}\right)\in C\left(k + 2; - \frac{10}{k}\right)\) sono allineati. [7, 15]
68 Considera il triangolo \( ABC \), con \( A(0; -3) \in B\left(\frac{15}{4}; -\frac{9}{8}\right) \). La retta che contiene il lato \( AC \) ha equazione \( 2x - y - 3 = 0 \) e la retta che contiene l'altezza relativa ad \( AB \) ha equazione \( y = -2x + 3 \). Trova le coordinate di \( C \) e dimostra che il triangolo \( ABC \) è inscrivibile in una semicirconferenza di diametro \( AB \). \( \left[C\left(\frac{3}{2};0\right)\right] \)
69 Considera le funzioni \( f(x) = 4|x| + a \in g(x) = |2x - a| \) e determina \( a \) in modo che \( f(-1) = g(-1) \). Rappresenta i grafici di \( f(x) \in g(x) \) e trova sua graficamente sua algebricamente per quali valori di \( x \) si verifica \( f(x) \leq g(x) \). \( [a = -3; -1 \leq x \leq 3] \)
70 Considera la retta di equazione \( y = mx + q \) e dimostra che puoi ricavare la distanza tra due sui punti, \( A \in B \), di ascisse \( x_{1} \in x_{2} \), alla calcolare le loro ordinate, con la formula:

$$\overline{AB} = |x_2 - x_1|\sqrt{1 + m^2}.$$

Applica la formula nel caso di $y = -\frac{3}{4}x + 3$, con $A$ e $B$ di ascisse, rispettivamente, $-2$ e $4$, e conferma il risultato applicando la formula nota.

71 Determina le coordinate del baricentro del triangolo \( ABC \), con \( A(0; -4) \), \( B(5; 3) \), \( C(-2; 1) \), e verifica che il baricentro divide agli mediana in due parti tali che quella che contiene il vertice è dopbia dell'altra. [(1; 0)]
72 Trova l'equazione della retta \( r \) passante per \( A(-2;5) \) e parallela alla bisettrice del secondo e quarto quadrante. Detto \( B \) il punto di intersezione di \( r \) con l'asse \( x \), determina l'equazione dell'asse del segmento \( AB \).

$$[y = -x + 3; y = x + 2]$$

73 Rappresenta graficamente le funzioni \( f(x) = |x - 4| - 1 \) e \( g(x) = -2|x| + 6 \) e determina l'area del triangolo che delimitano intersecandosi. [6]
74 Determina per quale valore del parametro \( m \) la retta passante per i punti \( A(m + 1;2) \in B(1;m) \) è parallela alla retta di equazione \( y = 3x + 1 \). Trova poi il perimetro del triangolo \( ABC \) con \( C \) punto di intersezione tra l'asse \( x \) e la retta \( y = x + 1 \).
[8] 1. 2. 3. 4. 5. 6. 7. 8. 9. 10. 11. 12. 13. 14. 15. 16. 17. 18. 19. 20. 21. 22. 23. 24. 25. 26. 27. 28. 29. 30. 31. 32. 33. 34. 35. 36. 37. 38. 39. 40. 41. 42. 43. 44. 45. 46. 47. 48. 49. 50. 51. 52. 53. 54. 55. 56. 57. 58. 59. 60. 61. 62. 63. 64. 65. 66. 67. 68. 69. 70. 71. 72. 73. 74. 75. 76. 77. 78. 79. 80. 81. 82. 83. 84. 85. 86. 87. 88. 89. 90. 91. 92. 93. 94. 95. 96. 97. 98. 99. 100. 101. 102. 103. 104. 105. 106. 107. 108. 109. 110. 111. 112. 113. 114. 115. 116. 117. 118. 119. 120. 121. 122. 123. 124. 125. 126. 127. 128. 129. 130. 131. 132. 133. 134. 135. 136. 137. 138. 139. 140. 141. 142. 143. 144. 145. 146. 147. 148. 149. 150. 151. 152. 153. 154. 155. 156. 157. 158. 159. 160. 161. 162. 163. 164. 165. 166. 167. 168. 169. 170. 171. 172. 173. 174. 175. 176. 177. 178. 179. 180. 181. 182. 183. 184. 185. 186. 187. 188. 189. 190. 191. 192. 193. 194. 195. 196. 197. 198. 199. 200. 201. 202. 203. 204. 205. 206. 207. 208. 209. 210. 211. 212. 213. 214. 215. 216. 217. 218. 219. 220. 221. 222. 223. 224. 225. 226. 227. 228. 229. 230. 231. 232. 233. 234. 235. 236. 237. 238. 239. 240. 241. 242. 243. 244. 245. 246. 247. 248. 249. 250. 251. 252. 253. 254. 255. 256. 257. 258. 259. 260. 261. 262. 263. 264. 265. 266. 267. 268. 269. 270. 271. 272. 273. 274. 275. 276. 277. 278. 279. 280. 281. 282. 283. 284. 285. 286. 287. 288. 289. 290. 291. 292. 293. 294. 295. 296. 297. 298. 299. 300. 301. 302. 303. 304. 305. 306. 307. 308. 309. 310. 311. 312. 313. 314. 315. 316. 317. 318. 319. 320. 321. 322. 323. 324. 325. 326. 327. 328. 329. 330. 331. 332. 333. 334. 335. 336. 337. 338. 339. 340. 341. 342. 343. 344. 345. 346. 347. 348. 349. 350. 351. 352. 353. 354. 355. 356. 357. 358. 359. 360. 361. 362. 363. 364. 365. 366. 367. 368. 369. 370. 371. 372. 373. 374. 375. 376. 377. 378. 379. 380. 381. 382. 383. 384. 385. 386. 387. 388. 389. 390. 391. 392. 393. 394. 395. 396. 397. 398. 399. 400. 401. 402. 403. 404. 405. 406. 407. 408. 409. 410. 411. 412. 413. 414. 415. 416. 417. 418. 419. 420. 421. 422. 423. 424. 425. 426. 427. 428. 429. 430. 431. 432. 433. 434. 435. 436. 437. 438. 439. 440. 441. 442. 443. 444. 445. 446. 447. 448. 449. 450. 451. 452. 453. 454. 455. 456. 457. 458. 459. 460. 461. 462. 463. 464. 465. 466. 467. 468. 469. 470. 471. 472. 473. 474. 475. 476. 477. 478. 479. 480. 481. 482. 483. 484. 485. 486. 487. 488. 489. 490. 491. 492. 493. 494. 495. 496. 497. 498. 499. 500. 501. 502. 503. 504. 505. 506. 507. 508. 509. 510. 511. 512. 513. 514. 515. 516. 517. 518. 519. 520. 521. 522. 523. 524. 525. 526. 527. 528. 529. 530. 531. 532. 533. 534. 535. 536. 537. 538. 539. 540. 541. 542. 543. 544. 545. 546. 547. 548. 549. 550. 551. 552. 553. 554. 555. 556. 557. 558. 559. 560. 561. 562. 563. 564. 565. 566. 567. 568. 569. 570. 571. 572. 573. 574. 575. 576. 577. 578. 579. 580. 581. 582. 583. 584. 585. 586. 587. 588. 589. 590. 591. 592. 593. 594. 595. 596. 597. 598. 599. 600. 601. 602. 603. 604. 605. 606. 607. 608. 609. 610. 611. 612. 613. 614. 615. 616. 617. 618. 619. 620. 621. 622. 623. 624. 625. 626. 627. 628. 629. 630. 631. 632. 633. 634. 635. 636. 637. 638. 639. 640. 641. 642. 643. 644. 645. 646. 647. 648. 649. 650. 651. 652. 653. 654. 655. 656. 657. 658. 659. 660. 661. 662. 663. 664. 665. 666. 667. 668. 669. 670. 671. 672. 673. 674. 675. 676. 677. 678. 679. 680. 681. 682. 683. 684. 685. 686. 687. 688. 689. 690. 691. 692. 693. 694. 695. 696. 697. 698. 699. 700. 701. 702. 703. 704. 705. 706. 707. 708. 709. 710. 711. 712. 713. 714. 715. 716. 717. 718. 719. 720. 721. 722. 723. 724. 725. 726. 727. 728. 729. 730. 731. 732. 733. 734. 735. 736. 737. 738. 739. 740. 741. 742. 743. 744. 745. 746. 747. 748. 749. 750. 751. 752. 753. 754. 755. 756. 757. 758. 759. 760. 761. 762. 763. 764. 765. 766. 767. 768. 769. 770. 771. 772. 773. 774. 775. 776. 777. 778. 779. 780. 781. 782. 783. 784. 785. 786. 787. 788. 789. 790. 791. 792. 793. 794. 795. 796. 797. 798. 799. 800. 801. 802. 803. 804. 805. 806. 807. 808. 809. 810. 811. 812. 813. 814. 815. 816. 817. 818. 819. 820. 821. 822. 823. 824. 825. 826. 827. 828. 829. 830. 831. 832. 833. 834. 835. 836. 837. 838. 839. 840. 841. 842. 843. 844. 845. 846. 847. 848. 849. 850. 851. 852. 853. 854. 855. 856. 857. 858. 859. 860. 861. 862. 863. 864. 865. 866. 867. 868. 869. 870. 871. 872. 873. 874. 875. 876. 877. 878. 879. 880. 881. 882. 883. 884. 885. 886. 887. 888. 889. 890. 891. 892. 893. 894. 895. 896. 897. 898. 899. 900. 901. 902. 903. 904. 905. 906. 907. 908. 909. 910. 911. 912. 913. 914. 915. 916. 917. 918. 919. 920. 921. 922. 923. 924. 925. 926. 927. 928. 929. 930. 931. 932. 933. 934. 935. 936. 937. 938. 939. 940. 941. 942. 943. 944. 945. 946. 947. 948. 949. 950. 951. 952. 953. 954. 955. 956. 957. 958. 959. 960. 961. 962. 963. 964. 965. 966. 967. 968. 969. 970. 971. 972. 973. 974. 975. 976. 977. 978. 979. 980. 981. 982. 983. 984. 985. 986. 987. 988. 989. 990. 991. 992. 993. 994. 995. 996. 997. 998. 999.

$$[y = 2x - 6; \overline{HB} = \frac{2\sqrt{5}}{3}, \overline{BC} = \frac{\sqrt{5}}{3}]$$

77 Considera i due fasci di rette di equazioni $kx - (y - 1) = 0$ e $x + k(y + 1) = 0$ e determina i loro centri $A$ e $B$. Dimostra che, per qualsiasi valore di $k$, si ottengono nei due fasci due rette tra loro perpendicolari. Calcola per quali valori del parametro $k$ il punto $P$ di intersezione delle due rette giace nel primo quadrante.

$$[A(0; 1), B(0; -1); -1 < k < 0]$$

78 Considera il triangolo \( ABC \), con \( A(5;6) \), \( B(-1;3) \) e \( AC \) sulla retta \( r \): \( 2x - y - 4 = 0 \). Determina le coordinate dell'incentro del triangolo, sapendo che si trova sull'altezza relativa al lato \( AC \). [(1; 2)]
79 Determina il terzo vertic e di un triangolo di cui sono noti due vertici, \(B(3; - 1)\in C(-1; - 3)\) e l'ortocento \(H\left(\frac{21}{4};\frac{3}{4}\right)\) . \(\left[A\left(\frac{87}{4}; - \frac{129}{4}\right)\right]\)
80 REALTA E MODELLI In un serbatoio di acqua di forma cubica, un liquido raggiunge l'altezza di 40 cm. All'apertura dello scarico, il liquido defluisce completeness in 8 minuti. L'altezza del liquido presente nel serbatoio t minuti dopo l'apertura dello scarico è descritta alla funzione \( h(t) = k \cdot t + d \), per \( t \in [0;8] \). Determina i valori dei parametri \( k \in d \).

(Austria, tratto da Haupttermin, AHS, 2019, esercizio 9)

$$[k = -5 \text{ cm/min}, d = 40 \text{ cm}]$$

279

VERSO L'ESAME