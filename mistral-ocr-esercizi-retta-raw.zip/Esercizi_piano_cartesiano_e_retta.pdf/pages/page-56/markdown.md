PROVE DI VERIFICA

# PROVE DI VERIFICA

Risultati delle prove

# Prova A

1 ora

Il tuo punteggio: ... / 100

1 Sul segmento di estremi $A(4; -1)$ e $B(8; -4)$ determina un punto $P$ tale che $\overline{PA} = 3\overline{PB}$.

2 Rappresenta i grafici delle seguenti funzioni:

a. $y = \frac{\sqrt{x^2}}{x} + |x - 3|$

b. $y = \begin{cases} |2x + 1| & \text{se } x \le 0 \\ -x + 3 & \text{se } x > 0 \end{cases}$

3 Dati i punti $A(2k; 1 - 2k)$, $B(k + 3; k - 3)$ e $C(4 - k; k)$, trova per quali valori di $k \in \mathbb{R}$:

a. il punto medio di \(AB\) appartiene all'asse \(x\)
b. il segmento \(AC\) non interseca l'asse \(y\)
c. il baricentro del triangolo \( ABC \) si trovava sulla retta di equazione \( y = -x + 1 \)
d. \(\overline{AB} <  \sqrt{5}.\)

4 Studia il fascio di rette di equazione $x - 4ay + 2ax + 2 = 0$ e trova per quali valori di $a \in \mathbb{R}$ la retta corrispondente del fascio:

a. ha coefficiente angolare positivo;
b. interseca l'asse \(x\) in un punto di ascisa negativa;
c. è perpendicularare alla retta che passa per \((0;1)\) e \((-2;3)\).

5 Trova l'area della figura individuata mettendo a sistema le disequazioni:

$y - 3 \le 0; \quad y \le 6 - x; \quad x + y \ge 0; \quad y + 12 > 2x.$

# Prova B

1 ora

Il tuo punteggio: ... / 100

1 REALTÀ E MODELLI Un giardiniere deve disporre sei cespugli di rose in modo che ciascuno disti 5 dm dai due adiacenti e dal centro $O$ del giardino.

![img-130.jpeg](img-130.jpeg)

Per aiutarsi, scava per terra due piccoli solchi, come se fossero assi cartesiani di origine $O$. Posto il primo cespuglio in $(-5; 0)$, dove pianterà gli altri?

2 Il parallelogramma $ABCD$ ha il vertice $A(1; 4)$ e il punto di incontro delle diagonali $P(4; 3)$. Il vertice $B$ è sull'asse $x$ e sulla retta di equazione $2y - x - 2 = 0$. Trova i vertici $B, C, D$, il perimetro e l'area del parallelogramma.

3 Trova l'equazione della retta $t$ comune ai due fasci

$r: (3h - 1)x + 2hy - 6 = 0 \quad \text{e} \quad s: kx + (k - 1)y - k = 0, \quad \text{con } h, k \in \mathbb{R},$

e calcola l'area del triangolo formato da $t$ e dagli assi coordinati. Verifica poi che l'ortocentro, il baricentro e il circocentro del triangolo sono allineati.

![img-131.jpeg](img-131.jpeg)

4 LEGGI IL GRAFICO Scrivi le equazioni delle rette $r, s$ e $t$ rappresentate nel grafico e indica le coordinate dei punti $A, B, C$.

5 Rappresenta il grafico della funzione

$y = \begin{cases} |x - 1| & \text{se } x < 2 \\ -\frac{1}{2}x + 2| + 1 & \text{se } x \ge 2 \end{cases}$

VERIFICA LE COMPETENZE

269