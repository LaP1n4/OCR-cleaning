DISTANZA, PUNTO MEDIO, BARICENTRO

RIEPILOGO

In un triangolo di vertici \(A(0;5),B(3; - 1),C(6;3)\) conduci da un punto \(P\) del lato \(AB\) la retta parallela al lato \(BC\) fino a incontrare il lato \(AC\) nel punto \(Q\) . Quali coordinate deve ave \(P\) affinché le aree dei triangoli \(PAQ\) e \(BAC\) stiano fra loro come 4 sta a 9? [P(2;1)]
151 Verifica che il triangolo di vertici \(A(4;2),B(9;4)\in C\left(8; - \frac{3}{4}\right)\) e isoscele e calcola la sua area. Trova le coordinate dei punti che dividono l'altezza \(CH\) del triangolo in tre segmenti congruenti.

$$\left[ \frac{87}{8}; P\left(\frac{15}{2}; \frac{1}{2}\right), Q\left(7; \frac{7}{4}\right) \right]$$

Dati i punti \(A(-4;0)\) e \(B(2;2)\) ,trova per quali valori di \(k\) il punto \(C(2k - 1;k + 3)\) e il vertic del triangolo isoscele \(ABC\) di base \(AB\) .Determina poi un punto \(P\) del lato \(AC\) tale che \(\frac{\overline{AP}}{7} = \overline{PC}\) . \(\left[-\frac{2}{7};P\left(-\frac{15}{8};\frac{19}{8}\right)\right]\)
153 Un triangolo \( ABC \) ha per vertici i punti \( A(k^2 - 1; 2) \), \( B(-4; 2k) \in C(5; 1 - 3k) \). Trova \( k \) in modo che il triangolo \( A'B'C' \), simmetrico di \( ABC \) rispetto al punto \( P(-1; 2) \), abbia per baricentro il punto \( G' \left(-\frac{10}{3}; \frac{11}{3}\right) \). Calcola poi il perimetro e l'area del triangolo \( ABC \).

$$\left[ k = 2; 2\sqrt{53} + 9\sqrt{2}; \frac{45}{2} \right]$$

154 Se $M(2; 2)$ è il punto di incontro delle diagonali di un quadrato $ABCD$ di lato $l = 2\sqrt{2}$, determina le coordinate dei vertici del quadrato, sapendo che le diagonali sono perpendicolari agli assi coordinati.

$$[A(4; 2), B(2; 4), C(0; 2), D(2; 0)]$$

155 I punti \(A(4;6),B(9;3)\in C(6; - 2)\) sono tre vertici consecutivi di un quadrilatero \(ABCD\) avente le diagonali che si intersecano in \(M\) punto medio della diagonale \(AC\) . Inoltre, \(M\) divide la diagonale \(BD\) in due parti tali che \(MD\) è doppio di \(MB\) . Determina le coordinate del vertic \(D\) e l'area di \(ABCD\) . [D(-3;0);51]
156 I punti \(A(-2;4)\in B(0;1)\) sono due vertici del parallelogramma \(ABCD\) e il punto \(M\left(2;\frac{9}{2}\right)\) è il punto di intersezione delle diagonali.

a. Determinina le coordinate dei vertici \(C\in D\)
b. Verifica che il parallelogramma è un rettangolo.
c. Calcolane il perimetro e l'area.

$$[a) C(6; 5), D(4; 8); c) 6\sqrt{13}; 26]$$

157 Trova i punti \(A^{\prime}\) e \(B^{\prime}\) simmetrici dei punti \(A(-2;1)\) e \(B(1;4)\) rispetto all'origine \(O\) degli assi, e determina nel quarto quadrante il punto \(C\) in modo che il triangolo \(A'B'C\) sa rettangolo, con ipotenusa \(A'C\), e abbia area uguate a 12. \([A'(2; - 1), B'(-1; - 4); C(3; - 8)]\)
158 Dati i punti \(A\left(\frac{5 - h}{5};\frac{10 + 7h}{5}\right),B(1 - 2h;2 - h)\in C(1 + 3h;2 - h)\) , con \(h\) numero reale diverso da 0:

a. verifica che il triangolo \( ABC \) è rettangolo in \( A \);
b. determina i valori di \(h\) affinché il triangolo abbia area 24;
c. verifica che, scelti due valori distincti di \(h\), i due triangoli che si ottengono sono simili.

$$[b) h = \pm 2]$$

159 Del triangolo $ABC$ sono noti il vertice $B(4; 5)$ e il punto medio $M(1; 1)$ del lato $AC$. Trova:

a. il baricentro \(G\) del triangolo;
b. le coordinate del vertice \(A\) sapendo che si trovava sull'asse \(y\), con ordinata minore di 5, e che il lato \(AB\) misura \(2\sqrt{5}\);
c. le coordinate del vertice \(C\)
d. il perimetro e l'area del triangolo.

160 Dati i punti $A(-2; 2)$ e $B(1; 8)$, determina:

a. il punto \(C\) di ordinata \(-1\) in modo che il triangolo \(ABC\) sa rettangolo in \(A\);
b. il punto \(D\) di ascissa \(-1\) in modo che il triangolo \(ABD\) sa isoscele con la base su \(AB\);
c. il rapporto tra le aree dei triangoli \( ABC \in ABD \);
d. il circocentro dei triangoli \( ABC \in ABD \).

$$[a) C(4; -1); b) D\left(-1; \frac{21}{4}\right); c) 12; d) P\left(\frac{5}{2}; \frac{7}{2}\right), P'\left(\frac{33}{4}; \frac{5}{8}\right)]$$

223

ESERCIZI