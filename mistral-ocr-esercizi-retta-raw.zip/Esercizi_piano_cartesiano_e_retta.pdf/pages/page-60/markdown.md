VERSO L'ESAME

# LEGGI IL GRAFICO

45

![img-136.jpeg](img-136.jpeg)

Il triangolo $ABC$ della figura ha l'ortocentro in $H\left(-\frac{7}{2}; -\frac{5}{2}\right)$.

a. Trova le coordinate di \(A, B \in C\).
b. Determinina sul segmento \(BC\) il punto \(P\) tale che

$$\overline{PA}^2 = \frac{6}{5} \overline{PB}^2 + 4 \overline{BO}^2.$$

c. Da $P$ traccia la parallela ad $AB$ che interseca in $Q$ il lato $AC$. Calcola il rapporto tra le aree dei triangoli $ABC$ e $PQC$.

[a) $A(-5; -2)$, $B(0; 1)$, $C(-2; -5)$; b) $P(-1; -2)$; c) 4]

46

Scrivi l'equazione della retta $r$ della figura e considera su $r$ un punto $C$ variabile.

![img-137.jpeg](img-137.jpeg)

a. Determinina il baricentro \(G\) del triangolo \(ABC\) e scrivi l'equazione del luogo descritto da \(G\). Calcola le coordinate di \(C\) quando \(G\) ha ascisa 3.
b. Determinina \(C\) nel primo quadrante in modo che \(\overline{AC} = \sqrt{17}\) e trova l'ortocentro \(H\) di \(ABC\).
c. Trova \(C\) in modo che il triangolo \(ABC\) sua isoscele, con base \(AB\), e determina l'incentro di \(ABC\).

$$\left\{ r: y = 2x; \text{a) } G\left(\frac{x_C}{3} + 2; \frac{2x_C}{3}\right); y = 2x - 4; C(3; 6); \text{b) } C(2; 4), H\left(2; \frac{3}{4}\right); \text{c) } C(3; 6), \text{incentro: } \left(3; \frac{2}{3}(\sqrt{10} - 1)\right) \right\}$$

47

È dato il punto $A(-2; 1)$.

a. Siano \(P(x;0)\) un punto dell'asse \(x\in Q\) il punto del piano di ascisa \(x\in\) ordinata \(y = \overline{PO}^2 -\overline{PA}^2\) , con O origine degli assi. Scrivi l'equazione del luogo geometrico \(r\) descritto da \(Q\) al variate della posizione di \(P\)
b. Del triangolo \( ABC \) si sa che r è l'equazione dell'altezza uscente dal vertic B e che il lato BC appartiene alla bisettrice del I e III quadrante. Determinina le coordinate dei vertici B e C del triangolo.
c. Determinina le coordinate del baricentro \(G\) e del circoentro \(K\) del triangolo \(ABC\).

$$\left\{ \text{a) } r: y = -4x - 5; \text{b) } B(-1; -1), C(2; 2); \text{c) } G\left(-\frac{1}{3}; \frac{2}{3}\right), K\left(\frac{1}{6}; \frac{5}{6}\right) \right\}$$

48

a. Nel fascio di rette di equazione

$$2(k+1)x + (k-1)y - 11k - 1 = 0,$$

individua le rette generatrici del fascio e indica con $C$ il centro del fascio.

b. Scrivi l'equazione della retta \( r \) del fascio, relativa a un valore positivo del parametro \( k \), che forma con gli assi cartesiani nel primo quadrante un triangolo di area \( \frac{98}{3} \).
c. Determinina la retta s del fascio perpendicular alla retta r.
d. Sia \(D\) l'intersezione della retta s con l'asse delle ordinate. Sia \(CD\) il lato di un quadrato, tutto situato nel primo quadrante. Trova gli altri vertici A e B del quadrato.

$$\left[ \text{a) } 2x - y - 1 = 0, 2x + y - 11 = 0, C(3; 5); \text{b) } 3x + y - 14 = 0; \text{c) } x - 3y + 12 = 0; \text{d) } A(1; 1), B(4; 2) \right]$$

49

Considera le rette $r_1: x + y = 2\sqrt{3} + 1$ e $r_2: x + \frac{\sqrt{3}}{3} y = 3$.

a. Determinina un'equazione del fascio proprio generato da \(r_1 \in r_2\).
b. Trova la retta s del fascio con coefficiente angolare positivo che forma con l'asse x un angolo di \(60^{\circ}\)
c. Determinina le equazioni delle bisettrici \(b_{1}\) e \(b_{2}\) dell'angolo formato alla retta s e dall'asse x.
d. Detto \(C\) il centro del fascio e \(A\) il punto di intersezione di s con l'asse \(x\), trova i punti \(B\) e \(D\) tali che \(ABCD\) sua un rettangolo per cui due lati appartengono alle rette \(b_{1}\) e \(b_{2}\).

$$\left\{ \text{a) } y - kx + k - 2\sqrt{3} = 0; \text{b) } y = \sqrt{3}x + \sqrt{3}; \text{c) } b_1: y = -\sqrt{3}(x+1), b_2: y = \frac{\sqrt{3}}{3}(x+1); B(2; \sqrt{3}), D(-2; \sqrt{3}) \right\}$$

273

VERSO L'ESAME