VERSO L'ESAME

Nell'istante \(t_2 = 4\) s la monoposto ha raggiunto la velocità \(\nu_{2} = \nu (4) = 52\mathrm{m / s}\)
- Nei successivi 5 secondi, dato che la velocità è costante, il grafico è un segmento parallelo all'asse delle ascisse.
Concludiamo che:

![img-144.jpeg](img-144.jpeg)

$$v(t) = \begin{cases} 10t + 12 & \text{se } 0 \le t \le 4 \\ 52 & \text{se } 4 < t \le 9 \end{cases}$$

- Tracciamo il grafico di $v(t)$.

b. Calcoliamo la forza esercitata dal motore nella parte iniziale del rettilineo.

- Il modulo $a$ dell'accelerazione nei primi 4 secondi è la pendenza del grafico della velocità, ovvero:

$$a = 10 \text{ m/s}^2.$$

- Le forze agenti sulla monoposto sono la forza $\vec{F}_m$ dovuta all'azione del motore e la forza resistente $\vec{F}_R$, e la forza totale è $\vec{F} = \vec{F}_m + \vec{F}_R$.

Detta $M$ la massa della monoposto e $a$ l'accelerazione nella fase iniziale del rettilineo, si ha:

$$F = Ma \quad \text{e} \quad F_R = 0,80 \text{ Mg}.$$

- Applichiamo la seconda legge della dinamica.

Le due forze hanno la stessa direzione e il verso opposto, quindi:

$$F_m - F_R = F = Ma \rightarrow F_m - 0,80 \text{ Mg} = Ma \rightarrow F_m = M(a + 0,8g) = 10700 \text{ N} \simeq 11 \cdot 10^3 \text{ N}.$$

61

![img-145.jpeg](img-145.jpeg)

MOTO RETTILINEO Il grafico a fianco rappresenta la legge oraria $s_A(t)$ del moto di Angela, che percorre in bicicletta un tratto di strada rettilineo.

a. Determinina la velocità di Angela e scrivi l'equazione di \( s_A(t) \). Qual è il significato fisico del punto (0; -10)?
b. Paolo si muove con la sua moto nella stessa direzione e nelle stesso verso alla velocità di \(20\mathrm{m / s}\). Scrivi la legge oraria \(s_{\mathrm{p}}(t)\) del moto di Paolo se, all'istante \(t = 1\) s, \(s_{\mathrm{p}}\) vale 0, e rappresentala graficamente.
c. I due grafici si intersecano nel punto \(Q\). Trova le sue coordinate e indica il suo significato fisico.

[a) $5,0 \text{ m/s}$; $s_A(t) = 5t - 10$; b) $s_P(t) = 20t - 20$; c) $Q(0,67; -6,7)$]

62

CAPACITÀ TERMICA Il grafico rappresenta la temperatura $T$, in gradi Celsius, di un blocco di zinco in funzione del calore $Q$, in kilojoule, scambiato dal blocco con l'esterno.

$C$ = capacità termica (in kJ/°C)

$C = m \cdot c$

$Q = C \Delta T$

![img-146.jpeg](img-146.jpeg)

![img-147.jpeg](img-147.jpeg)

a. Scrivi l'equazione della retta.
b. Determinina la capacité termica \(C\) del blocco di zinco. Che relazione c'è tra \(C\) e il coefficiente angolare della retta data?
c. Determinina la massa \(m\) dello zinco, sapendo che il calore specifico dello zinco è di \(0,38\mathrm{kJ / kg}\cdot {}^{\circ}\mathrm{C}\)
d. Come cambierebbe il grafico se i blocchi di zinco fosso due, ognuno di massa \(m\) e con temperatura iniziale di \(10^{\circ}\mathrm{C}\)?

[a) $T = 10 + 0,80Q$; b) $C = 1,25 \text{ kJ/°C}$; c) $m = 3,3 \text{ kg}$; d) $T = 10 + 0,40Q$]

277

VERSO L'ESAME