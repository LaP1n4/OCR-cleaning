PUNTI E SEGMENTI

Paragrafo 1

12 Per quali valori di \(kP(2k - 5; k^2 - 5k + 6)\) è un punto dell'asse x? Calcola il valore corrispondente dell'ascissa. \([k = 2, x = -1; k = 3, x = 1]\)
13 Per quali valori di \(a\) il punto \(P(4a - a^2; 2a - 12)\) appartiene al quarto quadrante? \([0 < a < 4]\)

VERIFICA CON PYTHON

Scrivi un programma che, considerato il punto P dell'esercizio, chieda in input un valore di a, stampi le coordinate di P e rappresenti il punto nel piano cartesiano. Usa il programma per verificare il risultato che hai ottenuto.

14 Trova per quali valori di k il punto

$$A \left( 2 - | k |, \frac { 1 - 2 k } { k ^ { 2 } - 4 } \right)$$

appartiene al primo quadrante. $$\left\{ \frac { 1 } { 2 } < k < 2 \right\}$$

15 In un riferimento cartesiano, A è l'insieme dei punti che hanno ascissa x ≥ 1, B è l'insieme dei punti che hanno ordinata y > 3. Disegna A ∩ B.

In un riferimento cartesiano, \(A\) è l'insieme dei punti che hanno ascissa \(x\) tale che \(-1 < x \leq 6\) e \(B\) è l'insieme dei punti che hanno ordinata \(y\) tale che \(-1 \leq y < 8\). Disegna \(A \cap B\).
Dato il punto \(A\left(\sqrt{a - 1};\frac{a}{2} -1\right)\) ,trova per quali valori di a il punto e interno al quadrato che ha i lati paralleliagli assicartesianieha due vertici di coordinate \((-1;0)\) e(3;4). [2<a<10]
18 Calcola per quali valori di \(a\) il punto

$$P ( | a + 1 | ; a - 4 )$$

appartiene alla striscia individuata dalle parallele all'asse y passanti per A(-2; 0) e B(4; 0). $$[ - 5 \leq a \leq 3 ]$$

LEGGI IL GRAFICO Indica per ciascun insieme di punti evidenziato la condizione sulle coordinate che lo descrive.

![img-2.jpeg](img-2.jpeg)

![img-3.jpeg](img-3.jpeg)

![img-4.jpeg](img-4.jpeg)

![img-5.jpeg](img-5.jpeg)

Rappresenta nel piano cartesiano gli insiemi dei punti P(x; y) le cui coordinate soddisfano le seguenti condizioni.

21 $$\left\{ \begin{array} { l } { | x - 4 | < 2 } \\ { 1 + y ^ { 2 } < 5 } \end{array} \right.$$

23 $$\left\{ \begin{array} { l } { x < - 2 } \\ { y < 1 } \end{array} \right. \vee \left\{ \begin{array} { l } { x \geq 3 } \\ { y ^ { 2 } \leq 1 6 } \end{array} \right.$$

22 $$\left\{ \begin{array} { l } { x = 4 } \\ { 1 \leq y < 7 } \end{array} \right.$$

24 $$\left\{ \begin{array} { l } { | x - 2 | < 3 } \\ { | y | \leq 2 } \end{array} \right.$$

25 Rappresenta i punti dell'asse x la cui ascissa verifica la condizione:

a. $$| x | \geq 3;$$

b. $$| 2 x - 1 | = 3;$$

c. $$| 3 x + 2 | < 1.$$

26 Rappresenta i punti dell'asse y la cui ordinata verifica la condizione:

a. $$| y ^ { 2 } - 3 | \leq 1;$$

b. $$| 1 - 3 y | = 6;$$

c. $$| y - 4 | > 2.$$

27 LEGGI IL GRAFICO VERO O FALSO?

![img-6.jpeg](img-6.jpeg)

a. Il rettangolo della figura può essere individuato da

$$\left\{ ( x ; y ) \mid x ^ { 2 } - x \leq 0 \land \mid y - 3 \mid \leq 3 \right\} .$$

b. La disequazione \(x^{2} - 4x\leq 0\) nel piano cartesiano e verificata solo dai punti del segmente di estremi (0; 0) e (4; 0).
c. I punti che verificano il systema \(\left\{ \begin{array}{l} |x| \leq 1 \\ |y| \leq 3 \end{array} \right.\) appar tengono a un rettangolo che ha centro nell'origine e un vertic di coordinate (1; 3).

V F

V F

V F

215

ESERCIZIO