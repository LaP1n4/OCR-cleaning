FASCI DI RETTE

Paragrafo 7

589

Dato il fascio proprio di rette di equazione $mx - y + m + 2 = 0$, determina per quali valori di $m$ si hanno rette che intersecano il segmento di estremi $A(3; 6)$ e $B(-2; -4)$. Calcola poi l'area del triangolo $ABC$, con $C$ centro del fascio, e i valori di $m$ che individuano nel fascio la mediana $CM$ e l'altezza $CH$ del triangolo.

$$\left[ m \leq 1 \vee m \geq 6; 10; -\frac{2}{3}; -\frac{1}{2} \right]$$

590

Siano dati i due fasci di rette $r$: $hx - y + 3h = 0$ e $s$: $x - 2hy + h = 0$.

a. Determinina la retta comune ai due fasci.
b. Scrivi, al variate di \( h \), le coordinate del punto di intersezione \( P \) tra le rette \( r \in s \).
c. Trova il valore di \( h \) per cui il punto \( P \) coincide con l'origine degli assi.
d. Detti \(A\in B\) i rispetti centri dei fasci, trova l'area del triangolo ABO.

$$\left[ a) x - 6y + 3 = 0; b) P \left( \frac{-6h^2 + h}{2h^2 - 1}; \frac{h^2 - 3h}{2h^2 - 1} \right); c) 0; d) \frac{3}{4} \right]$$

591

Studia il fascio di rette di equazione $(2k + 1)x + (3 + k)y + 1 - 2k = 0$, determinando le equazioni delle generatrici e le coordinate del centro $C$. Calcola il valore di $k$ corrispondente alla retta:

a. parallela alla retta di equazione \(x + y - 1 = 0\)
b. passante per \(P(5;1)\)
c. passante per \(Q\), essendo \(Q\) un punto del primo quadrante, vertice del triangolo isoscele PCQ di base PC e area \(\frac{441}{40}\). [generatrici: \(x + 3y + 1 = 0, 2x + y - 2 = 0; C\left(\frac{7}{5}; -\frac{4}{5}\right)\); a) 2; b) -1; c) - \(\frac{67}{18}\)]

592

a. Studia le caratteristiche del fascio di rette di equazione \((2 + k)x - (1 + k)y - 5 - k = 0\) e individua il centro e le generatrici.
b. Determinina per quale valore del parametro \(k\) si ottiene la retta s del fascio perpendicolare alla retta di equazione \(x - 2y + 5 = 0\)
c. Individua la retta del fascio che forma un angolo di \(135^{\circ}\) con la direzione positiva dell'asse delle ascisse.
d. Stabilisci per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \(A(1;6)\in B(4;5)\)

$$\left[ a) C(4; 3), x - y - 1 = 0, 2x - y - 5 = 0; b) k = -\frac{4}{3}, s: y = -2x + 11; c) y = -x + 7; d) -\frac{3}{2} \leq k \leq -1 \right]$$

593

a. Studia il fascio di rette di equazione \((2 + k)x + (k - 1)y - 1 - 2k = 0\), individuandone il centro e le generatrici.
b. Trova per quali valori di \(k\) si ottengono le rette che formano con gli assi cartesiani un triangolo di area \(\frac{1}{2}\).
c. Calcola per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \(A(1; - 2)\in B(4;3)\)

$$\left[ a) C(1; 1), 2x - y - 1 = 0, x + y - 2 = 0; b) k = \frac{-5 \pm 3\sqrt{5}}{10}; c) k \leq -\frac{4}{5} \vee k \geq 1 \right]$$

594

a. Studia il fascio di rette di equazione \((k + 2)x - (1 - 2k)y + 5 = 0\),indicando con a la retta del fascio che non viene rappresentata da alcun valore di \(k\)
b. Determinina la retta \( r \) del fascio che interseca l'asse \( y \) nel punto avente per ordinata la soluzione positiva dell'equazione \( t^4 - 4t^2 = 0 \).
c. Individua la retta s del fascio di equazione \(x + (k + 1)y - 3 + k = 0\) perpendicular alla retta r.
d. Calcola l'area del quadrilatero convesso individuato delle rette \( r \), \( s \), \( a \) e alla retta \( b \) del secondo fascio che non corrisponde ad alcun valore di \( k \).

[a) fascio proprio di centro $(-2; 1)$, a: $x + 2y = 0$; b) $r$: $x - 2y + 4 = 0$; c) $s$: $2x + y - 7 = 0$; d) $12$]

595

a. Nel fascio di rette di equazione \(2x + 5y + k = 0\) individua le rette \(r\in s\) \((k_{r} < k_{s})\) che passano per i punti dell'asse \(y\) le cui ordinate sono soluzioni dell'equazione \(t^2 -2t - 8 = 0\)
b. Determinina i punti di intersezione \(A\) e \(B\) della retta \(8x + 5y + 10 = 0\) con le rette \(r\in s\)
c. Determinina, nel quarto quadrante, il punto \(C\) appartenente alla retta s tale che il segmento \(BC\) abbia lunghezza \(\sqrt{29}\).
d. Individua il quarto vertice \(D\) del parallelogramma \(ABCD\) e calculane perimetro e area.

$$\left[ a) 2x + 5y - 20 = 0, 2x + 5y + 10 = 0; b) A(-5; 6), B(0; -2); c) C(5; -4); d) D(0; 4); 2(\sqrt{29} + \sqrt{89}); 30 \right]$$

261

ESERCIZI