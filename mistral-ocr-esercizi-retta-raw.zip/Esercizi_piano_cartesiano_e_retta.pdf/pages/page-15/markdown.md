Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

194 Indica per quali valori di \(a\) la retta di equazione \(y = (2 - a)x + a - 3\) forma con l'asse \(x\) un angolo acuto. Se \(a = 2\), che angolo forma la retta con l'asse \(x\)? \([a < 2]\)
195 Determinina la condizione sul parametro \(a\) affinché la retta di equazione \(2ay + (a - 2)x - 1 = 0\) formi un angolo retto con l'asse \(x\). \([a = 0]\)
196 Considera la retta di equazione \( y = 2kx - 3k - 6 \) e indica per quali valori di \( k \) interseca l'asse \( y \) in un punto di ordinata negativa. \( [k > -2] \)
197 Trova i valori di \(k\) tali che la retta di equazione \(-3y + (3k - k^2)x + 5 = 0\) formi con l'asse \(x\) un angolo ottuso. \([k < 0 \vee k > 3]\)

Determina il coefficiente angolare delle rette passanti per O(0; 0) che formano con l'asse x gli angoli indicati.

198 30°; 45°; 60°. [√3/3; 1; √3] 199 120°; 135°; 150°. [-√3; -1; -√3/3]

# Grafici di funzioni definite a tratti

Rappresenta graficamente le seguenti funzioni.

![img-40.jpeg](img-40.jpeg)

200 y = {2x - 1 se x ≤ 0, -1 se 0 < x ≤ 4, -x + 6 se x > 4}

# COMPLETA LO SVOLGIMENTO

Il grafico della funzione è costituito da [ ] tratti.

Troviamo due punti che soddisfano l'equazione y = 2x - 1, con x [ ] 0, e disegniamo la semiretta.

Disegniamo il segmento per 0 < x ≤ 4, osservando che appartiene a una retta parallela all'asse [ ].

Rappresentiamo la semiretta di equazione y = -x + 6 usando punti con ascissa maggiore di [ ].

201 y = { -x + 7 se x ≤ 0, 7 se x > 0}

202 y = { -5x + 1 se x ≤ 1, 2x se x > 1}

203 y = { -1 se x < 2/3, 3x + 2 se x ≥ 2/3}

204 y = { 2x - 1 se x ≤ 1, -2x + 4 se x > 1}

205 y = { -x - 1 se x ≤ 0, -3 se 0 < x ≤ 3, x - 6 se x > 3}

206 y = { 2x + 1 se x ≤ -2, -x - 5 se -2 < x < 1, x - 6 se x ≥ 1}

# RISOLVI CON PYTHON

Scrivi un programma che disegni il grafico della funzione indicata.

207 y = x + |x - 2|

# RISOLVI IN 2 PASSI

1 Studia il segno dell'argomento del valore assoluto, ponendolo maggiore o uguale a 0.
2 Applicando la definizione di valore assoluto, scrivi la funzione data come funzione definita a tratti e rappresenta graficamente.

208 y = -|x|

209 y = |x| + 1

210 y = 2|x| + 1

211 y = |x - 4|

212 y = -|x - 2|

213 y = |x + 1| - 1

214 y = |2x + 3| - 3

215 y = |x + 3| + x + 3

216 y = |1/2 x - 2|

217 y = 2 - |x/3|

218 y = ||x| - 2|

219 y = |x - 2| + |1 - x|

220 y = 2√x² - x

221 y = |3 - x| + |x|

222 y = ||x| - 1| + 2

228