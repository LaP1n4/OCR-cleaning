DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

# Retta passante per due punti

Teoria a pagina 205

1 attività interattiva

I FONDAMENTALI

Prova tu fai un esercizio simile interattiva

# Scrivere l'equazione della retta passante per due punti

Per ogni coppia di punti, scriviamo l'equazione della retta PQ:

a. $P(\sqrt{5}; 3), Q(\sqrt{5}; -6);$

b. $P(2; -1), Q(-\sqrt{2}; -1);$

c. $P\left(-\frac{1}{3}; 2\right), Q(3; -8).$

a. I punti \(P\) e \(Q\) hanno la stessa ascissa \(\sqrt{5} \rightarrow PQ\) ha equazione \(x = \sqrt{5}\).
b. I punti \(P\) e \(Q\) hanno la stessa ordinata \(-1\to PQ\) ha equazione \(y = -1\)
c. I punti \(P\) e \(Q\) hanno ascisse e ordinate diverse, quindi l'equazione di \(PQ\) e

$$\frac{y - y_P}{y_Q - y_P} = \frac{x - x_P}{x_Q - x_P} \rightarrow \frac{y - 2}{-8 - 2} = \frac{x - \left(-\frac{1}{3}\right)}{3 - \left(-\frac{1}{3}\right)} \rightarrow y - 2 = (-10) \cdot \frac{x + \frac{1}{3}}{\frac{10}{3}} \rightarrow$$

$$y - 2 = -3x - 1 \rightarrow y = -3x + 1.$$

Se $x_A \neq x_B$ e $y_A \neq y_B$,

$$\frac{y - y_A}{y_B - y_A} = \frac{x - x_A}{x_B - x_A}.$$

# Scrivi l'equazione della retta passante per i punti A e B.

385

A(3; 0),

B(0; 5).

388

A(1; 1),

B(-1; -1).

391

A(8; 8),

B(2; -2).

386

A(-5; 0),

B(7; -2).

389

A($\frac{1}{2}$; -6),

B(2; -3).

392

A($\frac{1}{3}$; -1),

B($2; \frac{2}{3}$).

387

A(2; -1),

B(0; -4).

390

A(5; 2),

B(-3; 2).

393

A(0; 0),

B(5; 4).

GENERALIZZA CON PYTHON

Scrivi un programma che, acquisite in input le coordinate di due punti A e B, con $x_A \neq x_B$ e $y_A \neq y_B$, fornisca l'equazione della retta AB, nella forma $y = mx + q$.

# LEGGI IL GRAFICO Scrivi le equazioni delle rette passanti per i punti A e B di ogni figura.

![img-72.jpeg](img-72.jpeg)

394

![img-73.jpeg](img-73.jpeg)

![img-74.jpeg](img-74.jpeg)

![img-75.jpeg](img-75.jpeg)

395

![img-76.jpeg](img-76.jpeg)

![img-77.jpeg](img-77.jpeg)

![img-78.jpeg](img-78.jpeg)

![img-79.jpeg](img-79.jpeg)

396

Scrivi l'equazione della retta passante per $A\left(\frac{5}{2}; -2\right)$ e $B\left(3; -\frac{3}{2}\right)$ e trova l'ordinata del suo punto C di ascis-

$$\left[ 2x - 2y - 9 = 0; y_C = -\frac{11}{2} \right]$$

241

ESERCIZIO