VERSO L'ESAME

$$\overline{DE} = 4 - 3 = 1$$

$$\overline{DF} = \sqrt{(3 - 2)^2 + \left(\frac{9}{2} - 4\right)^2} = \sqrt{1 + \frac{1}{4}} = \frac{\sqrt{5}}{2}$$

$$\overline{EF} = \sqrt{(3 - 2)^2 + \left(\frac{9}{2} - 3\right)^2} = \sqrt{1 + \frac{9}{4}} = \frac{\sqrt{13}}{2}$$

Il perimetro è $1 + \frac{\sqrt{5}}{2} + \frac{\sqrt{13}}{2}$.

- Determiniamo ora l'ortocentro $H$ di $DEF$ intersecando le altezze da $E$ e $F$.

La retta passante per $F$ e perpendicolare a $DE$ ha equazione $y = \frac{9}{2}$.

La retta passante per $E$ e perpendicolare alla retta $DF$ (che ha coefficiente angolare $\frac{1}{2}$) ha equazione:

$$y - 3 = -2(x - 2) \rightarrow y = -2x + 7.$$

Le coordinate di $H$ si ottengono risolvendo il seguente sistema.

$$\begin{cases} y = \frac{9}{2} \\ y = -2x + 7 \end{cases} \rightarrow \begin{cases} y = \frac{9}{2} \\ 2x = 7 - \frac{9}{2} \end{cases} \rightarrow x = \frac{5}{4} \rightarrow H\left(\frac{5}{4}; \frac{9}{2}\right)$$

c. Cerchiamo $m$ in modo che la retta di equazione $y = mx$ divida $ABCD$ in due poligoni equivalenti.

- Se $0 \le m \le 1$, la retta di equazione $y = mx$ interseca il segmento $CB$ in $G$ e il segmento $DA$ in $L$.

Troviamo le coordinate di $G$:

$$\begin{cases} y = mx \\ x = 6 \end{cases} \rightarrow \begin{cases} y = 6m \\ x = 6 \end{cases} \rightarrow G(6; 6m).$$

![img-133.jpeg](img-133.jpeg)

$L$ ha invece coordinate $(2; 2m)$.

- L'area del trapezio $ABCD$ è:

$$\frac{(\overline{BC} + \overline{AD}) \cdot \overline{AB}}{2} = \frac{(6 + 4) \cdot 4}{2} = 20.$$

- L'area del trapezio $ABGL$ è:

$$\frac{(\overline{BG} + \overline{AL}) \cdot \overline{AB}}{2} = \frac{(6m + 2m) \cdot 4}{2} = 16m, \quad \text{con } 0 \le m \le 1.$$

- Se la retta di equazione $y = mx$ divide il trapezio in due poligoni equivalenti, deve essere:

$$16m = \frac{20}{2} \rightarrow m = \frac{5}{8}, \text{valore accettabile.}$$

d. Calcoliamo le aree dei due poligoni se $\alpha = 30^\circ$.

Se $\alpha = 30^\circ$, allora è $G\left(6; 6\frac{\sqrt{3}}{3}\right)$ e $m = \frac{\sqrt{3}}{3}$, pertanto $ABGL$ ha area $16\frac{\sqrt{3}}{3}$ e $LGCD$ ha area $20 - 16\frac{\sqrt{3}}{3}$.

39

# LEGGI IL GRAFICO

![img-134.jpeg](img-134.jpeg)

a. Nel triangolo \( ABC \) della figura \( G \) è il baricentro. Determina le coordinate di \( C \) e scrivi l'equazione della retta \( DE \) che passa per \( C \).
b. Dimostra che \( ABDE \) è un trapezio e calculane l'area.
c. Congiungi i punti medi \(M\) e \(N\) dei lati obliqui del trapezio e verifica che il segmento ottenuto è parallelo alle basi e congruente alla loro semisomma.
d. Verifica che l'asse \(y\) è bisettrice dell'angolo \(\widehat{BAC}\)

[a) $C(7; -4)$, $DE: x - y - 11 = 0$; b) $105$]

271

VERSO L'ESAME