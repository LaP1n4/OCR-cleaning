FASCI DI RETTE

Paragrafo 7

# Studio di un fascio di rette

OLTRE I FONDAMENTALI

# Studiare un fascio di rette

Studiamo il fascio di rette di equazione:

$$(k + 1)x + (2k + 1)y + k + 2 = 0.$$

# 1 Determiniamo le generatrici per individuare la natura del fascio.

Svolgiamo i calcoli e raccogliamo k.

$$\begin{array}{l} kx + x + 2ky + y + k + 2 = 0 \rightarrow \\ x + y + 2 + k(x + 2y + 1) = 0 \end{array}$$

Le generatrici hanno equazioni:

$$\begin{array}{l} t: x + y + 2 = 0; \text{—— generatrice che si ottiene per } k = 0 \\ u: x + 2y + 1 = 0. \text{—— generatrice che non si ottiene} \\ \text{per alcun valore reale di } k \end{array}$$

Le generatrici non hanno lo stesso coefficiente angolare.

Infatti $m_t = -1$ e $m_u = -\frac{1}{2}$, quindi non sono parallele.

Si tratta quindi di un fascio proprio.

Se fosse improprio, lo studio sarebbe concluso.

Le generatrici si ottengono separando i termini che contengono il parametro k da quelli che non lo contengono e raccogliendo k.

La seconda generatrice non si può ottenere dall'equazione del fascio per alcun valore di k. Possiamo dire che si ottiene dall'equazione

$$\frac{1}{k}(ax + by + c) + (a'x + b'y + c') = 0 \text{ per } k \to \pm \infty.$$

La posizione reciproca delle due generatrici definisce la natura del fascio.

In alternativa, potremmo analizzare la natura del fascio anche considerando il coefficiente angolare dell'equazione iniziale: se varia con k il fascio è proprio, altrimenti è improprio.

# 2 Determiniamo il centro del fascio.

Per trovare il centro si possono intersecare due rette qualsiasi del fascio, per esempio le generatrici oppure le due rette parallele agli assi, che si ottengono annullando il coefficiente di x e quello di y nell'equazione iniziale.

Le rette del fascio si intersecano nel centro. Per trovare le sue coordinate mettiamo a sistema le equazioni delle generatrici:

$$\left\{\begin{array}{l} x + y + 2 = 0 \\ x + 2y + 1 = 0 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -y - 2 \\ -y - 2 + 2y + 1 = 0 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -y - 2 \\ y = 1 \end{array}\right. \rightarrow \left\{\begin{array}{l} x = -3 \\ y = 1 \end{array}\right. \rightarrow C(-3; 1).$$

# 3 Stabiliamo il senso di rotazione delle rette del fascio al crescere di k.

Per esempio, per k = -1 otteniamo la retta di equazione y = 1, che rappresentiamo nel piano cartesiano.

![img-113.jpeg](img-113.jpeg)

Per decidere se il senso di rotazione delle rette del fascio è orario o antiorario è sufficiente rappresentare, oltre alle due generatrici, una retta qualsiasi del fascio: si parte, per esempio, dalla seconda generatrice, che si ottiene per k → ±∞, e si osserva in quale verso si deve ruotare per incontrare valori crescenti di k.

La seconda generatrice u è origine di due semipiani: ne scegliamo uno e vediamo che al crescere di k le rette ruotano attorno al centro C in senso antiorario, come indica la freccia arancione.

ESERCIZI

259