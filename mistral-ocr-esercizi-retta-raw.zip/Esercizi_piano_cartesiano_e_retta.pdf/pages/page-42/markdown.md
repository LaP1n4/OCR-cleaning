FASCI DI RETTE

Paragrafo 7

527 Nel sistema di disequazioni $$\begin{cases} x - y + 1 \leq 0 \\ x + y \geq 0 \\ 3y - x + k \leq 0 \end{cases}$$ trova:

a. per quali valori di \(k\) il systemammette soluzione;
b. il valore di \( k \) per cui la regione di piano soluzione del systemà è un triangolo rettangolo che ha ipotenusa lunga \( \frac{\sqrt{10}}{10} \). [a) \( k \leq -2 \); b) \( k = -\frac{12}{5} \)]

528 Un rombo ha due lati che si trovano sulle rette di equazioni \(3x - 4y + 12 = 0\) e \(x + 2 = 0\), il raggio della circonferenza inscritta è \(\frac{13}{4}\) e il suo centro ha coordinate positive. Determina i vertici, il perimetro e l'area del rombo. \(\left[A\left(-2;\frac{3}{2}\right),B\left(\frac{9}{2};\frac{51}{8}\right),C\left(\frac{9}{2};\frac{29}{2}\right),D\left(-2;\frac{77}{8}\right),\frac{65}{2};\frac{845}{16}\right]\)
539 Disegna i grafici delle funzioni \( y = |x - 1| + |x + 4| - 2 \) e \( y = x - 2|x - 2| + 4 \) e trova i loro punti di intersezione. \(\left[A(1;3),B\left(\frac{7}{3};\frac{17}{3}\right)\right]\)
530 Data la retta \(r\) di equazione \(x - 2y + 6 = 0\) e il punto \(A(5;1)\), sua \(B\) il punto in cui \(r\) in contra la retta \(s\) per \(A\) parallela all'asse delle ascisse e sua \(P\) un generico punto su \(r\). Indicato con \(M\) il punto medio di \(AP\) e con \(H\) la proiezione di \(P\) su \(s\), determina le coordinate di \(P\) affinché si abbia:

$$\overline{PH}^2 + \overline{HM}^2 = \frac{9}{16} \overline{BP}^2.$$

$$[P_1(0; 3) \text{ e } P_2(-40; -17)]$$

# 7 Fasci di rette

# Fascio improprio

Teoria a pagina 208

1 attività interattiva

531 TEST Una sola delle seguenti equazioni non rappresenta un fascio improprio. Quale?

A $$y = -2x + 2 + a$$

C $$y = 3x + 5 - k$$

B $$2x - 4ky = 9$$

D $$ky - kx = 2$$

532 AL VOLO Scrivi l'equazione del fascio improprio a cui appartiene l'asse y.

# I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un fascio improprio di rette

Scriviamo l'equazione del fascio improprio di rette contenente la retta di equazione $$2x + y - 3 = 0$$ e disegniamo alcune rette del fascio.

Scriviamo l'equazione della retta in forma esplicita, per ricavare il suo coefficiente angolare m:

![img-109.jpeg](img-109.jpeg)

$$y = -2x + 3 \rightarrow m = -2.$$

Il fascio di rette ha equazione $$y = -2x + q$$.

Disegniamo le rette corrispondenti a tre valori di q, per esempio 0, 2, -2. Le rette corrispondenti sono:

$$y = -2x; \quad y = -2x + 2; \quad y = -2x - 2.$$

Le rette di un fascio improprio sono tutte parallele, perciò hanno lo stesso coefficiente angolare e cambia solo l'ordinata all'origine.

533 Scrivi l'equazione del fascio improprio contenente la retta di equazione $$8x - 4y + 6 = 0$$ e disegna alcune rette del fascio.

255

ESERCIZI