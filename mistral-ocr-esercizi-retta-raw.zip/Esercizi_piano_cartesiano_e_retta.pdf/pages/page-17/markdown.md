Capitolo 4 PIANO CARTESIANO E RETTA

ESERCITI

256 CHIMICA Gli studenti Ada e Thomas riscaldano un campione di acido stearico fino alla temperatura di 90 °C e poi lo lasciano raffreddare. Osservano che l'andamento nel tempo t della temperatura y del campione può essere descritto dalla funzione

![img-42.jpeg](img-42.jpeg)

$$y = \begin{cases} -7t + 90 & \text{se } 0 \le t < 3,0 \\ t, & \text{se } 3,0 \le t < 11, \\ -5t + 124 & \text{se } t \ge 11 \end{cases}$$

con la temperatura y in °C e il tempo t in minuti. Durante l'intervallo $3,0 \le t < 11$ la temperatura è rimasta costante ($t_0$) perché è avvenuto il passaggio dallo stato liquido allo stato solido.

a. Calcola la temperatura di solidificazione \(t\), misurata dagli studenti.
b. Se gli studenti terminano l'esperienza nell'istante in cui il campione raggiunge la temperatura ambiente di \(24^{\circ}\mathrm{C}\) quantato è durato complessivamente il raffreddamento?
c. Rappresenta la curva di raffreddamento nel piano cartesian. [a) \(69^{\circ}\mathrm{C}\); b) 20 minuti]

# Dal grafico all'equazione

LEGGI IL GRAFICO Per ogni grafico scrivi l'equazione della retta relativa.

![img-43.jpeg](img-43.jpeg)

![img-44.jpeg](img-44.jpeg)

![img-45.jpeg](img-45.jpeg)

260 Trova l'equazione della retta che passa per il punto \(P(1; - 5)\) ed è parallela all'asse \(x\)
261 Traccia la retta parallela all'asse \(y\) passante per il punto \(A(-2;1)\) e scrivi la sua equazione.
262 Determinina le equazioni delle rette passanti per l'origine e per i seguenti punti:

a. \((-1;\frac{1}{2})\)
b. \((2; - 4)\)
c. (3;9).

263 Scrivi le equazioni:

a. delle rette passanti per il punto \(P(2; - 6)\) paralleleagliassi cartesiani;
b. della retta passante per \(P\) e per l'origine.

264 a. Disegna la retta passante per l'origine e per il punto $A\left(\frac{1}{4}; \frac{1}{3}\right)$.

b. Scrivi la sua equazione.
c. Verifica che la retta passa anche per i punti \(B(3;4),C(-6; - 8),D\left(1;\frac{4}{3}\right)\)

$$\left[y = \frac{4}{3}x\right]$$

265 LEGGI IL GRAFICO Scrivi le equazioni dei seguenti grafici.

![img-46.jpeg](img-46.jpeg)

![img-47.jpeg](img-47.jpeg)

![img-48.jpeg](img-48.jpeg)

230