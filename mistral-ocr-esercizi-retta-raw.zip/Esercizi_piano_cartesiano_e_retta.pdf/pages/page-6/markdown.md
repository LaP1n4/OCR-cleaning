PUNTI E SEGMENTI

Paragrafo 1

Determina le coordinate del punto medio del segmento di estremi A e B.

81 A(4; -3), B(10; -3).

85 A(1/3; 4), B(4; 1/2).

82 A(5; 1), B(5; 9).

86 A(1/3; -4), B(-1/2; 3).

83 A(0; 1), B(1; -1).

87 A(-2√3; 1), B(4√3; -3).

84 A(-3; 1/4), B(6; 3/4).

88 A(a-1; 2), B(2a+1/2; -2a).

89 TEST Il segmento AB ha punto medio M(5/2; 5). Se A(-1/2; -1), allora:

A B(11; 11/2).

B B(11/2; 11).

C B(-11/2; -11).

D B(-11; -11/2).

Per ogni segmento AB sono indicate le coordinate di un estremo e quelle del punto medio M. Calcola le coordinate dell'altro estremo.

90 A(2; 4), M(0; 2).

93 A(3/2; -4), M(3/2; 2).

91 A(3; 5), M(2; 1).

94 B(3/2; 5/2), M(4; 5).

92 A(-2; -1), M(-1; -4).

95 B(4/3; -3/4), M(0; 0).

GENERALIZZA CON PYTHON

Considera un segmento e il suo punto medio M. Scrivi un programma che chieda le coordinate di uno dei due estremi e di M e fornisca le coordinate dell'altro estremo. Negli input usa Fraction() del modulo fractions, utile per inserire anche frazioni nella forma m/n, per esempio 5/2, -3/4.

96 Trova le coordinate del punto P' simmetrico di P(2; 1) rispetto a C(5; 2).

[P'(8; 3)]

97 Nel triangolo ABC, di vertici A(-2; 4), B(0; 2), C(4; 6), determina i punti medi dei lati e la misura delle mediane. {(-1; 3), (2; 4), (1; 5); √34; 4; √10}

98 Dato il triangolo ABC con A(1; 3), B(6; 1) e C(3; -5), considera i punti medi M e N dei lati AC e BC e verifica che MN = 1/2 AB.

99 Dati i punti A(2k-1; 2) e B(3; 2k+5), trova k in modo che il punto medio del segmento AB abbia ascissa doppia dell'ordinata. [k = -6]

100 Il segmento AB ha per estremi i punti A(1; 2a+1) e B(a-2; -a). Trova a sapendo che il punto medio di AB dista √5 dall'origine O. [a = ±3]

101 I punti A(2; 1) e B(5; 5) sono vertici del triangolo ABC e M(1/2; -1) è il punto medio del lato AC. Determina:

a. le coordinate di C;

b. il perimetro del triangolo.

[a) C(-1; -3); b) 20]

102 I punti A(-2; 3) e B(3; 4) sono vertici del triangolo ABC. Sapendo che M(1; 1) è il punto medio del lato BC:

a. determina le coordinate di C;

b. verifica che il triangolo è isoscele;

c. calcola l'area del triangolo.

[a) C(-1; -2); c) 13]

103 Verifica che il triangolo ABC di vertici A(1; 3), B(4; 1), C(3; 11/4) è isoscele e trova la misura dell'altezza relativa alla base. [√13/4]

104 Determina le coordinate dei punti A' e B', simmetrici di A(0; 1) e B(5; 0) rispetto a C(2; 2), e verifica che il quadrilatero ABA'B' è un parallelogramma. [A'(4; 3); B'(-1; 4)]

![img-17.jpeg](img-17.jpeg)

ESERCIZI

219