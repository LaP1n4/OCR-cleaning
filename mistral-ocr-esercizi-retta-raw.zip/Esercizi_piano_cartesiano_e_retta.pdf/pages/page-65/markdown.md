Capitolo 4 PIANO CARTESIANO E RETTA

![img-148.jpeg](img-148.jpeg)

VERCO I STAME

63 MOTO RETTILINEO Un punto materiale si muove secondo la legge oraria

$$s(t) = |-2 + t| + |-1 + t|, \quad \text{con } 0 \le t \le 5,0,$$

dove la posizione s è espressa in metri e il tempo t in secondi.

a. Rappresenta il grafico di \( s(t) \) e descivi il moto del punto materiale.
b. Qual è lo spostamento nell'intervallo considerato?
c. Determinina la velocità \( v(t) \) al variate di \( t \) e rappresenta il suo grafico.
d. Calcola la velocità media nell'intero tragitto.

[b) 4,0 m; d) 0,80 m/s]

64 DILATAZIONE TERMICA La variazione di volume $\Delta V = V - V_0$ di un liquido è legata al coefficiente di dilatazione $\alpha$ della sostanza e alla variazione di temperatura $\Delta T = T - T_0$ secondo la relazione:

$$\Delta V = \alpha V_0 \Delta T,$$

dove il volume è misurato in litri, la temperatura in °C, $V_0$ è il volume iniziale e $T_0$ la temperatura iniziale.

Nella fase di sperimentazione di un farmaco un'azienda farmaceutica prova a trattare 50 litri di glicerina ($\alpha = 0,53 \cdot 10^{-3} \text{°C}^{-1}$) a diverse temperature controllate $T_0$.

a. Scrivi la relazione \(V(T)\) e stabilisci se, considerando \(T_{0}\) come parametro, descive un fascio di rette proprio o improprio. Determinina l'eventuale centro o coefficiente angolare del fascio.
b. Una volta trattata, la glicerina passa alla temperatura \(T_{0}\) alla temperatura di \(25^{\circ}C\) e il suo volume si riduce del \(2.8\%\). Determinina la corrispondente retta del fascio.
c. Durante il trattamento descritto nel punto b l'azienda decide di immagazzinare la glicerina in cinque contentitori uguali. Come diventa la funzione \( V(T) \) per ciascun contentitore?

[a) improprio; $m = 2,7 \cdot 10^{-2} \text{ L} \cdot \text{°C}^{-1}$; b) $V(T) = 2,7 \cdot 10^{-2} T + 48$; c) $V(T) = 5,4 \cdot 10^{-3} T + 9,6$]

65 CONSERVAZIONE DELL'ENERGIA Un carrello di massa $m = 15$ kg, inizialmente in cima a un piano inclinato di altezza h, scivola senza attrito.

![img-149.jpeg](img-149.jpeg)

In figura sono rappresentate l'energia potenziale gravitazionale $U(x)$ e l'energia meccanica $E$ in funzione dello spostamento x lungo il piano inclinato.

a. Scrivi l'espressione analitica dell'energia potenziale, dell'energia meccanica e dell'energia cinetica \(K(x)\) , e rappresenta quest'ultima nel piano cartesian.
b. Determinina l'altezza \(h\) e l'angolo di inclinazione del piano.
c. Stabilisci dopo quanti metri di scivolamento lungo il piano l'energia cinetica è uguali all'energia potenziale e calcola il loro valore.

$$\begin{array}{l} E(x) = U(x) + K(x) \\ U(x) = m \cdot g \cdot h(x) \end{array}$$

[a) $U = -5,0 \cdot 10^{-2} x + 5$; $E = 5$; $K = 5,0 \cdot 10^{-2} x$; b) $h = 34 \text{ m}$; $\alpha = 20^\circ$; c) $50 \text{ m}$; $U = K = 2,5 \text{ kJ}$]

66 MOTO NEL PIANO Per aiutare un bagnante in difficoltà (punto C), due bagnini, partendo entrambi nello stesso momento dal punto A, decidono di adottare due diverse strategie: il primo corre sulla spiaggia e nuota direttamente verso C, entrando in acqua nel punto B; il secondo decide di entrare in acqua nel punto B', compiendo il percorso $AB'C$.

Entrambi corrono a una velocità di 3,0 m/s e nuotano a una velocità di 1,8 m/s.

![img-150.jpeg](img-150.jpeg)

a. Calcola l'ascissa di \(C\) nel riferimento in figura.
b. Quale delle due strategie comporta il percorso più breve? Quale consente di arrivare prima al bagnante?
c. Considera quale altra scelta per il punto \(B\), e verifica che il tempo di percorrenza è maggiore di 29 s.

[a) 52 m; b) $d_{ABC} = 65 \text{ m}, t_{ABC} = 31 \text{ s}$;

$d_{AB'C} = 68 \text{ m}, t_{AB'C} = 29 \text{ s}$]

278