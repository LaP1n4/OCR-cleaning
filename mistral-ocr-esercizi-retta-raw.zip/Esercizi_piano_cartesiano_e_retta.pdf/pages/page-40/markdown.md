PROBLEMI CON LE RETTE

RIEPILOGO

# RIEPILOGO Problemi con le rette

# 503 VERO O FALSO?

a. L'equazione $|x| + |y| = 2$ individua nel piano cartesiano un quadrato di area 8.

V F

b. Le due rette di equazioni $x + 2y + 1 = 0$ e $x - 2y + 1 = 0$ sono simmetriche rispetto all'asse $x$.

V F

c. La bisettrice degli angoli acuti formati dalle due rette di equazioni $4x - 3y + 1 = 0$ e $3x = 4y + 2$ è la retta $x + y + 3 = 0$.

V F

d. Le due rette di equazioni $y = 3x + 5$ e $y = -3x + 5$ sono simmetriche rispetto all'asse $y$.

V F

504 Considera la retta passante per $A(0; 5)$ e $B(-2; -3)$. Determina su tale retta un punto $C$ la cui ascissa è tripla dell'ordinata. Considera la retta parallela all'asse $x$ passante per $A$ e la retta parallela all'asse $y$ passante per $B$. Determina il punto $D$ di intersezione di queste due rette e calcola l'area del triangolo $DAC$.

$$\left[ C \left( - \frac { 1 5 } { 1 1 } ; - \frac { 5 } { 1 1 } \right) ; D ( - 2 ; 5 ) ; \frac { 6 0 } { 1 1 } \right]$$

505 I lati di un quadrilatero $ABCD$ appartengono alle rette di equazioni: $x - y = 0$, $x + y - 2 = 0$, $x + y - 6 = 0$, $x - y - 4 = 0$. Determina le coordinate dei vertici, verifica che $ABCD$ è un quadrato e calcolane area e perimetro.

$$[ A ( 1 ; 1 ) , B ( 3 ; 3 ) , C ( 5 ; 1 ) , D ( 3 ; - 1 ) ; 8 ; 8 \sqrt { 2 } ]$$

506 Da un punto $A(-5; -4)$ conduci la parallela $r$ e la perpendicolare $s$ alla retta $t$ di equazione $y = 2x + 1$. Detto $B$ il punto di intersezione di $s$ e $t$ e detti $C$ e $D$ i punti di intersezione rispettivamente di $t$ e $r$ con l'asse delle ordinate, stabilisci che tipo di quadrilatero è $ABCD$ e calcolane l'area.

[trapezio rettangolo; 20]

507 Un parallelogramma $ABCD$ ha i lati $AB$, $BC$ e $DA$ che si trovano rispettivamente sulle rette di equazioni $2x + y - 2 = 0$, $4x - 7y - 4 = 0$ e $4x - 7y + 14 = 0$.

Sapendo che $C$ ha coordinate $(8; 4)$, determina le coordinate degli altri vertici del parallelogramma e del punto di incontro delle diagonali.

$$[ A ( 0 ; 2 ) , B ( 1 ; 0 ) , D ( 7 ; 6 ) , M ( 4 ; 3 ) ]$$

508 Il vertice $A$ di un triangolo $ABC$ ha coordinate $(-2; 3)$; si sa che l'altezza uscente dal vertice $C$ ha equazione $x - y - 2 = 0$ e che l'equazione del lato $BC$ è $2x - 3y - 2 = 0$. Calcola le coordinate degli altri due vertici del triangolo e la sua area.

$$\left[ C ( 4 ; 2 ) , B ( 1 ; 0 ) ; \frac { 1 5 } { 2 } \right]$$

# LEGGI IL GRAFICO

509 Deduci dal grafico:

a. le equazioni di \(f(x)\in g(x)\)
b. per quali valori di \(x\) si ha \(f(x) <   g(x)\)

![img-106.jpeg](img-106.jpeg)

![img-107.jpeg](img-107.jpeg)

511 LEGGI IL GRAFICO Utilizzando i dati della figura stabilisci se il triangolo $ABC$ è rettangolo.

510 Il quadrilatero $ABCD$ della figura è un quadrato. Trova le coordinate di $D$. [(2; 8)]

512 ASSOCIA a ciascuna coppia di rette la proprietà soddisfatta da entrambe le rette.

![img-108.jpeg](img-108.jpeg)

a. \(3x + y - 2 = 0\mathrm{e}y = 3x + 2.\)
b. \(3x - 2y + 4 = 0\mathrm{e}2x + 3y - 6 = 0.\)
c. \(2y - x - 1 = 0\mathrm{e}y = 2x + 2.\)
d. \(6x - 3y + 1 = 0\mathrm{e}2x - y + 3 = 0.\)

1. Intersecano l'asse \(x\) nel punto di ascissa \(-1\).
2. Sono perpendiculari.
3. Hanno la stessa distanza dall'origine.
4. Sono parallele.

ESERCIZI

253