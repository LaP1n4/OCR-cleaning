Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

534

Disegna cinque rette del fascio di equazione $y = 3x + k$, con $k \in \mathbb{R}$.

GENERALIZZA CON PYTHON

Scrivi un programma che chieda in input il coefficiente angolare della retta di equazione $y = mx + k$ e disegni le rette del fascio per $k = -7, -4, -1, 2, 5$.

535

Scrivi l'equazione del fascio di rette parallele alla retta di equazione $y = -4x + 5$ e l'equazione del fascio di rette perpendicolari alle precedenti. Rappresenta alcune rette di ciascun fascio.

536

AL VOLO Dato il fascio di equazione $y = 2x + 3k + 1$, stabilisci per quali valori di $k$ si ottengono la retta del fascio passante per l'origine e la retta passante per il punto (0; 4).

537

Scrivi l'equazione del fascio improprio contenente la retta che passa per i punti $A(-3; 2)$ e $B(1; -1)$ e rappresenta altre due rette del fascio.

$$\left[ y = -\frac{3}{4}x + k \right]$$

538

Scrivi l'equazione del fascio improprio contenente la retta $2x - 5y - 10 = 0$ e determina l'equazione della retta del fascio passante per il punto $(-4; -1)$.

$$\left[ 2x - 5y + 3 = 0 \right]$$

# Fascio proprio

Teoria a pagina 209

1 attività interattiva

539

Quali delle seguenti equazioni rappresentano un fascio proprio di rette di centro $P(-1; 2)$?

a. $y = -2x + q$

b. $y = mx + 2 + m$

c. $my + x - 2m + 1 = 0$

d. $y = mx + m - 2$

Determina per ogni fascio proprio il relativo centro e scrivi l'equazione della retta esclusa.

540

$$mx + y - 2m + 1 = 0$$

543

$$6kx + 10k - 3y = 0$$

541

$$6mx - 6y - 10m + 3 = 0$$

544

$$3y - 6m + mx + 3 = 0$$

542

$$3y - mx + 2 = 0$$

545

$$5y + 5m + 2 - 5mx = 0$$

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un fascio proprio di rette di centro assegnato

Scriviamo l'equazione completa del fascio proprio di rette passante per il punto $P(-3; \frac{4}{3})$ e disegniamo le rette del fascio aventi coefficiente angolare $m = 0$ e $m = 1$.

Usando l'equazione del fascio per $P$, otteniamo

$$y - \frac{4}{3} = m(x + 3) \rightarrow y = mx + 3m + \frac{4}{3},$$

a cui dobbiamo aggiungere la retta parallela all'asse $y$, di equazione $x = -3$.

L'equazione completa del fascio è quindi:

![img-110.jpeg](img-110.jpeg)

$$y = mx + 3m + \frac{4}{3} \vee x = -3, \quad \text{con } m \in \mathbb{R}.$$

Troviamo le rette del fascio con coefficiente angolare 0 e 1:

se \(m = 0\) ， \(y = \frac{4}{3}\)
se \(m = 1\) \(y = x + 3 + \frac{4}{3}\rightarrow y = x + \frac{13}{3}.\)

Poiché le due rette passano per $P$, per disegnarle basta determinare un solo altro punto su ciascuna.

L'equazione della retta generica passante per $P(x_0; y_0)$, $y - y_0 = m(x - x_0)$, con $m$ variabile, non rappresenta tutte le rette per $P$: manca la retta parallela all'asse $y$, di equazione $x = x_0$.

256