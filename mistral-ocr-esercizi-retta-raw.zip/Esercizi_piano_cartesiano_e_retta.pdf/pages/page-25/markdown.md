Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

340 Stabilisci per quale valore di \(a\) le due rette \(-x + 2y - 1 = 0\) e \(ax + (a - 1)y = 1\) risultano parallele. [1]
341 Trova per quali valori di \(a\) le due rette \(ax - 2y - 3 = 0\) e \((2a + 3)x + y - 1 = 0\) sono perpendiculari. \([-2\circ \frac{1}{2} ]\)
342 Stabilisci per quale valore di \(a\) le due rette \(4x + (a - 1)y = 0\) e \(2ax + 2(a - 1)y + 1 = 0\) risultano:

a. parallele;

b. perpendicolari.

[a) a = 1 ∨ a = 4; b) a = -1]

VERIFICA CON PYTHON

Scrivi un programma che, acquisito in input un valore di a, verifichi se le rette sono parallele, perpendicolari o incidenti ma non perpendicolari.

343 Determinina per quale valore di \(a\) le due rette di equazioni \(2x + 4y - 3 = 0\) e \((2 - a)x + (a + 1)y + 1 = 0\) risultano perpendicolari. \([a = -4]\)
344 Determinina per quale valore di \(k\) la retta di equazione \((k + 2)x + (k + 3)y - 1 = 0\) risulta:

a. parallela all'asse \(x\)
b. parallela all'asse \(y\)

c. parallela alla retta di equazione \(x - 2y = 0\)
d. perpendicularare alla retta di equazione \(4x - 2y + 1 = 0\)

[a) k = -2; b) k = -3; c) k = -7/3; d) k = -1]

345 Determina per quale valore di a la retta di equazione (a + 1)x + (2a - 3)y + 2a = 0 risulta:

a. parallela alla retta \(3x - 1 = 0\)
b. parallela alla retta \(2y + 5 = 0\)
c. perpendicularare alla retta \(9x - 3y + 1 = 0\)
d. parallela alla retta \(y = -x + 2\)

[a) a = 3/2; b) a = -1; c) a = -6; d) a = 4]

346 Calcola a in modo che la retta di equazione

(a + 3) x + y - 2 = 0, con a ∈ ℝ:

a. sia parallela all'asse \(x\)
b. sia parallela all'asse \(y\)
c. intersechi la retta \(y + x - 1 = 0\) in un punto del primo quadrante;
d. formi con gli assi cartesiani un triangolo di area \(\frac{1}{4}\)

[a) a = -3; b) ∉ a ∈ ℝ; c) a > -1;

d) a = -11 ∨ a = 5]

Discuti al variare di a la posizione reciproca delle rette r e s.

347 \(r:2ax + 2y - 3 = 0\) （20 \(s:(a - 2)y - x + 2 = 0.\) （20 \([a = 1:r / s;a\neq 1:r\in s\) incidenti]
348 \(r:(a^2 -a)x - y + a^2 = 0\) （20 \(s:(2a - 2)x - y + 1 = 0.\) （20 \([a = 1:r\equiv s;a = 2:r / s;a\neq 1\wedge a\neq 2:r\in s\) incidenti]

# 4 Determinare l'equazione di una retta

Equazione di una retta passante per un punto e di coefficiente angolare noto

Teoria a pagina 203

1 attività interattiva

349 VERO O FALSO?

a. L'asse \(y\) non ha coefficiente angolare. [V] F
b. L'equazione \( y - 1 = m(x - 2) \) rappresenta tutte le rette passanti per il punto \( P(2;1) \). [V] F
c. Tutte le rette di equazione \(y - 1 = m(x - 2)\) passano per il punto \(P(2;1)\). [V] F
d. L'equazione \( y = mx - m \) rappresenta tutte le rette passanti per \( P(1;0) \), esclusa la retta \( x = 1 \). [V] F

350 Scrivi l'equazione della retta passante per il punto P(2; -5) e di coefficiente angolare m = -3.

COMPLETA LO SVOLGIMENTO

Sostituendo nella formula a lato, abbiamo:

y = (x - 2) → y = -3x + 1.

Retta passante per A(x₁; y₁)

e di coefficiente angolare m:

y - y₁ = m(x - x₁).

238