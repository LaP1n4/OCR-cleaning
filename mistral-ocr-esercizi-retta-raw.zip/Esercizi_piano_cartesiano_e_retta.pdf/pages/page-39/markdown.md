Capitolo 4 PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

Prima di iniziare,
esercitati su laZ Esercizi

# Distanza di un punto da una retta e luoghi geometrici

1 Sia \(r_a\) la retta di equazione \((a + 1)x + (a - 2)y - 7a + 2 = 0\), con \(a \in \mathbb{R}\). Determinina per quale valore di a la distanza fra \(r_a\) e il punto \(P(2;3)\) è \(\sqrt{2}\). \(\left[a = \frac{1}{2}\right]\)
2 Determina i punti \(A\) e \(B\) della retta \(r\): \(3x - y + 2 = 0\) che hanno distanza \(4\sqrt{2}\) alla retta \(s\): \(x + y + 2 = 0\), con \(x_{A} < x_{B}\). Detti \(H\) e \(K\) i piedi delle perpendiculari a s condotte rispettovamente da \(A\) e da \(B\) e detto \(C\) il punto di intersezione fra \(r\) e \(s\), dimostra che i triangoli \(AHC\) e \(BKC\) sono congruenti e calculane l'area.

[A(-3; -7), B(1; 5); 8]

3 Un rombo \(ABCD\) ha area 30 e due vertici opposti hanno coordinate \(A(-7;4)\) e \(C(5; - 2)\). Trova le coordinate degli altri due vertici, \(B\in D\), e il raggio della circonferenza inscritta nel rombo. \(\left[(-2; - 1),(0;3);\frac{3}{2}\sqrt{2}\right]\)
4 Sia \(G\) il baricentro del triangolo di vertici \(A(2; - 1),B(-4; - 3)\in C(k - 5;2k + 2)\) . Trova per quali valori di \(k\) la distanza tra \(G\) e il lato \(AB\) vale \(\frac{7}{10}\sqrt{10}\) \(\left[k = 1\vee k = -\frac{37}{5}\right]\)
5 VERO FALSO? Considera il triangolo di vertici \(A(2;1)\) \(B(7;3)\in C(4;6)\)

a. Il triangolo è isoscele.
b. Incentro, circocentro e ortocentro apparpengono a una retta passante per \(A\)
c. L'asse del lato \(AC\) ha equazione \(2x + 5y = 23\)
d. La retta di equazione \(x + y = 8\) divide il triangolo in due poligoni equivalenti.

V F
V F
V F
V F

6 LEGGI IL GRAFICO ASSOCIA a ogni retta la sua equazione facendo riferimento al triangolo ABC in figura.

![img-104.jpeg](img-104.jpeg)

a. Bisettrice dell'angolo \(\widehat{A}\)
1. \(12x + 2y - 3 = 0\)
b. Asse di \(AB\)
2. \(2x + 12y = 43\)
c. Altezza relativa ad \(AB\)
3. \(x - y + 4 = 0\)
d. Asse di AC.
4. \(6x + y + 5 = 0\)

7 Scrivi l'equazione del luogo dei baricentri dei triangoli di vertici \(A(2k + 4; k - 1)\), \(B(k + 1; k + 4)\) e \(C(k + 3; 2k + 3)\) al variate di \(k \in \mathbb{R}\). [3x - 3y = 2]
8 Dati i punti \(A(-2; - 1)\in B(2;2)\) , determina il luogo \(\gamma\) dei punti tali che il triangolo ABC abbia area 10.

[3x - 4y + 22 = 0 ∨ 3x - 4y - 18 = 0]

9 Considera il triangolo di vertici A(-6; -4), B(1 - 3k/2; 2k + 4) e C(-5; 3). Trova per quali valori di k il circocentro del triangolo ha coordinate (-2; -1). Determina poi il raggio della circonferenza circoscritta.

[k = -1; r = 5]

10 Considera il triangolo di vertici A(4k; 4k²), B(4k; -1) e C(0; 1), k ≠ 0. Detto P il punto di intersezione tra la mediana relativa ad AB e l'asse di BC, determina l'equazione del luogo γ descritto dal punto P al variare del parametro k. Trova poi, se esistono, le coordinate dei punti di γ appartenenti alla bisettrice del I e III quadrante.

[y = 3/16 x², x ≠ 0; (16/3; 16/3)]

11 FISICA COMPOSIZIONE DI MOTI Un nuotatore si tuffa in un fiume e nuota perpendicolarmente alle sponde con velocità di modulo v_N = 0,8 m/s, mentre la corrente del fiume scorre a una velocità di modulo v_F = 1,5 m/s con la direzione indicata nella figura a lato.

![img-105.jpeg](img-105.jpeg)

a. Determinina l'equazione della traiettoria descritta dal nuotatore nel piano cartesianopappresentato.
b. Sapendo che il fume è长大o \(16\mathrm{m}\) ,calcola il tempo necessario per atraversarlo e la distanza totale percorsa dal nuotatore.

[a) 8x - 15y = 0; b) 20 s, 34 m]

ESERCIZI

252