Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

473 Determinina sulla retta di equazione \(3x + y = 0\) il punto equidistante dai punti \(A(2; - 1)\in B(4;3)\) . \([(-1;3)]\)
474 Dati due punti \(A(2;3),B(4;1)\) e la retta \(r\) di equazione \(3x - y + 5 = 0\) ,determina su \(r\) un punto C in modo che il triangolo ABC sua isoscele sulla base AB e calcula l'area del triangolo ABC. \([C(-3; - 4);12]\)
475 Sia C il punto in cui l'asse del segmento avente per estremi i punti \(A(-3;3)\) e \(B(1;5)\) in contra l'asse \(x\). Calco la l'area di ABC. [10]
476 Calcola l'area del triangolo isoscele \( ABC \) di base \( BC \), sapendo che \( B(-4;1) \), \( C(0; -1) \) e che il vertic A appariene alla retta di equazione \( 3x + 2y - 15 = 0 \). [15]
477 Trova per quali valori di \(k\) il punto \(P(k - 5;1 - 2k)\) appartiene all'asse del segmento di estremi \(A(-2;4)\) e \(B(1; - 2)\). \(\left[k = \frac{9}{10}\right]\)
478 Il segmento \(AB\) ha per estremi il punto \(A(1; - 2)\) e il punto \(B\), che si trova sull'asse \(x\). Trova l'ascissa di \(B\), sapendo che l'asse del segmento \(AB\) interseca l'asse \(y\) nel punto di ordinata 11. \([x_8 = -7\lor x_8 = 7]\)

# Bisettrici degli angoli formati da due rette

Teoria a pagina 207

479 Considera le rette r e s di equazioni

$$r: x + 2y - 1 = 0, \quad s: 2x + y + 2 = 0.$$

Scrivi l'equazione delle bisettrici degli angoli formati dalle due rette.

# COMPLETA LO SVOLGIMENTO

Se il punto P(x; y) è un generico punto di una bisettrice, allora deve avere la stessa __________ dalle rette r e s, cioè deve valere l'uguaglianza $$\overline{PH} = \overline{PK}$$.

Calcoliamo le distanze di P da r e da s:

$$\overline{PH} = \frac{|x + 2y - 1|}{\sqrt{5}}, \quad \overline{PK} = \frac{|2x + y + 2|}{\sqrt{5}}.$$

Uguagliamo le due distanze:

![img-103.jpeg](img-103.jpeg)

$$\frac{|x + 2y - 1|}{\sqrt{5}} = \frac{|2x + y + 2|}{\sqrt{5}} \rightarrow |x + 2y - 1| = |2x + y + 2|.$$

Questa equazione è equivalente alle due equazioni

$$x + 2y - 1 = \underline{\quad} (2x + y + 2), \text{ cioè:}$$

$$x + 2y - 1 = -(2x + y + 2) \vee x + 2y - 1 = 2x + y + 2 \rightarrow$$

$$3x \underline{\quad} + 1 = 0 \vee \underline{\quad} + y - 3 = 0.$$

Le bisettrici degli angoli formati da r e s hanno per equazioni:

$$3x + 3y + 1 = 0 \quad \text{e} \quad -x + y - 3 = 0.$$

Le bisettrici degli angoli formati da due rette sono perpendicolari fra loro.

# Scrivi le equazioni delle bisettrici degli angoli formati dalle coppie di rette.

480 $$2x + 3y - 1 = 0, \quad 2x - 3y + 3 = 0.$$

$$\left[x = -\frac{1}{2}; y = \frac{2}{3}\right]$$

481 $$x + 6y + 2 = 0, \quad 6x + y - 1 = 0.$$

$$[5x - 5y - 3 = 0; 7x + 7y + 1 = 0]$$

482 $$3x + 5y - 3 = 0, \quad 5x - 3y + 1 = 0.$$

$$[2x - 8y + 4 = 0; 8x + 2y - 2 = 0]$$

483 $$x + y + 3 = 0, \quad x = 0.$$

$$[(1 \pm \sqrt{2})x + y + 3 = 0]$$

484 Dato il triangolo ABC di vertici A(0; 3), B(6; 1), C(5; 8), trova la bisettrice dell'angolo $$A\widehat{C}B$$ e verifica che è anche mediana e altezza. $$[y = 3x - 7]$$

250