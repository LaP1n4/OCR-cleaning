Capitolo 4

PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

# Fasci di rette

Prima di iniziare,
esercitati su laZ Esercizi

1 Dato il fascio di rette di equazione $$(2k - 1)x + (3 - k)y + 2k - 1 = 0$$, determina il centro e le generatrici. Trova poi le rette del fascio che, intersecando gli assi cartesiani, formano un triangolo rettangolo isoscele.

$$[C(-1; 0), x - 3y + 1 = 0, 2x - y + 2 = 0; x - y + 1 = 0, x + y + 1 = 0]$$

2 Sono dati due fasci di rette, $$r_A: x + (k - 1)y + 2 - 2k = 0$$ e $$r_B: (1 - k)x + (2k - 1)y - 1 = 0$$.

a. Verifica che sono entrambi propri e determina i centri \(A\in B\)
b. Detto \(C\) il punto di interszione fra le rette \(r_A\) e \(r_B\) per \(k = -1\), calcola l'area del triangolo ABC.
c. Trova il valore di \( k \) per cui \( r_A \) è parallela a \( r_B \) e il valore di \( k \) per cui \( r_A \) è perpendicularare a \( r_B \).

$$[a) A(0; 2), B(2; 1); b) \mathcal{A} = 14; c) k = 0, k = 1]$$

3 Dato il fascio improprio di rette contente la retta \(r\): \(3x - 2y + 3 = 0\), determina le rette \(s\) e \(t\) del fascio che distano \(\sqrt{13}\) da \(r\). Detti \(A\) e \(C\) i punti di intersezione di \(s\) e \(t\) con l'asse \(y\), calcola l'area del rettangolo che ha diagonale \(AC\) e due lati che giaccioni su \(s\) e su \(t\). \([3x - 2y + 16 = 0, 3x - 2y + 10 = 0; \mathcal{A} = 78]\)
4 Considera il fascio generato delle rette \(r\): \(2x + 3y = 0\) e \(s\): \(x - y - 5 = 0\).

a. Verifica che si tratta di un fascio proprio e ricavane il centro \(C\)
b. Scrivi l'equazione del fascio in modo che la retta s corrisponda al valore nullo del parametro \(k\) e che il fascio ruoti in senso antiorario al crescere di \(k\).
c. Determinina il valore di \(k\) per cui si ottiene la retta del fascio parallela alla bisettrice del II e IV quadrante.

$$[a) C(3; -2); b) (2k + 1)x + (3k - 1)y - 5 = 0; c) k = 2]$$

5 Considera il fascio di rette di equazione $$2(k + 1)x - (k + 1)y + 2 - 4k = 0$$, con $$k \neq -1$$, e il segmento di estremi $$A(1; 3)$$ e $$B(5; 1)$$.

a. Determinina i valori di \(k\) per cui le rette intersecano il segmento \(AB\).
b. Esiste una retta del fascio che passa per il punto medio di \(AB\)?

$$[a) k \leq -\frac{11}{5} \vee k \geq \frac{1}{5}; b) \text{ no}]$$

6 Determina per quali valori di $$k$$ la retta del fascio di equazione $$(k - 3)x + (k - 1)y + 3 - 2k = 0$$, intersecando gli assi cartesiani, forma un triangolo rettangolo di area 2.

$$\left[ k = \frac{3}{4} \vee k = \frac{7 \pm \sqrt{7}}{4} \right]$$

7 Studia il fascio di rette di equazione $$(k - 1)x + 2ky - 3k + 1 = 0$$ e determina le equazioni delle rette generatrici, le coordinate del suo centro $$C$$ e l'equazione della retta del fascio che non viene rappresentata da alcun valore di $$k$$. Calcola poi i valori di $$k$$ per cui la retta del fascio:

a. interseca il segmento di estremi \(A(-3;2)\) e \(B(0;3)\)
b. passa per il baricentro del triangolo \( ABC \)
c. è parallela alla retta del fascio di equazione \( y = kx + 3k + 2 \)
d. è perpendicularare alla retta del fascio di equazione \( y = kx + 3k + 2 \).

$$\left[ x + 2y - 3 = 0, x = 1, C(1; 1), x + 2y - 3 = 0; a) k \leq -\frac{1}{3} \vee k \geq 2; b) k = -5; c) k = \frac{1}{2} \vee k = -1; d) k = 3 \right]$$

8 FISICA OTTICA GEOMETRICA Lungo le due direzioni degli assi cartesiani $$x$$ e $$y$$ del sistema di riferimento rappresentato a lato sono posti due specchi piani perpendicolari.

![img-114.jpeg](img-114.jpeg)

Nel punto $$S(4; 7)$$ è posta una sorgente luminosa puntiforme che irraggia luce in ogni direzione.

a. Ricava un'equazione del fascio proprio delle rette che descrivono le direzioni dei raggi luminosi prodotti alla sorgente \(S\)
b. Determinina l'equazione della retta del fascio che corrisponde alla direzione del raggio luminoso \(r\) che incide con un angolo di \(45^{\circ}\) sullo specchio verticale.
c. Ricava le equazioni delle due rette che corrispondono alle direzioni del raggio \(r^{\prime}\), riflesso di \(r\) dallo specchio verticale, e di \(r^{\prime}\), riflesso di \(r^{\prime}\) dallo specchio orizzontale. Qual è la posizione reciproca tra \(r^{\prime}\) e \(r^{\prime \prime}\)

$$[a) mx - y - 4m + 7 = 0; b) y = x + 3; c) y = -x + 3, y = x - 3, \text{ sono parallele}]$$

ESERCIZI

262