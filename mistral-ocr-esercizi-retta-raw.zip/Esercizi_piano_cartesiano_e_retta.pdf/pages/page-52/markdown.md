COMPETENZE ALLA PROVA

# COMPETENZE ALLA PROVA

![img-118.jpeg](img-118.jpeg)

laZ Tutor di matematica

https://tutor.zanichelli.it/matematica

Se hai acquistato l'edizione con Tutor, allenati con esercizi e percorsi interattivi.

![img-119.jpeg](img-119.jpeg)

RECUPERO

INVALSI

GARE

ESAME

UNIVERSITÀ

## Argomentare e dimostrare

1 Dimostra che, se due fasci di rette hanno in comune due rette distinte, alla rappresentano lo stesso fascio.
2 Considera i segmenti \(OP\) di estremi \(O(0;0)\) e \(P(k;k + 1)\). Al variate di \(k\) l'insieme degli assi dei segmenti \(OP\) forma un fascio di rette? Giustifica la risposta e, in caso sa affermativa, scrivi l'equazione del fascio. [no]
3 Dimostra che il triangolo formato da una retta \( ax + by + c = 0 \) (con \( a \neq 0 \) e \( b \neq 0 \)) con gli assi cartesiani ha sempre area uguali a \( \frac{c^2}{2|ab|} \).
4 Considera un triangolo rettangolo qualsiasi e, fissato un opportuno sistema di riferimento, dimostra che il punto medio dell'ipotenusa è equidistante dai tre vertici.

5 Dimostra che le rette su cui giacciono i lati di un angolo la cui bisettrice coincide con l'asse \(y\) hanno coefficienti angolari opposti.
E dato un triangolo isoscele di baricentro \(O(0;0)\) e vertice \(P(0;k)\). Dimostra che al variate di \(k\neq 0\) la retta su cui giace la base del triangolo appartiene al fascio improprio di equazione \(y = -\frac{k}{2}\).
7 Dimostra analiticamente che congiungendo i punti medi di due lati di un triangolo si ottiene un segmento parallelo al terzo lato e congruente alla meta diesso.
8 Dato un trapezio qualsiasi, fissa un opportuno si stema di riferimento e verifica che il segmento congiungente i punti medi dei lati obliqui è congruente alla semisomma delle due basi.

9 Dimostra che la distanza $d$ tra due rette parallele, $ax + by + c = 0$ e $a'x + b'y + c' = 0$, con $a = a'$ o $b = b'$, è data da: $d = \frac{|c - c'|}{\sqrt{a^2 + b^2}}$. Calcola la distanza tra le due rette $4x + y - 10 = 0$ e $y = -4x + 28$. $\left\{\frac{18\sqrt{17}}{17}\right\}$

10 VERO O FALSO?

a. Tutte le rette di un fascio proprio hanno la stessa direzione.
b. La retta \( y = -2x \) appartiene al fascio improprio di equazione \( 4x + 2y - k = 0 \).
c. L'equazione \( y = mx + 1 \) rappresenta il fascio proprio con centro in (0; 1).
d. Nel fascio di equazione \( y = (k - 2)x + k - 1 \) la retta parallela all'asse \( y \) si ottiene per \( k = 2 \).

V F
V F
V F
V F

## Analizzare e interpretare dati e grafici

11 LEGGI IL GRAFICO Scrivi le equazioni delle funzioni rappresentate nei grafici.

![img-120.jpeg](img-120.jpeg)

![img-121.jpeg](img-121.jpeg)

![img-122.jpeg](img-122.jpeg)

265

VERIFICA LE COMPETENZE