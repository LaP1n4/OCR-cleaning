Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

3 TEST Sia r la retta che passa per i punti A(1; -6) e B(-1; -8). Quale delle seguenti affermazioni è corretta?

A Il punto \(C(0; -6)\) appartiene al segmento \(AB\)
B I punti \(A, B \in D(0;7)\) sono allineati.
La retta di equazione \(2x - 2y + 7 = 0\) è perpendicular a \(r\).
La retta r è parallela alla bisettrice del I e III quadrante.

4 TEST Per quale valore di k ∈ ℝ il punto P(-1; k) determina con l'origine O una retta parallela alla retta di equazione y = 2x + 3?

A -2 B -1 C 1 D 2

5 LEGGI IL GRAFICO Scrivi un sistema di disequazioni le cui soluzioni sono gli insiemi di punti indicati in figura.

![img-97.jpeg](img-97.jpeg)

6 Considera il punto P(k - 1; 2 - k), dove k ∈ ℝ. Determina per quali valori di k:

a. la retta per \(P\) e \(Q(3;3)\) è perpendicular alla retta di equazione \(2x + 4y - 2 = 0\)
b. la retta per \(P\) con coefficient angolare 3 ha equazione \(y = 3x\)

[a) k = 7/3; b) k = 5/4]

7 Stabilisci per quali valori di a le rette di equazioni 3ax + y - 3 = 0 e y = 6x + 2a:

a. sono parallele;
b. sono perpendicular;
c. si intersecano in un punto di ascisa \(-2\)

[a) a = -2; b) a = 1/18; c) a = -15/4]

8 LEGGI IL GRAFICO

![img-98.jpeg](img-98.jpeg)

a. Scrivi l'espressione analitica della funzione rappresentata nella figura.
b. Determinina le coordinate del punto di intersezione \(D\) fra la retta perpendicular ad \(AB\) e passante per \(A\) e la retta perpendicular a \(BC\) e passante per \(C\).
c. Verifica che \(ABCD\) è un rettangolo e calculane l'area.

[b) D(1; -8); c) A_ABCD = 78]

9 VERO O FALSO? La retta r forma un angolo di 60° con il semiasse positivo delle ascisse e interseca l'asse y in un punto di ordinata positiva.

a. La retta \(q\): \(6x - 6y - 7 = 0\) interseca \(r\) in un punto che appartiene al secondo quadrante.
b. La retta s: \(y = -\frac{\sqrt{3}}{3} x + 2\) è perpendicular a r.
c. La bisettrice del II e IV quadrante interseca la retta \(r\) in un punto del secondo quadrante.
d. Tutte le rette con coefficient angolare \(\sqrt{3}\) sono parallele a \(r\)

10 EDUCAZIONE FINANZIARIA COSTO E RICAVO Un'azienda familiare produce e vende marmellate. Ha valutato che producendo 10 kg di marmellate alla settimana deve sostenere un costo di 260 €, mentre producendone 50 kg il costo è di 500 €.

![img-99.jpeg](img-99.jpeg)

a. Se la funzione del costo ha come grafico una retta e la funzione del ricavo è \( y = px \), dove \( p \) è il prezzo di vendita, in €/kg, e \( x \geq 0 \) è la quantità, in kg, di marmellate prodotta e venduta, quanto deve valere \( p \) affinché l'azienda non sa sempre in perdita?
b. Se l'azienda vende le marmellate a 11 €/kg, quanti kg di marmellate deve produrre e vendere perché il costo sa uguali al ricavo? [a] \( p > 6 \) €/kg; b) 40 kg]

246