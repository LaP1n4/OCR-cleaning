POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

7 Rappresenta nel piano cartesiano l'insieme delle soluzioni del sistema di disequazioni:

$$\left\{ \begin{array}{l} 2x - y + 4 \geq 0 \\ 2x + y - 4 \leq 0. \\ y \geq |x| - 2 \end{array} \right.$$

Calcola l'area della regione di piano rappresentata.

[12]

8 Rappresenta graficamente la spezzata definita dal sistema $$\left\{ \begin{array}{l} y = ||x + 1| - 3 \\ |x + 1| \leq 6 \end{array} \right.$$ e determina la sua lunghezza. [12√2]

### 3 Posizione reciproca di due rette

Stabilisci la posizione reciproca delle seguenti coppie di rette.

295 $$2x + y - 5 = 0, \quad x - 3y - 6 = 0.$$

RISOLVI IN 2 PASSI

1 Poni aSYSTEMA le due equazioni. Il systema\
può essere determinato con una sola soluzione \((x,y)\) ,impossible o indeterminato.Le rette sono,rispettivamente,incidenti nel punto \((x,y)\) ,parallele e distinte o coincidenti.
2 Verifica che il systema è determinato e conferma il risultato nel piano cartesian.

296 \(2x + y + 3 = 0\) \(3x - y + 2 = 0.\)
297 \(4x - 3y - 2 = 0,\) \(-8x + 6y - 1 = 0.\)
298 \(x + 3y - 4 = 0,\) \(2x + 6y - 8 = 0.\)
299 \(-x + y - 6 = 0,\) \(x + y - 6 = 0.\)
300 \(y = 3x - 6,\) \(y = 2x - 5.\)

# Rette incidenti

Teoria a pagina 200

301 COMPLETA Date le rette di equazioni $$3x - 6h = 0$$ e $$2y - x + k = 0$$, il loro punto di intersezione coincide con:

$$A(2; -1) \text{ se } h = \_\_\_\_\_ \text{ e } k = \_\_\_\_\_;$$

$$B(-3; -2) \text{ se } h = \_\_\_\_\_ \text{ e } k = \_\_\_\_\_.$$

302 Trova la misura del segmento che le rette di equazioni \( y = x - 6 \) e \( y = -x + 5 \) staccano sull'asse delle \( x \). [1]
303 La retta di equazione

$$4x + 3y - 12 = 0$$

interseca gli assi cartesiani in due punti A e B. Calcola area e perimetro del triangolo AOB.

[6; 12]

304 Le rette \(r\) e s, rispettivamente di equazioni \(y = 2x + 3\) e \(y = 2x - 1\), staccano sulla retta \(t\) di equazione \(2x - 3y + 9 = 0\) un segmento \(AB\). Calcola la misura di \(AB\). [V13]
305 Stabilisci per quale valore di \(a\) le rette di equazioni \(x - y + a = 0\) e \(x - 3y = 0\) si intersecano in un punto di ascissa 3. [-2]

306 Determina le coordinate dei vertici A, B, C del triangolo i cui lati appartengono alle rette di equazioni $$2x - 6 = 0, y = 2$$ e $$y = -2x + 10$$. Calcola l'area e il perimetro del triangolo.

$$[A(3; 4), B(3; 2), C(4; 2); 1; 3 + \sqrt{5}]$$

307 Determinina il valore del parametro \(k\) per cui il punto di intersezione delle rette di equazioni \(3x + y + 4 = 0\) e \(x - 2y + 6 = 0\) appartiene alla retta di equazione \(y = (3 - k)x + 6\). [1]
308 Trova per quale valore di \(k\) le rette di equazioni \((k - 1)x + 2ky + 6 = 0\) e \(x - y + 2 = 0\) si intersecano sull'asse \(x\). [4]
309 Trova le intersezioni tra le rette di equazioni

$$2x - (k - 3)y + 8k - 2 = 0$$

e

$$x + (k + 1)y + k = 0,$$

al variare di k.

$$\left[ k = \frac{1}{3} : \text{rette coincidenti}; k \neq \frac{1}{3} : (-3k - 2; 2) \right]$$

233

ESERCIZI