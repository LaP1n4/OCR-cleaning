RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Coefficiente angolare e ordinata all'origine

186 AL VOLO Determina, se esiste, il coefficiente angolare delle rette che hanno le seguenti equazioni.

a. $$y = \frac{x}{4} - 1$$

b. $$4x + 2y - 5 = 0$$

c. $$3y - 6 = 0$$

d. $$2x = 5$$

e. $$\frac{x + y}{4} = 0$$

f. $$7x = -14y$$

Per ognuna delle seguenti equazioni di rette indica, se esistono, il coefficiente angolare $$m$$ e il termine noto $$q$$ e poi rappresentale.

187 $$2 - 2x = 0; \quad y - x - 1 = 0.$$

188 $$y = -3x + 6; \quad 2x - y - 2 = 0.$$

189 VERO O FALSO?

a. L'equazione \( y = mx + q \) rappresenta tutte le rette del piano al variare di \( m \in q \).
b. L'equazione \(4y - x + 1 = 0\) non è l'espressione di una funzione di \(\mathbb{R}\) in \(\mathbb{R}\).
c. L'asse \(x\) non ha coefficiente angolare.
d. L'ordinata all'origine della retta \( y - 5 = \frac{1}{2} (x + 1) \) è \( \frac{11}{2} \).

V F
V F
V F
V F

# LEGGI IL GRAFICO

190 TEST Osservando la figura si deducono le seguenti affermazioni. Una sola è falsa. Quale?

![img-37.jpeg](img-37.jpeg)

A Le rette \(r,s\in t\) hanno I'ordinata all'origine positiva.
B I coefficienti angolari di \(r\in s\) sono discordi.
C Il coefficiente angolare di \(s\) è maggiore di quello di \(t\).
D Il coefficiente angolare della retta \(t\) è minore di quello di \(r\).

191 In ognuna delle seguenti figure evidenzia l'angolo tra retta e asse $$x$$, come definito nella teoria. Indica se il coefficiente angolare della retta è positivo, negativo, nullo o non definito.

![img-38.jpeg](img-38.jpeg)

192 Indica il segno di $$m$$ e $$q$$ per ognuna delle seguenti rette di equazione $$y = mx + q$$.

![img-39.jpeg](img-39.jpeg)

193 Determina per quali valori di $$a$$ la retta di equazione $$5y + (a^2 - 9)x + a = 0$$ forma con l'asse $$x$$ un angolo $$\alpha$$ acuto. Per quali valori di $$a$$ l'angolo $$\alpha$$ è di $$45^\circ$$? $$[-3 < a < 3, a = \pm 2]$$

# RISOLVI IN 3 PASSI

1 Scrivi l'equazione della retta in forma esplicita e determina il coefficiente angolare \( m \).
La retta deve formare un angolo acuto con l'asse \(x\), quindi poni \(m > 0\) e risolvi la disequazione in \(a\).
3 Verifica che, se \(\alpha = 45^{\circ}\) , alla il coefficiente angolare vale 1; poni \(m = 1\) e risolvi l'equazione.

227

ESERCIZI