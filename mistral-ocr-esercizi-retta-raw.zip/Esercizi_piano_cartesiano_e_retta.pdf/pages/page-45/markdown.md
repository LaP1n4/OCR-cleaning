Capitolo 4 PIANO CARTESIANO E RETTA

# Fasci generati da due rette

Teoria a pagina 209

565 Scrivi l'equazione del fascio generato dalle rette r e s di equazioni x - 2y + 1 = 0, x + y - 2 = 0; stabilisci il tipo di fascio e determina la retta del fascio passante per il punto P(3; -2).

# COMPLETA LO SVOLGIMENTO

Scriviamo l'equazione del fascio generato dalle rette r e s combinando linearmente le loro equazioni:

$$x - 2y + 1 + k(x + y - 2) = 0 \rightarrow x - 2y + 1 + kx + ky - 2k = 0.$$

Raccogliamo x e y: (1 + k) x + (k - 2) y + 1 - 2k = 0.

Osserviamo che le rette non sono parallele perché

Nella combinazione lineare, è indifferente scrivere prima l'equazione di r o quella di s.

$$m_r = \_\_\_\_\_ \text{ e } m_s = \_\_\_\_\_$$

Il fascio è \_\_\_\_\_ e il centro è il punto C di intersezione tra le generatrici r e s.

$$\begin{cases} x - 2y + 1 = 0 \\ x + y - 2 = 0 \end{cases} \rightarrow \begin{cases} x = 2y - 1 \\ 2y - 1 + y - 2 = 0 \end{cases} \rightarrow \begin{cases} x = 2y - 1 \\ 3y = 3 \end{cases} \rightarrow \begin{cases} x = 1 \\ y = 1 \end{cases} \rightarrow C(1; 1)$$

Per determinare l'equazione della retta del fascio passante per P(3; -2) sostituiamo le coordinate di P alla x e alla y nell'equazione del fascio:

$$(1 + k) 3 + (k - 2) \_\_\_\_\_ + 1 - 2k = 0 \rightarrow 3 + 3k - 2k + 4 + 1 - 2k = 0 \rightarrow k = 8.$$

Sostituiamo k = 8 nell'equazione del fascio e otteniamo l'equazione richiesta:

$$\_\_\_\_\_ + 6y - 15 = 0 \rightarrow 3x + 2y - 5 = 0.$$

566 Scrivi l'equazione del fascio di rette le cui generatrici hanno equazioni 3x + 2y - 1 = 0 e 6x + 4y + 3 = 0, stabilisci di che fascio si tratta e determina l'equazione della retta del fascio che interseca l'asse y nel punto di ordinata 1. [fascio improprio; 3x + 2y - 2 = 0]

567 Scrivi l'equazione del fascio generato dalle rette di equazioni 3x + y - 1 = 0 e x + 2y + 3 = 0, stabilisci se è proprio o improprio e individua l'equazione della retta del fascio che passa per P(4; 1).

[fascio proprio di centro C(1; -2); x - y - 3 = 0]

568 Dopo aver scritto l'equazione del fascio generato dalle rette di equazioni 3x - 2y + 4 = 0 e 2x + y - 2 = 0, stabilisci se è proprio o improprio e determina l'equazione della retta del fascio parallela alla bisettrice del primo e terzo quadrante. [fascio proprio di centro C(0; 2); x - y + 2 = 0]

569 Nel fascio di rette le cui generatrici hanno equazioni 2x + 3y - 7 = 0 e x + 4y - 1 = 0 determina la retta di coefficiente angolare m = -4. [y = -4x + 19]

570 Determina l'equazione della retta che interseca l'asse y nel punto di ordinata -3 e che appartiene al fascio generato dalle rette di equazioni 2x - y + 2 = 0 e -2x + y = 0. [2x - y - 3 = 0]

571 Fra le rette del fascio le cui generatrici hanno equazioni 3x - 2y - 3 = 0 e 3x - 4y = 0, determina quella parallela alla retta di equazione 3x + 4y + 2 = 0. [3x + 4y - 12 = 0]

572 REALTÀ E MODELLI La meridiana solare rappresentata in figura segna le ore utilizzando l'ombra che un'asta proietta sul sistema di linee dipinto su una parete. Considera le due linee evidenziate in colore rosso, di estremi A(0; 5), B(3; 44/7) e C(3; 0), D(5; 4) nel riferimento Oxy, quindi:

![img-112.jpeg](img-112.jpeg)

a. ricava l'equazione del fascio proprio di rette che ha per generatrici le rette \(AB\) e \(CD\), assegnando alla retta \(CD\) il ruolo di generatrice corrispondente al valore nullo del parametro;
b. determina il centro del fascio;
c. ricava l'equazione della retta del fascio che corrisponde a un'ora intermedia tra la VII e la VIII,cioe la retta passante per l'origine \(O\) del riferimento.

[a) (2 + 3k)x - (1 + 7k)y + 35k - 6 = 0; b) C(7; 8); c) 8x - 7y = 0]

ESERCIT

258