Capitolo 4

PIANO CARTESIANO E RETTA

![img-141.jpeg](img-141.jpeg)

Agatha si trova nella città di Seattle, dove deve incontrare l'amico Bob. Agatha è all'incrocio tra la 6th Avenue e Pike Street, mentre Bob la aspetta nei pressi del Seattle Art Museum, all'incrocio tra la 2nd Avenue e University Street. Utilizza il riferimento Oxy e le misure riportate sulla mappa, assumendo che le strade del quartiere si intersechino perpendicolarmente.

a. Determinina le coordinate di Agatha e Bob.
b. Qual è la minima distanza che Agatha deve percorrere per raggiungere Bob?

a) A(300; 300), B(600; 180); b) $$\frac{1620\sqrt{13}}{13}$$ m $$\simeq 449,3$$ m

60 Un giardiniere ha l'incarico di tagliare l'erba di un giardino il cui modello è indicato in figura.

![img-142.jpeg](img-142.jpeg)

a. Quanto tempo è necessario per tosare il giardino se mediamente il giardiniere impiega 1 min per \(50\mathrm{m}^2\)
b. Quale sarebbe il preventivo di spesa se il giardiniere volesse piantare delle piccole betulle lungo tutto il perimetro del giardino a una distance di 2,5 m l'une dall'altra, sapendo che il costo medio è di 4,50 € ciascuna? (Calcola il perimetro using due metodi: l'usuale formula della distance nel piano

cartesiano, approssimando il risultato con la calcolatrice, e il metodo diretto, misurando i lati della figura con un righello e trasformando le lunghezze con il rapporto di scala.)

c. Il giardiniere vuole installare una fontana in corrispondenza del baricentro del triangolo ACD. Dove andrà collocata?

a) 10 ore; b) 1512 €; c) $$\left(\frac{650}{3}; 100\right)$$

# Problemi di matematica e fisica

# RISOLVIAMO UN PROBLEMA

# Monoposto in pista

Una monoposto da corsa di massa M = 600 kg percorre il rettilineo di un circuito: per i primi 4 secondi si muove con accelerazione costante, per i 5 successivi mantiene la velocità raggiunta. La velocità iniziale è 43,2 km/h, mentre dopo 1,8 s è 108 km/h.

![img-143.jpeg](img-143.jpeg)

a. Deduciamo la funzione che descrive la velocità (espressa in m/s) in funzione del tempo (espresso in s) e rappresentiamo il grafico velocità-tempo.
b. Ipotizzando che sulla monoposto agisca una forza resistente \(\vec{F}_R\) parial \(80\%\) del suo peso, calculiamo la forza che il motore esercita sulla monoposto nella parte iniziale del rettilineo.

a. Deduciamo la funzione v(t) e tracciamo il suo grafico.

Nei primi 4 secondi, dato che l'accelerazione è costante, il grafico velocità-tempo è lineare. In particolare, è un segmento della retta che passa per i punti (t₀; v₀) e (t₁; v₁), con t₀ = 0 s, v₀ = 43,2 km/h = 12 m/s, t₁ = 1,8 s e v₁ = 108 km/h = 30 m/s. Ricaviamo la relazione tra v e t:

$$\frac{v - v_0}{v_1 - v_0} = \frac{t - t_0}{t_1 - t_0} \rightarrow \frac{v - 12}{18} = \frac{t}{1,8} \rightarrow v(t) = 10t + 12.$$

VERTO I ESAME

276