DISTANZA, PUNTO MEDIO, BARICENTRO

RIEPILOGO

# Parti proporzionali in un segmento

125 Dato il segmento di estremi $A(-1; 1)$ e $B(5; 4)$, determina le coordinate del punto $C$ su $AB$ tale che $AC$ sia il doppio di $BC$.

# COMPLETA LO SVOLGIMENTO

![img-19.jpeg](img-19.jpeg)

Disegniamo il segmento $AB$ e fissiamo un punto $C(x; y)$ su $AB$. Tracciamo da $A, B$ e $C$ le rette parallele all'asse $x$ e all'asse $y$.

Poiché deve essere $AC \cong \underline{\quad}$, per il teorema di Talete valgono le due relazioni $A'C' \cong 2C'B'$ e $A'C'' \cong 2C'B''$.

Determiniamo le misure dei segmenti $A'C'$ e $C'B'$. Otteniamo:

$$\overline{A'C'} = x + 1 \quad \text{e} \quad \overline{C'B'} = \underline{\quad} - x.$$

Sostituiamo nella relazione $\overline{A'C'} = 2\overline{C'B'}$ e troviamo l'ascissa di $C$:

$$x + 1 = \underline{\quad} (5 - x) \rightarrow x + 1 = 10 - 2x \rightarrow x = 3.$$

In modo analogo troviamo che l'ordinata di $C$ è $y = \underline{\quad}$.

Il punto cercato è $C(3; 3)$.

126 Nel segmento di estremi $A(-3; 4)$ e $B(3; -2)$ individua le coordinate di un punto $C$ tale che $AC$ sia triplo di $BC$.

$$\left[ C \left( \frac{3}{2}, -\frac{1}{2} \right) \right]$$

127 Dato il segmento di estremi $A(-4; 0)$ e $B(6; 5)$, quali sono le coordinate di un punto $C$ tali che $AC$ sia un quarto di $BC$? [C(-2; 1)]

128 Dato il segmento di estremi $A(0; 6)$ e $B(7; 1)$, determina le coordinate dei punti che lo dividono in due parti proporzionali ai numeri $4$ e $3$.

$$\left[ \left( 3; \frac{27}{7} \right), \left( 4; \frac{22}{7} \right) \right]$$

129 Calcola le coordinate dei punti del segmento di estremi $A(4; 4)$ e $B(-2; -5)$ che lo suddividono in tre parti congruenti. [(2; 1), (0; -2)]

130 Individua le coordinate dei punti del segmento di estremi $A(-1; 3)$ e $B(7; -5)$ che lo suddividono in quattro parti congruenti.

$$[(1; 1), (3; -1), (5; -3)]$$

131 I punti $A(6; 1)$ e $B(1; 0)$ sono gli estremi della mediana $AM$ di un triangolo $ABC$. Trova il baricentro $G$ del triangolo.

$$\left[ G \left( \frac{8}{3}; \frac{1}{3} \right) \right]$$

# RIEPILOGO Distanza, punto medio, baricentro

132 COMPLETA

a. La distanza tra \(P(-1;3)\) e \(Q(2; - 1)\) e
b. Il punto medio del segmento \(AB\), di estremi \(A(\underline{\quad};6)\) e \(B(-3; - 8)\), e \(M(2;\underline{\quad})\)
c. Il simmetrico di \(A(-1;3)\) rispetto a \(C\left(2; - \frac{1}{2}\right)\) e \(A^{\prime}(\underline{\quad};\underline{\quad})\)
d. La distanza tra \(A(3; - 4)\in B(\underline{\quad};2)\dot{\varepsilon}6.\)

133 TEST Nel triangolo $ABC$ la mediana $AM$ ha per estremi i punti $A(-3; 5)$ e $B(-3; -1)$. Quali sono le coordinate del baricentro del triangolo $ABC$?

A (-3; 1).

C (-3; 2).

B (-3; 0).

D I dati non sono sufficienti per determinarle.

134 TEST Il triangolo di vertici $A(1; 2)$, $B(1 - 3a; -4)$ e $C(1; b - 4)$ ha baricentro $G(-1; -1)$ se:

A \(a = 1\wedge b = 3\)
B \(a = 3\wedge b = 2\)
C \(a = 2\wedge b = 3\)
D \(a = 2\wedge b = 1\)

135 TEST Un triangolo ha due vertici nei punti di coordinate $(-4; 1)$ e $(2; -1)$ e il terzo vertice nel punto di coordinate $(1; k)$. Per quanti valori reali di $k$ tale triangolo risulta isoscele?

A Nessuno.

D 5.

B 1.

E Infiniti.

C 4.

(Giochi di Archimede)

221

ESERCIZIO