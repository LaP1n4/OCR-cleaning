Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZIO

513 Verifica che il quadrilatero di vertici A(3; 0), B(13; 4), C(9; 6), D(4; 4) è un trapezio e che il segmento che congiunge i punti medi dei lati obliqui è parallelo alle due basi e congruente alla loro semisomma.

514 Determina i vertici e l'area del parallelogramma ABCD che ha due lati consecutivi sulle rette di equazioni 3x + y - 5 = 0, 5x - y - 11 = 0 e un vertice nel punto A(4; 1).

[B(3; -4), C(2; -1), D(3; 4); 8]

515 Il triangolo ABC ha i lati sulle rette di equazioni:

r: y = x + 2,

s: y = -1/2 x + 7/2,

t: 7y - x - 2 = 0.

Determina il perimetro, l'area e il baricentro. Verifica inoltre che il triangolo che si ottiene congiungendo i punti medi dei lati ha il perimetro uguale alla metà di quello di ABC.

[8√2 + 2√5; 9; (4/3; 4/3)]

516 EUREKAI Un quadrato, con un vertice nel punto A(1; 2), ha un lato sulla retta di equazione x - 2y + 3 = 0. Individua le coordinate degli altri tre vertici del quadrato, sapendo che uno di essi sta sull'asse x, mentre gli altri sono interni al primo quadrante. [(2; 0), (4; 1), (3; 3)]

517 Due triangoli congruenti hanno ciascuno area 24. I loro vertici sono determinati dalle intersezioni delle rette di equazioni y = -4, x = 0 e y = 3/4 x + b. Determina i due possibili valori di b.

(CAN, Canadian Open Mathematics Challenge)
[b = 2, b = -10]

523 Dato il triangolo di vertici A(-1; 2), B(-9; 2), C(-5; -1), verifica che è un triangolo isoscele e determina il baricentro, l'incontro, il circocentro e l'ortocentro.

524 Rappresenta nello stesso piano cartesiano le seguenti funzioni:

f(x) = |x - 2| + 3 e g(x) = {2x + 4 se x ≤ 1; 1/3 (-x + 19) se x > 1}

Trova poi i vertici e l'area del quadrilatero che si forma dall'intersezione dei loro grafici.

[(1; 6), (4; 5), (2; 3), (1/3; 14/3), 17/3]

Trova l'area della figura individuata nel piano cartesiano dai seguenti sistemi di disequazioni.

525

{2y ≥ 3x - 3; 3y ≤ 2x + 3; y ≥ -x + 1}

[5/2]

526

{y + x ≥ 0; y - 2 ≤ 0; 4y ≥ x - 5; y ≤ 5 - x}

[25/2]

254