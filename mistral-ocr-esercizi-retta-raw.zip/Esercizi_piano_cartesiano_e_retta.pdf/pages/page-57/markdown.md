Capitolo 4

PIANO CARTESIANO E RETTA

# VERSO L'ESAME

# Problemi di matematica

# RISOLVIAMO UN PROBLEMA

# Un trapezio e un fascio di rette

Consideriamo il trapezio ABCD in figura e la retta di equazione y = mx, con m ≥ 0.

![img-132.jpeg](img-132.jpeg)

a. Indichiamo per quali valori di \( m \) la retta interseca il segmento \( DC \) e calculiamo l'area del triangolo \( DEF \) in funzione di \( m \).
b. Troviamo per quale valore di \( m \) l'area di \( DEF \) è \( \frac{1}{2} \) e per tale valore troviamo il perimetro di \( DEF \) e l'ortocentro.
c. Calcoliamo il valore di \( m \), con \( 0 \leq m \leq 1 \), per cui la retta di equazione \( y = mx \) divide il trapezio ABCD in due poligoni equivalenti.
d. Se l'angolo \( \alpha \) che la retta forma con l'asse \( x \) è di \( 30^{\circ} \), quanto valgono le aree dei due poligoni in cui la retta divide il trapezio?

a. Troviamo i valori richiesti per il parametro m e calcoliamo l'area di DEF in funzione di m.

Troviamo le equazioni delle rette passanti per l'origine che passano per C e D.

Retta per C(6; 6): 6 = m · 6 → m = 1 → y = x.

Retta per D(2; 4): 4 = m · 2 → m = 2 → y = 2x.

La retta y = mx interseca CD per 1 ≤ m ≤ 2.

Troviamo le coordinate di F intersecando le rette DC ed EF.

La retta DC ha equazione:

$$\frac{y-6}{4-6} = \frac{x-6}{2-6} \rightarrow \frac{y-6}{-2} = \frac{x-6}{-4} \rightarrow y = \frac{x-6}{2} + 6 \rightarrow y = \frac{x+6}{2}.$$

Risolviamo il sistema seguente.

$$\left\{\begin{array}{l} y=mx \\ y=\frac{x+6}{2} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ mx=\frac{x+6}{2} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ x(2m-1)=6 \end{array}\right.\rightarrow\left\{\begin{array}{l} y=mx \\ x=\frac{6}{2m-1} \end{array}\right.\rightarrow\left\{\begin{array}{l} y=\frac{6m}{2m-1} \\ x=\frac{6}{2m-1} \end{array}\right.\rightarrow F\left(\frac{6}{2m-1}; \frac{6m}{2m-1}\right), \quad \text { con } 1 \leq m \leq 2.$$

Troviamo le coordinate di E intersecando le rette AD ed EF.

$$\left\{\begin{array}{l} y=mx \\ x=2 \end{array}\right.\rightarrow\left\{\begin{array}{l} x=2 \\ y=2m \end{array}\right.\rightarrow E(2; 2m)$$

Calcoliamo $$\overline{DE} = y_D - y_E = 4 - 2m$$ e la distanza h fra F e DE:

$$h = x_F - x_D = \frac{6}{2m-1} - 2 = \frac{6-4m+2}{2m-1} = \frac{8-4m}{2m-1}.$$

L'area del triangolo DEF è:

$$\frac{1}{2} \overline{DE} \cdot h = \frac{1}{2}(4-2m) \cdot \frac{8-4m}{2m-1} = 4 \frac{(2-m)^2}{2m-1}, \quad \text { con } 1 \leq m \leq 2.$$

b. Troviamo il valore richiesto per m e calcoliamo perimetro e ortocentro di DEF.

Poniamo l'area di DEF = 1/2.

$$4 \frac{(2-m)^2}{2m-1} = \frac{1}{2} \rightarrow 8(4+m^2-4m) = 2m-1 \rightarrow 8m^2-34m+33 = 0 \rightarrow$$

$$m = \frac{17 \pm \sqrt{25}}{8} = \frac{17 \pm 5}{8} \rightarrow m_1 = \frac{3}{2}, m_2 = \frac{11}{4}; \text { solo } m_1 = \frac{3}{2} \text { è accettabile, perché } m_2 > 2.$$

Calcoliamo il perimetro del triangolo DEF.

Per $$m = \frac{3}{2} \rightarrow F\left(3; \frac{9}{2}\right)$$ ed E(2; 3).

VERSO L'ESAME

270