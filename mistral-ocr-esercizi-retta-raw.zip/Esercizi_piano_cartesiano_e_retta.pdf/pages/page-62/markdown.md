VERSO L'ESAME

# EDUCAZIONE FINANZIARIA

55

PROBLEMA DI SCELTA Per il noleggio giornaliero di un'automobile si può scegliere fra tre diverse tariffe. La tariffa A comporta una quota fissa di 30 € e costa 0,25 € a kilometro percorso; la tariffa B comporta una quota fissa di 10 € e costa 0,60 € a kilometro percorso; la tariffa C non ha quota fissa, costa 0,40 € a kilometro percorso, però ha un vincolo minimo di 150 km, ovvero la spesa ha un costo minimo corrispondente a un percorso di 150 km.

Dopo aver rappresentato i grafici del costo del noleggio in funzione dei kilometri percorsi, stabilisci qual è la tariffa più conveniente nei diversi casi.

[B: tra 0 e 57,14 km; A: tra 57,14 e 120 km e dopo i 200 km; C: tra 120 e 200 km]

56

DOMANDA E OFFERTA La quantità di grano offerta e quella richiesta nella piazza di Granopoli il 4 luglio 2015 hanno esibito andamenti lineari in funzione del prezzo, secondo le modalità riportate nella figura.

a. Determinina le equazioni della quantità dell'offerta e della domanda in funzione del prezzo unitario (prezzo in €/q, quantità in tonnellate).
b. Qual è il prezzo di equilibrio in cui le due quantità sono uguali? Quanto valgono?

![img-140.jpeg](img-140.jpeg)

|  incremento di prezzo = 1€/q  |   |   |
| --- | --- | --- |
|  aumento offerta: 6 tonnellate  |   |   |
|  diminuzione domanda : 9 tonnellate  |   |   |
|  prezzo | offerta | domanda  |
|  24,67 €/q | 20 tonnellate | 70 tonnellate  |

[a) $y_{eff} = 6x - 128,02$, $y_{dom} = -9x + 292,03$; b) 28,00 €/q, 40 t]

57

COSTO E RICAVO In un borgo medievale Alessandro prepara e vende marmellate di frutta biologica al prezzo di 7 € al vasetto. Per quanto riguarda i costi, ha rilevato che variano linearmente con la produzione come segue.

produzione 300 vasetti
costo complessivo 1800 €

produzione 500 vasetti
costo complessivo 2600 €

Ha la possibilità di aumentare la produzione fino a 700 vasetti e pertanto decide di effettuare una piccola campagna pubblicitaria che gli verrebbe a costare 300 €. Determina:

a. la funzione del costo e quella del ricavo nella situazione attuale e la quantità per cui esse si uguagliano;
b. la funzione del costo che tiene conto della spesa per la pubblicità e la quantità che nella nuova situazione uguaglia costi e ricavi.

Rappresenta graficamente le due situazioni precedenti e commenta il risultato.

[a) $y_c = 4x + 600$, $y_r = 7x$, 200 vasetti; b) $y_c = 4x + 900$, 300 vasetti]

58

FUNZIONE DEL COSTO L'impresa Textil vuole studiare l'andamento del costo di produzione, in un settore dove vengono fabbricati piccoli tappeti di cotone, in relazione al tempo e al numero di addetti. Ha preso in considerazione la produzione di 100 unità e in base ai dati rilevati in passato ha determinato quanto segue.

costo 4000 €
tempo lavorazione 48 ore
numero addetti 6

costo 3700 €
tempo lavorazione 120 ore
numero addetti 2

Determina:

a. la funzione che esprime il costo $y$ in funzione del numero delle ore $t$, supponendo che sia lineare;
b. la funzione che esprime il numero degli addetti $n$ in funzione del numero delle ore $t$, supponendo che sia lineare, e il costo nel caso in cui si utilizzino 3 addetti.

Rappresenta graficamente le due funzioni lineari $y$ e $n$ in funzione di $t$, supponendo che $n$ possa assumere valori non naturali.

[a) $y = -\frac{25}{6}t + 4200$; b) $n = -\frac{t}{18} + \frac{26}{3}$, 3775 €]

VERSO L'ESAME

275