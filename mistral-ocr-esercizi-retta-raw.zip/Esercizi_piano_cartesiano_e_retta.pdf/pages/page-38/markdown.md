LUOGHI GEOMETRICI E RETTA

Paragrafo 6

6

# Punti notevoli di un triangolo

Determina l'incentro dei triangoli ABC.

485 O(0; 0), A(8; 0), B(0; 6).

486 A(0; -2), B(6; 1), C(0; 4).

487 A(0; 3), B(4; 0), C(0; -3).

488 A(-1; 0), B(5; 0), C(2; 4).

489 Determina le coordinate dell'incontro del triangolo di vertici A(0; 4), B(-3; 0) e C(16/3; 0).

Calcola il raggio della circonferenza inscritta.

[(2; 2)]

$$\left[ \left( \frac{3}{2} (\sqrt{5} - 1); 1 \right) \right]$$

$$\left[ \left( \frac{3}{2}; 0 \right) \right]$$

$$\left[ \left( 2; \frac{3}{2} \right) \right]$$

punto di incontro di

baricentro

circocentro

ortocentro

incentro

mediane

assi

altezze

bisettrici

$$\left[ \left( \frac{1}{3}; \frac{5}{3} \right); r = \frac{5}{3} \right]$$

Determina il circocentro dei triangoli ABC.

490 A(-2; 1), B(2; 5), C(4; -1).

$$\left[ \left( \frac{3}{2}; \frac{3}{2} \right) \right]$$

RISOLVI IN 3 PASSI

1 Indica con \((x,y)\) le coordinate del circumocentro \(D\) del triangolo, che è il centro della circonferenza circoscritta e quando è equidistante dai tre vertici.
2 Calcola le distance \(\overline{DA}\) \(\overline{DB}\) e \(\overline{DC}\)
3 Scrivi e risolvi il systemà \(\left[\frac{\overline{DA} = \overline{DB}}{\overline{DB} = \overline{DC}}\right]\)

491 A(-3; 0), B(1; 4), C(-3; 6). [(-2; 3)]

492 A(5; -1), B(-1; 1), C(-2; -4). [(21/16; -33/16)]

493 Trova le coordinate dell'ortocentro del triangolo di vertici A(3; 5), B(1; 0), C(9; 8). [(-6; 14)]

494 Dato il triangolo di vertici A(6; 0), B(3; 6) e C(0; 2), determina le coordinate dell'ortocentro e del baricentro. [(2; 3), (3; 8/3)]

495 Verifica che il triangolo ABC di vertici A(1; 1), B(4; 7) e C(-5; 4) è un triangolo rettangolo e:

a. scrivi le equazioni dei lati;
b. determina l'ortocentro;
c. determina il circumocentro.

$$\left[ \begin{array}{l} \text{a) } 2x - y - 1 = 0, x - 3y + 17 = 0, x + 2y - 3 = 0; \end{array} \right.$$

$$\left. \begin{array}{l} \text{b) } (1; 1); \text{c) } \left( -\frac{1}{2}; \frac{11}{2} \right) \end{array} \right]$$

496 Trova le coordinate del baricentro e del circocentro e l'area del triangolo di vertici A(2; 1), B(8; 1) e C(5; 4). [(5; 2); (5; 1); 9]

497 Verifica che il triangolo di vertici

$$A(3; 0), B\left(\frac{18}{5}; \frac{9}{5}\right) \text{ e } C\left(\frac{24}{5}; -\frac{3}{5}\right)$$

è rettangolo isoscele. Determina poi il centro e il raggio della circonferenza circoscritta al triangolo.

$$\left[ \left( \frac{21}{5}; \frac{3}{5} \right); \frac{3}{5} \sqrt{5} \right]$$

498 Dato il triangolo di vertici A(-1; -1), B(-1; 5), C(8; 2), verifica che è un triangolo isoscele e trova il baricentro, il circocentro e l'ortocentro.

$$\left[ (2; 2), (3; 2), (0; 2) \right]$$

499 Verifica che nel triangolo ABC, di vertici A(-2; -2), B(4; -2) e C(1; 6), il baricentro, l'ortocentro e il circocentro sono allineati.

500 Calcola le coordinate dell'incontro, del circocentro, del baricentro e dell'ortocentro del triangolo di vertici A(0; 8), B(6; 0) e C(0; 0).

$$\left[ (2; 2); (3; 4); \left( 2; \frac{8}{3} \right); (0; 0) \right]$$

501 Dopo aver verificato che il triangolo di vertici A(1; 2), B(7; 2), C(4; 5) è un triangolo isoscele, trova le coordinate dell'incontro, del baricentro e dell'ortocentro. [(4; 3√2 - 1); (4; 3); (4; 5)]

502 È dato il triangolo di vertici A(-1; 0), B(3; 2), C(1; 3).

a. Determina le coordinate del baricentro \(G\) del circumocentro \(D\) dell'ortocentro \(H\)
b. Verifica che \(G, D, H\) sono allineati e che \(G\) divide il segmento \(DH\) in due parti tali che \(GH \cong 2DG\) (teorema di Eulero).

$$\left[ \text{a) } G\left( 1; \frac{5}{3} \right), D\left( \frac{9}{8}; \frac{3}{4} \right), H\left( \frac{3}{4}; \frac{7}{2} \right) \right]$$

251

ESERCIZI