Capitolo 4

PIANO CARTESIANO E RETTA

# MATEMATICA PER L'EDUCAZIONE CIVICA

# Prezzo di equilibrio

# EDUCAZIONE FINANZIARIA

In economia, la funzione della domanda rappresenta la quantità di un certo bene richiesta dai consumatori in funzione del suo prezzo, mentre la funzione dell'offerta rappresenta la quantità di bene immessa sul mercato. La funzione della domanda è decrescente: se aumenta il prezzo, i consumatori sono meno propensi all'acquisto. La funzione dell'offerta è invece crescente: all'aumentare del prezzo i produttori sono più propensi a immettere sul mercato una maggiore quantità di bene. Il prezzo di equilibrio è quello in cui le due funzioni hanno lo stesso valore.

ESEMPIO L'offerta e la domanda di legna da ardere sono descritte rispettivamente dalle equazioni $q = 2p - 10$ e $q = -\frac{3}{2}p + 32$, dove $q$ è la quantità di legna, in quintali, e $p$ è il prezzo, in €/quintale. Troviamo il prezzo di equilibrio. Rappresentiamo le due funzioni in un piano cartesiano $Opq$. Risolviamo il sistema delle loro equazioni.

$$\begin{cases} q = 2p - 10 \\ q = -\frac{3}{2}p + 32 \end{cases} \rightarrow \begin{cases} q = 2p - 10 \\ 7p = 84 \end{cases} \rightarrow \begin{cases} q = 14 \\ p = 12 \end{cases}$$

$p = 12$ €/quintale è il prezzo di equilibrio.

In corrispondenza del prezzo di equilibrio, la quantità offerta e la quantità domandata sono uguali entrambe a 14 quintali.

# ESERCIZIO

1 Trova il prezzo di equilibrio per il parcheggio di un'automobile per 24 ore in una città di mare, sapendo che l'offerta e la domanda sono descritte rispettivamente dalle equazioni $p - q = 6$ e $2q + 3p = 38$, dove $q$ è il numero complessivo di soste di 24 ore in un mese (in migliaia) e $p$ è il prezzo in euro di una singola sosta per giornata. [10 €/giorno]

![img-51.jpeg](img-51.jpeg)

![img-52.jpeg](img-52.jpeg)

# Interpreta graficamente le seguenti equazioni e risolvile algebricamente.

$$\boxed{310} \quad |x - 1| = 2|x| - 1$$

$$\left[ -2; \frac{2}{3} \right]$$

# RISOLVI IN 3 PASSI

1 Indica con $f(x)$ il primo membro e con $g(x)$ il secondo membro dell'equazione e rappresenta nello stesso sistema di assi cartesiani le funzioni $y = f(x)$ e $y = g(x)$ ottenute; ciascun grafico è l'unione di due semirette.
2 Osserva i punti di intersezione $A$ e $B$ dei due grafici. Le ascisse di $A$ e $B$ sono le soluzioni dell'equazione.
3 Poni a sistema le equazioni delle opportune semirette e risolvi algebricamente il sistema.

$$\boxed{311} \quad |x + 1| = -\frac{x}{2}$$

$$\left[ -2; -\frac{2}{3} \right]$$

$$\boxed{313} \quad |x| - 1 = -|x - 3|$$

[impossibile]

$$\boxed{312} \quad -\frac{|x|}{2} + 2 = |x + 2|$$

$$\left[ -\frac{8}{3}; 0 \right]$$

$$\boxed{314} \quad |1 - x| + 1 = \frac{|x + 1|}{2}$$

[1]

# Interpreta graficamente le seguenti disequazioni e risolvile algebricamente.

$$\boxed{315} \quad |x - 2| > |x| + 1$$

$$\left[ x < \frac{1}{2} \right]$$

$$\boxed{317} \quad \frac{2}{3}|x| - 1 \leq |x - 4|$$

$$[x \leq 3 \lor x \geq 9]$$

$$\boxed{316} \quad |x| - 1 \leq -|x + 2| + 3$$

$$[-3 \leq x \leq 1]$$

$$\boxed{318} \quad |x - 4| + 5 > \frac{|x + 5|}{3}$$

$$[\forall x \in \mathbb{R}]$$

ESERCIZIO

234