FAI IL PUNTO SULLE COMPETENZE

Per ciascuna retta, scrivi l'equazione della parallela e della perpendicolare passanti per il punto A.

422 $$y = \frac{1}{4}x, \quad A(1; -1).$$

423 $$2x + 3y - 1 = 0, \quad A(-3; 0).$$

424 $$3x + 6y + 2 = 0, \quad A(5; 1).$$

425 Fra le rette parallele alla retta r di equazione $$3x + 6y - 5 = 0$$, individua quella che passa per il punto P(3; 1) e quella passante per l'origine. $$[2y + x - 5 = 0; 2y + x = 0]$$

426 Fra le rette passanti per il punto Q(-3; -5), individua l'equazione della retta parallela alla retta passante per A(3; 2) e B(1; 1). $$\left[y = \frac{1}{2}x - \frac{7}{2}\right]$$

427 Scrivi l'equazione della retta r che passa per l'origine degli assi ed è perpendicolare alla retta s passante per i punti A(2; 0) e B(0; -5). $$[2x + 5y = 0]$$

428 Scrivi l'equazione della retta che passa per il punto C(-2; 3) ed è perpendicolare alla retta passante per A(2; 5) e B(-3; -1). $$[5x + 6y - 8 = 0]$$

429 Sia M il punto medio del segmento di estremi A(3; 2) e B(1; 6). Scrivi l'equazione della retta r passante per M e parallela alla bisettrice del primo e terzo quadrante. Determina poi il punto di intersezione tra la retta r e la retta s di equazione $$y = 3x - 2$$. $$[y = x + 2; M(2; 4)]$$

LEGGI IL GRAFICO Scrivi le equazioni di ciascuna coppia di rette parallele delle figure.

![img-92.jpeg](img-92.jpeg)

![img-93.jpeg](img-93.jpeg)

![img-94.jpeg](img-94.jpeg)

![img-95.jpeg](img-95.jpeg)

# FAI IL PUNTO SULLE COMPETENZE

Prima di iniziare, esercitati su laZ Esercizi

# Posizione reciproca di due rette
Retta per un punto, retta per due punti

LEGGI IL GRAFICO ASSOCIA a ogni equazione di una retta il grafico della retta a essa parallela.

a. $$2x - 8y + 1 = 0$$

b. $$2x + y = 0$$

c. $$y = 3x + 1$$

d. $$2x + 4y + 4 = 0$$

![img-96.jpeg](img-96.jpeg)

2 Considera le equazioni lineari nelle incognite x e y:

$$kx - y + k - 2 = 0; \quad 2x - (k + 1)y + 3 = 0.$$

a. Determina i valori del parametro reale \(k\) per cui le equazioni rappresentano due rette parallele e disegna le rette individuate.
b. Intersecandosi a due a due, le rette del punto a individuo un quadrilatero: classificato e calculane il perimetro.

$$\left[a) k = -2 \vee k = 1; \text{b) parallelogramma, } 2\left(\frac{\sqrt{2}}{3} + \frac{5}{6}\sqrt{5}\right)\right]$$

>SEGUE

245

ESERCIZI