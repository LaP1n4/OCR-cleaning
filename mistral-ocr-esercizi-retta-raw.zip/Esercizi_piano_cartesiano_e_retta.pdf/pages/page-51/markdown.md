Capitolo 4 PIANO CARTESIANO E RETTA

# FONDAMENTALI ALLA PROVA

Fai questi esercizi anche su laZ Esercizi

PUNTI NEL PIANO CARTESIANO Determina per quali valori di \(k\) il punto \(P(k - 3;8 - k)\) appartiene:
a. all'asse delle ordinate; b. al secondo quadrante.
2 DISTANZA FRA DUE PUNTI Determina il perimetro del triangolo di vertici \(A(-3;3),B(1;0)\in C(1;2).\)
3 AREA DI UN POLIGONO Calcola l'area del quadrilatero di vertici \(A(2; - 2),B(1;9),C(-2;3)\in D(-1; - 4).\)
4 PUNTO MEDIO DI UN SEGMENTO Associa ogni coppi di punti al punto medio del segmento di cui sono estremi.

a. $A(3; -2)$ e $B(-5; 4)$.

b. $A(-3; 5)$ e $B(3; 7)$.

c. $A(-7; 1)$ e $B(3; 3)$.

d. $A(5; 3)$ e $B(7; -3)$.

1. $M(-2; 2)$.

2. $M(0; 6)$.

3. $M(6; 0)$.

4. $M(-1; 1)$.

5 BARICENTRO DI UN TRIANGOLO Determina le coordinate del baricentro del triangolo di vertici \(A(6; - 2),B(1;3)\) e \(C(2; - 4)\)
6 EQUAZIONE DELLA RETTA La retta di equazione \(3x - 5y + 6 = 0\)

A forma un angolo ottuso con l'asse \(x\)
B interseca l'asse \(y\) in un punto di ordinata negativa.
\(\boxed{\mathbb{C}}\) passa per l'origine degli assi.
D passa per il punto \(P(-12; - 6)\)

![img-117.jpeg](img-117.jpeg)

7 DAL GRAFICO ALL'EQUAZIONE Scrivi le equazioni delle rette $s$, $t$ e $w$ rappresentate nel grafico.

8 RETTE PARALLELE E PERPENDICOLARI Stabilisci quali rette sono parallele tra loro e quali perpendicolari tra loro.

a. \(y = -7x + 3\)
b. \(14x + 2y + 3 = 0\)
c. \(x - 7y + 2 = 0\)
d. \(7x - y + 5 = 0\)

9 DETERMINARE L'EQUAZIONE DI UNA RETTA Determina l'equazione della retta passante per il punto \(P(-1;6)\) e di coefficiente angolare \(-4\)
10 DETERMINARE L'EQUAZIONE DI UNA RETTA Scrivi l'equazione della retta che passa per i punti di coordinate \((5; -2)\in (3;8)\)
11 DETERMINARE L'EQUAZIONE DI UNA RETTA Determina l'equazione della retta passante per \(A(3;1)\) e perpendicolare alla retta che passa per \(B(-2;0)\in C(-4;6)\).
12 DISTANZA DI UN PUNTO DA UNA RETTA Calcola la distanza del punto \(Q(-3;2)\) alla retta di equazione \(4x + 3y - 1 = 0\)
13 FASCI DI RETTE Stabilisci se le seguenti affirmazioni sono vere o false.

a. Il fascio improprio di rette contenti la retta \(2y + 14x + 7 = 0\) ha equazione \(y = -7x + q\)
b. L'equazione \( y = m(x - 5) \) rappresenta, al variate di \( m \), tutte le rette passanti per \( A(5;0) \).
c. L'equazione \(3kx - 2ky - 4 = 0\) , con \(k\neq 0\) , rappresenta un fascio improprio di rette.
d. L'equazione \(x - y + k(1 - x) = 0\) rappresenta un fascio proprio di centro (1; 1).

VERIFICA LE COMPETENZE

264