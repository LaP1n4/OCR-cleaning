RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Parti del piano e della retta e disequazioni in due variabili

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Rappresentare il semipiano definito da una disequazione

Rappresentiamo il semipiano definito dalla disequazione $6x + 3y - 2 \geq 0$.

# 1 Primo metodo

![img-49.jpeg](img-49.jpeg)

Esplicitiamo rispetto a $y$: $6x + 3y - 2 \geq 0 \rightarrow y \geq -2x + \frac{2}{3}$.

Disegniamo la retta $r$ di equazione $y = -2x + \frac{2}{3}$.

Le soluzioni della disequazione sono rappresentate da tutti i punti del semipiano che hanno l'ordinata maggiore o uguale all'ordinata del punto che ha la stessa ascissa e si trova sulla retta.

# 2 Secondo metodo

Per evitare di esplicitare la disequazione rispetto a $y$, si può procedere mediante un punto di prova. Per comodità consideriamo come punto

di prova l'origine $O$. Sostituiamo le sue coordinate nella disequazione.

Otteniamo $-2 \geq 0$, che è falso, quindi $O$ non appartiene al semipiano cercato, che è allora quello opposto al semipiano a cui appartiene $O$.

Per usare il punto di prova, scegliamo un punto che non appartiene alla retta e sostituiamo le sue coordinate nella disequazione.

Se la disequazione è verificata, il semipiano a cui appartiene il punto è quello cercato, altrimenti è quello opposto.

# Rappresenta nel piano cartesiano l'insieme delle soluzioni delle seguenti disequazioni.

266 $y \leq 4$

267 $y \leq 6$

268 $y > x + 4$

269 $x < y$

270 $x \geq -3$

271 $y \geq 2x$

272 $y + x + 5 \geq 0$

273 $y - x - 1 > 0$

274 $x + y > 2$

275 $2y + x \geq 4$

276 $2x + 3 \geq 0$

277 $x + 6 > 0$

278 $x < y + 8$

279 $y \geq 2|x|$

280 $y \leq |x + 1|$

# Semirette e segmenti

Rappresenta nel piano cartesiano la semiretta o il segmento definiti da ciascuno dei seguenti sistemi.

281 $\begin{cases} y = 2x - 1 \\ x \leq 2 \end{cases}$

282 $\begin{cases} y + 1 = 0 \\ x \geq \frac{1}{3} \end{cases}$

283 $\begin{cases} x = 3 - y \\ 0 \leq x < 4 \end{cases}$

284 $\begin{cases} 4x + 2y - 1 = 0 \\ -\frac{1}{2} < x \leq 4 \end{cases}$

# Altre regioni del piano

Rappresenta nel piano cartesiano l'insieme delle soluzioni dei seguenti sistemi di disequazioni.

285 $\begin{cases} y \geq -x - 1 \\ x - 2y + 2 \geq 0 \end{cases}$

# RISOLVI IN 2 PASSI

1 Rappresenta ciascuno dei due semipiani. Puoi farlo applicando il metod del punto di prova.
2 Le soluzioni del systeme sono rappresentate dall'intersezione dei due semipiani.

ESERCIZIO

231