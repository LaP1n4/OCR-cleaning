Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZIO

397

Determina il valore del parametro k affinché il punto A(8k - 6; 2k) appartenga alla retta passante per i punti P(1/2; 0) e Q(3; 5/3).

398

REALTÀ E MODELLI Nella loro azienda agricola Camilla e Petre producono farina biologica di grani antichi. Per produrre 50 kg di farina sostengono un costo di 90 €, mentre per produrre 200 kg i costi ammontano a 210 €. Il grafico della funzione che lega la quantità x di farina prodotta (in kg) ai costi complessivi y (in €) è una retta. Scrivi l'espressione analitica della funzione, calcola la spesa necessaria per produrre 400 kg di farina e determina quanta farina si può ottenere sostenendo dei costi di 1010 €.

[4x - 5y + 250 = 0; 370 €; 1200 kg]

![img-80.jpeg](img-80.jpeg)

399

![img-81.jpeg](img-81.jpeg)

FISICA MOTO RETTILINEO La figura a lato rappresenta il grafico velocità-tempo di due oggetti in moto rettilineo uniformemente accelerato. Scrivi le equazioni delle due rette e determina le accelerazioni dei due oggetti.

[v = 0,40t + 5,6; v = 0,25t + 1,0; aA = 0,40 m/s²; aB = 0,25 m/s²]

400

REALTÀ E MODELLI Un insetto nel piano Oxy parte dal punto (1; 9). Si muove dapprima fino al punto (2; 10), poi al punto (3; 11) e così via. Continua a muoversi in questo modo fino a che raggiunge un punto la cui coordinata y è il doppio della coordinata x. Quali sono le coordinate di questo punto?

(CAN, Canadian Open Mathematics Challenge)

[(8; (6))]

# MATEMATICA PER L'EDUCAZIONE CIVICA

# Energia del vento

# SOSTENIBILITÀ APIRIENTALE

L'energia eolica è una risorsa importante per un futuro sostenibile. Infatti, permette di generare elettricità con poche emissioni nocive, contribuendo così alla riduzione dell'inquinamento atmosferico. Inoltre, sfruttare l'energia del vento consente di ridurre la dipendenza dalle fonti energetiche fossili e di promuovere l'indipendenza energetica da altri Paesi.

![img-82.jpeg](img-82.jpeg)

ESERCIZIO In un Paese, in un certo anno che consideriamo l'anno 0, la potenza eolica installata (cioè la potenza totale degli impianti eolici presenti) era di 2 GW (gigawatt).

Negli anni seguenti, la funzione che esprime la potenza eolica installata, in GW, al variare del tempo, in anni, è stata, in modo approssimato, lineare. Dopo 10 anni la potenza eolica installata è di circa 10 GW.

Scrivi l'equazione della retta che rappresenta la funzione, indicando con y la potenza eolica installata e con x il numero degli anni. Che significato ha il coefficiente angolare della retta? [y = 0,8x + 2]

# UN PASSO IN PIÙ

- Cerca in rete dove sono maggiornente concentrati gli impianti eolici in Italia.
- Cerca informazioni sulla potenza elettrica totale generata in Italia e confrontala con quella proveniente dagli impianti eolici.

242