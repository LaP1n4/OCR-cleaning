Capitolo 4

PIANO CARTESIANO E RETTA

# Appartenenza di un punto a una retta

Stabilisci se le rette che hanno le seguenti equazioni passano per i punti indicati.

171 \(2x - 6y - 1 = 0,\) \(A\left(-\frac{1}{2};0\right),\) \(B\left(1;\frac{1}{6}\right),\) \(C(-1;0),\) \(D\left(10;\frac{3}{2}\right).\)
172 \(y = -x + 2,\) \(A(-5;3),\) \(B(10;4),\) \(C(-10;0),\) \(D(0; - 2).\)

GENERALIZZA CON PYTHON

Considerata una retta di equazione $y = mx + 2$, scrivi un programma che acquisisca in input i valori di $m$ e delle coordinate di un punto $P$, anche come frazioni, e, dopo aver detto se la retta passa per $P$, disegni il grafico con la retta e il punto.

173 Sulla retta di equazione \(2x + y - 3 = 0\) determina il punto \(A\) di ascissa \(-1\) e il punto \(B\) di ordinata 7.
Data la retta di equazione \(2x + y - 5 = 0\), stabilisci se i punti \(A(2;1)\) e \(B(1;1)\) appartengono aessa e determina l'ordinata del suo punto \(C\) di ascissa 1 e l'ascissa del suo punto \(D\) di ordinata 4. \(\left[C(1;3),D\left(\frac{1}{2};4\right)\right]\)
Determina per ciascuna delle rette di equazioni \(x - 4y + 7 = 0,2x + 6y - 7 = 0\) e \(2y - x - 4 = 0\) il relativo punto di ordinata \(-\frac{1}{2}\). \(\left[\left(-9; - \frac{1}{2}\right),\left(5; - \frac{1}{2}\right),\left(-5; - \frac{1}{2}\right)\right]\)
Un punto \(P\) della retta di equazione \(y = -3x + 4\) e distante \(4\sqrt{2}\) da \(Q(2;6)\). Trova le sue coordinate.

$\left[(-2; 10) \text{ o } \left(\frac{6}{5}; \frac{2}{5}\right)\right]$

# RISOLVI IN 2 PASSI

1 Se un punto \(P\) generico appartiene alla retta di equazione \(y = -3x + 4\), le sue coordinate sono \((x; -3x + 4)\).
2 Imponi che la distanza di \(P\) da \(Q\) sua \(4\sqrt{2}\) e risolvi l'equazione in \(x\) che ottieni.

17 Quali punti della bisettrice del primo e terzo quadrante distano \(\sqrt{13}\) da \(A(4; - 1)\)? [(1;1); (2;2)]
178 Considera la retta di equazione \(6x - y - 12 = 0\) e calcula l'area del triangolo che esta forma con gli assi cartesiani. [12]
179 Per quale valore di \(a\) il punto \(A(a - 2;1 - 3a)\) appartiene alla retta di equazione \(x - 2y = 3?\) \([a = 1]\)
170 Trova il valore di \(k\) affinché l'equazione \((k + 1)x - ky + 2 = 0\) sua l'equazione di una retta passante per il punto \(A(1; - 2)\) e disegna tale retta. \([k = -1]\)
Calcola il valore del parametro \(k\) affinché la retta di equazione \((2k - 1)x - (k + 1)y + k = 0\) passi per il punto \(A(0;3)\). Disegna tale retta dopo aver trovato i punti che ha in comune con l'asse \(x\) e con l'asse \(y\).

$\left[k = -\frac{3}{2}, \left(-\frac{3}{8}; 0\right), (0; 3)\right]$

182 SPIEGA PERCHÉ Dimostra che la distance tra due punti \(A(x_{A};y_{A})\) e \(B(x_{B};y_{B})\) appartenenti a una retta di equazione \(y = mx + q\) è independente da \(q\).
183 Trova, se esiste, per quale valore di \(k\) l'equazione lineare \((k^2 + k - 2)x + (k^2 - k)y + k^2 - 1 = 0\) in \(x, y\):

a. non rappresenta una retta;

c. rappresenta una retta passante per $P(1; 0)$.

b. rappresenta una retta parallela all'asse $y$;

$\left[a) k = 1; b) k = 0; c) k = -\frac{3}{2}\right]$

184 Trova, se esiste, il valore di $c$ tale che la retta di equazione $x + cy = 1$:

a. sia parallela all'asse $x$;

c. sia parallela all'asse $y$;

b. passi per $(3; 1)$;

d. passi per il punto dell'asse $y$ di ordinata $-\frac{1}{2}$.

$\left[a) \nexists c \in \mathbb{R}; b) c = -2; c) c = 0; d) c = -2\right]$

185 REALTÀ E MODELLI Un gruppo di studenti controlla il ritardo dell'orologio della propria aula confrontando per diversi giorni l'ora indicata dall'orologio con quella di un orologio satellitare. Gli studenti riescono a descrivere il ritardo accumulato $R$, in secondi, tramite l'equazione $R = \frac{3}{2} G + 9$, dove $G$ è il numero dei giorni trascorsi dall'inizio dell'esperimento. Rappresenta in un grafico l'equazione ricavata e determina il ritardo accumulato 30 giorni dopo la prima misurazione. [54 s]

![img-36.jpeg](img-36.jpeg)

ESERCIZI

226