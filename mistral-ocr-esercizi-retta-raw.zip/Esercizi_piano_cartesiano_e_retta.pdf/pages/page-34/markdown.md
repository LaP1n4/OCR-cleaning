DISTANZA DI UN PUNTO DA UNA RETTA

Paragrafo 5

# 5 Distanza di un punto da una retta

Teoria a pagina 206

434 TEST È vera solo una delle seguenti proposizioni relative al punto $P(1; -2)$ e alle rette $r$ e $s$, rispettivamente di equazioni $2x + y = 0$ e $x + y - 2 = 0$. Quale?

A \(P\) e equidistante da r e da s.
La distanza di \(P\) da \(r\) è maggiore della distanza di \(P\) da s.
\(\boxed{C}\) \(P\) appartiene a s ma non a r.
D \(P\) appartiene a r ma non a s.

Distanza $d$ di $P(x_0, y_0)$ dalla retta di equazione $ax + by + c = 0$:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

435 TEST Il triangolo di vertici $A(-1; -2)$, $B(6; 5)$ e $C(k; -3)$ ha area 28. Qual è il valore di $k$?

A 6.
C 10.
B \(60 - 10\)
D-6o10.

Determina la distanza del punto $P$ dalla retta data.

436 \(P(2; - 6)\) \(3x + 4y = 0.\) （18
437 \(P(2; - 4)\) \(2x - y + 2 = 0.\) （2√5]

438 \(P(-1;4)\) \(y = -\frac{1}{3} x + 2.\) （ \(\frac{\sqrt{10}}{2}\)
439 \(P(4;2)\) \(y = -x - 2.\) （4√2]

440 Stabilisci quale delle seguenti rette ha minore distanza dal punto $P(-1; 3)$:

$$r: x = -3; \quad s: y = -x; \quad t: y = x + 1.$$ [5]

441 Calcola la distanza del punto \(P(0;6)\) alla retta che passa per i punti \(A(2;3)\) e \(B\left(\frac{1}{2};1\right)\). [17]
442 Considera il triangolo \( ABC \) di vertici \( A(-3;3) \), \( B(1; -3) \), \( C(3;1) \). Calcola la misura dell'altezza relativa al lato \( AB \) e l'area del triangolo.

$$\left[ \frac{14\sqrt{13}}{13}; 14 \right]$$

443 Determina l'area del triangolo di vertici $A(4; 0)$, $B(-2; 6)$ e $C(8; 8)$. [36]

# RISOLVI IN 3 PASSI

1 Determina l'equazione della retta \(AB\) e scrivila in forma implicita.
2. Trova la misura dell'altezza relativa al lato \(AB\) come distanza tra il punto \(C\) e la retta \(AB\).
3 Determinina la misura del segmento \(AB\) e calcola l'area del triangolo.

444 Determina la distanza fra le rette parallele di equazioni $y = 2x + 7$ e $y = 2x - 3$. [2√5]

# RISOLVI IN 2 PASSI

1. Considera un punto a piacere su una delle due rette.
2. Calcola la distanza fra il punto scelto e l'altra retta.

445 Calcola la distanza tra le due rette parallele di equazioni $2x - 4y + 1 = 0$ e $y = \frac{1}{2}x + 2$. [7√5/10]

446 Calcola la distanza fra la retta passante per $A(-2; 0)$ e $B(3; 1)$ e la retta di equazione

$$x - 5y - 3 = 0. \quad \left[ \frac{5\sqrt{26}}{26} \right]$$

447 Calcola la misura delle altezze del triangolo di vertici $A(4; 3)$, $B(11; 4)$ e $C(7; 8)$.

$$\left[ \frac{16}{5}\sqrt{2}; \frac{16}{17}\sqrt{34}; \sqrt{32} \right]$$

448 Per quali valori del parametro \(k\) la distanza del punto \(P(k - 1;k)\) alla retta di equazione \(x - 2y - 2 = 0\) e \(\sqrt{5}\) ? \([k = 2\lor k = -8]\)
449 Per quali valori del parametro \(k\) la distanza del punto \(P(1 - 2k;3 + k)\) alla retta di equazione

$$12x - 5y - 2 = 0 \text{ è } \frac{24}{13}? \quad \left[ k = \frac{19}{29} \lor k = -1 \right]$$

450 Data la retta di equazione

$$(2 + 3k)x + (1 - k)y - 3 - 2k = 0,$$

trova per quali valori di $k$ la sua distanza dal punto $P(4; 4)$ è uguale a $\frac{9}{5}\sqrt{5}$.

$$\left[ k = 0 \lor k = -\frac{3}{7} \right]$$

451 Calcola le coordinate dei punti della retta di equazione $x - 3y - 2 = 0$ che hanno distanza $2\sqrt{5}$ dalla retta di equazione $y = 2x + 1$.

$$[(-7; -3), (5; 1)]$$

452 Fra tutti i triangoli $ABC$ di base $AB$, con $A(1; 0)$ e $B(0; 3)$, considera quelli per i quali il vertice $C$ appartiene alla retta $3y - x = 0$ e la cui area vale $\frac{19}{6}$. Trova le coordinate di $C$.

$$\left[ C_1(-1; -\frac{1}{3}), C_2\left(\frac{14}{5}; \frac{14}{15}\right) \right]$$

ESERCIZI

247