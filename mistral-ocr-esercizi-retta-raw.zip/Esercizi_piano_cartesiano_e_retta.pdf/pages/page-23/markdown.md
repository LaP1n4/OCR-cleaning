Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

324

EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA A un autotrasportatore vengono proposte due offerte di guadagno per il trasporto di una certa merce:

A: 115 € fissi più 0,25 € per agli quintale di merce trasportata;
B: 58 € fissi più 1,20 € per agli quintale di merce trasportata.

Sapendo che il massimo carico trasportabile è pari a 10 t, quale offerta è più conveniente per l'autotrasportatore in relazione alla quantità trasportata? [A per 0 q ≤ x < 60 q; B per 60 q < x ≤ 100 q]

325

EDUCAZIONE FINANZIARIA COSTO E RICAVO Per la vendita di hamburger in strada, Marco e Michela devono pagare una rata mensile di 300 € e 900 € all'anno per la licenza.

![img-57.jpeg](img-57.jpeg)

Hanno valutato che il costo medio di 100 hamburger è di 200 € e il prezzo medio di vendita di un panino è di 5 €.

Considera come orizzonte temporale un anno. Scrivi e rappresenta graficamente la funzione del costo complessivo e la funzione del ricavo.

Se Marco e Michela non vogliono andare in perdita, quanti hamburger devono vendere come minimo in un anno? [1500]

326

FISICA MOTO RETTILINEO Elena e Filippo abitano agli estremi opposti di una strada rettilinea e si muovono da casa per incontrarsi. La funzione che esprime la distanza s_F (in metri) percorsa da Elena rispetto al tempo t (in minuti) è s_F(t) = 50 · t; Filippo parte 2 minuti dopo e la funzione che esprime la sua distanza dalla casa di Elena rispetto al tempo è:

$$s_F(t) = \begin{cases} 700 & \text{se } 0 \le t \le 2 \\ 900 - 100 \cdot t & \text{se } t > 2 \end{cases}$$

a. Rappresenta graficamente le due funzioni. (Suggerimento. Per l'asse delle ordinate considera come unità di misura \(100\mathrm{m}\).)
b. Dopo quanto tempo si incontrano? [b) 6,0 min]

327

FISICA MOTO NEL PIANO Due corpi puntiformi si muovono in un piano con le seguenti leggi orarie:

A: $$\begin{cases} x(t) = 2t \\ y(t) = 4t + 1 \end{cases}$$, B: $$\begin{cases} x(t) = 3t + 1 \\ y(t) = 9t \end{cases}$$, con x e y in metri, t in secondi, t ≥ 0.

Ricava le traiettorie dei due corpi, rappresentate in un riferimento Oxy e determina il punto in cui le traiettorie si intersecano. Nel loro moto, i due corpi si incontrano? [(4; 9); no]

328

FISICA GRAFICO SPAZIO-TEMPO Nella figura sono rappresentati i grafici spazio-tempo per le leggi orarie del moto di due escursionisti.

![img-58.jpeg](img-58.jpeg)

a. Dopo i primi 20 minuti, chi ha percorso la distanza maggiore?
b. In che intervallo di tempo l'escursionista \(B\) è «in testa»?
c. In che istanti di tempo avvengono i sorpassi?
d. Scrivi le equazioni delle leggi orarie che descrivono i moti degli escursionisti \(A\) e \(B\).

# Rette parallele e rette perpendicolari

Teoria alle pagine 201 e 202

2 attività interattive

Determina il coefficiente angolare delle rette di ciascuno dei seguenti gruppi e stabilisci quali sono parallele e quali perpendicolari.

329

$$y = -3x + 1,$$

$$y + 3x - 2 = 0,$$

$$6y = -2x + 1,$$

$$3y - x - 5 = 0.$$

330

$$2y - 5x - 2 = 0,$$

$$y = -\frac{2}{5}x,$$

$$y = -\frac{2}{5}x - \frac{2}{5},$$

$$y = \frac{5}{2}.$$

331

$$3x - 2y + 1 = 0,$$

$$-6x + 4y + 7 = 0,$$

$$y = \frac{2}{3}x + 1,$$

$$-6x - 9y = 0.$$

236