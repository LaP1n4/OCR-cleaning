Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

374 TEST Una retta interseca gli assi coordinati nei punti $P(-3; 0)$ e $Q(0; -1)$. Quanto vale il suo coefficiente angolare?

A -3

B $\frac{1}{3}$

C $-\frac{1}{3}$

D 0

# LEGGI IL GRAFICO

375 Scrivi il coefficiente angolare delle rette rappresentate nei seguenti grafici.

![img-60.jpeg](img-60.jpeg)

![img-61.jpeg](img-61.jpeg)

![img-62.jpeg](img-62.jpeg)

![img-63.jpeg](img-63.jpeg)

a

b

c

d

Scrivi le equazioni delle rette $r$, $s$ e $t$ rappresentate nelle figure.

![img-64.jpeg](img-64.jpeg)

![img-65.jpeg](img-65.jpeg)

![img-66.jpeg](img-66.jpeg)

In base alle indicazioni date in ogni figura, ricava $m$ e scrivi l'equazione della retta rappresentata.

![img-67.jpeg](img-67.jpeg)

![img-68.jpeg](img-68.jpeg)

![img-69.jpeg](img-69.jpeg)

![img-70.jpeg](img-70.jpeg)

383 FISICA GRAFICI SPAZIO-TEMPO La figura a lato rappresenta i grafici spazio-tempo di due corpi in moto uniforme.

![img-71.jpeg](img-71.jpeg)

a. Senza fare calcoli, quale corpo è più veloce? Perché?
b. Calcola la velocità dei due corpi.

[b) $v_A = 2,0 \text{ m/s}$; $v_R = 1,0 \text{ m/s}$]

384 Determina l'equazione della retta che passa per $C(-1; 2)$ e ha il coefficiente angolare uguale a quello della retta che passa per $A(2; 2)$ e $B(1; -4)$. [y = 6x + 8]

240