Capitolo 4

PIANO CARTESIANO E RETTA

# Distanza fra due punti

Teoria a pagina 194

1 attività interattiva

# I FONDAMENTALI

Prova tu fai un esercizio simile interattiva

# Calcolare la distanza fra due punti

Dati i punti $A(4; 1)$, $B(4; 4)$ e $C(-2; 4)$, calcoliamo le distanze $\overline{AB}$, $\overline{BC}$ e $\overline{CA}$.

I punti $A(4; 1)$ e $B(4; 4)$ hanno la stessa ascissa, quindi:

![img-7.jpeg](img-7.jpeg)

$$\overline{AB} = |y_A - y_B| = |1 - 4| = |-3| = 3.$$

I punti $B(4; 4)$ e $C(-2; 4)$ hanno la stessa ordinata, quindi:

$$\overline{BC} = |x_B - x_C| = |4 - (-2)| = |4 + 2| = |6| = 6.$$

I punti $C(-2; 4)$ e $A(4; 1)$ hanno ascisse e ordinate diverse:

$$\overline{CA} = \sqrt{(x_C - x_A)^2 + (y_C - y_A)^2} = \sqrt{(-2 - 4)^2 + (4 - 1)^2} =$$

$$\sqrt{36 + 9} = \sqrt{45} = 3\sqrt{5}.$$

Per la presenza dei quadrati, è indifferente scegliere $C$ o $A$ come primo punto.

$$A(x_A; y_A), B(x_B; y_B)$$

$$\overline{AB} = \sqrt{(x_A - x_B)^2 + (y_A - y_B)^2}$$

# Calcola la distanza fra i punti indicati.

28

$A(2; 1)$,

$B(2; 6)$.

29

$A(-4; \frac{4}{3})$,

$B(-4; \frac{5}{6})$.

30

$A(-\frac{3}{4}; 4)$,

$B(\frac{17}{4}; 2)$.

31

$A(2; 6)$,

$B(9; -1)$.

32

$A(-10; \frac{1}{2})$,

$B(1; \frac{1}{2})$.

33

$A(\frac{4}{3}; 15)$,

$B(\frac{1}{3}; 7)$.

34

$A(2 + \sqrt{2}; 0)$,

$B(2; \sqrt{7})$.

35

$A(-\sqrt{2}; -1)$,

$B(\sqrt{18}; -6)$.

# Trova la distanza dei seguenti punti dall'origine.

36

$A(-4; -3), B(2; -1)$.

37

$A(8; -15), B(-6; 8)$.

38

$A(-1; 7), B(-7; -1)$.

# Determina il perimetro dei triangoli che hanno i seguenti vertici.

39

$A(2; 4), B(2; 1), C(6; 3)$.

40

$A(\frac{1}{2}; 7), B(-2; 3), C(3; -1)$.

41

$A(6; 3), B(-1; 3), C(1; -2)$.

# LEGGI IL GRAFICO Calcola il perimetro dei seguenti poligoni.

![img-8.jpeg](img-8.jpeg)

![img-9.jpeg](img-9.jpeg)

![img-10.jpeg](img-10.jpeg)

42

![img-11.jpeg](img-11.jpeg)

![img-12.jpeg](img-12.jpeg)

45

REALTÀ E MODELLI Il Quadrilatero della Moda è una zona di Milano famosa per i negozi di lusso. Deve il suo nome al fatto che la delimitano quattro strade, via Monte Napoleone, via Manzoni, via della Spiga e corso Venezia, formando una figura simile a un quadrilatero. In un sistema di riferimento come quello in figura, con l'unità di misura in decametri, possiamo assumere che i vertici del quadrilatero abbiano coordinate $A(30; 0)$, $B(46; 17)$, $C(15; 54)$ e $D(0; 33)$. Karim percorre tutto il quadrilatero, camminando alla velocità costante di 5 km/h e senza soste. Quanto tempo impiega?

[circa 17 minuti]

ESERCIZI

216