MATEMATICA PER LE STEM

MATEMATICA PER LE STEM

# Terremoti e piano di Benioff in sezione

SCIENZE DELLA TERRA

I geologi studiano fenomeni che talvolta hanno effetti catastrofici, come terremoti ed eruzioni vulcaniche.

Tra i fenomeni geologici più importanti c'è la subduzione, cioè il progressivo slittamento di una placca di litosfera al di sotto di un'altra.

Quando questo avviene, la placca in subduzione viene trascinata in profondità lungo un piano inclinato, chiamato piano di Benioff.

Nella zona di subduzione si registrano numerosi terremoti e nel piano di Benioff si allineano gli ipocentri, i punti in profondità da cui si propagano i sismi.

![img-115.jpeg](img-115.jpeg)

ESEMPIO Rappresentiamo in un piano cartesiano la sezione di una placca di subduzione. In sezione il piano di Benioff è rappresentato da un segmento della retta g, sulla quale si trovano gli ipocentri I₁ e I₂.

![img-116.jpeg](img-116.jpeg)

Nell'origine O si trova una città. L'asse x rappresenta la superficie terrestre e contiene il punto S in cui inizia la subduzione. Gli epicentri E₁ ed E₂ sono le proiezioni sull'asse x degli ipocentri.

Troviamo a quale distanza dalla città ha inizio la subduzione.

Usiamo la formula per determinare l'equazione della retta passante per due punti:

$$\frac{y + 60}{-78 + 60} = \frac{x - 200}{224 - 200} \rightarrow y = -0,75x + 90. \text{ — retta } I_1 I_2$$

Per y = 0, otteniamo il punto in cui ha inizio la subduzione rispetto alla città O(0; 0):

$$x_5 = \frac{90}{0,75} = 120. \text{ — ascissa di S}$$

Equazione della retta passante per I₁(x₁; y₁) e I₂(x₂; y₂):

$$\frac{y - y_1}{y_2 - y_1} = \frac{x - x_1}{x_2 - x_1}.$$

La zona di subduzione ha inizio a 120 km dalla città.

Il coefficiente angolare di I₁I₂ è m = -0,75. Da questo valore ricaviamo un'informazione in più: il piano di Benioff ha un'inclinazione del 75%, verso il basso rispetto alla superficie terrestre.

# ESERCIZI

RISOLVI CON PYTHON Scrivi un programma per calcolare la profondità di un sisma localizzato sul piano di Benioff dell'esempio precedente, quando è notà la distance del suo epicentro da O. Tieni presente che otre i 700 km di profondità i fenomeni sismici scompaiano.
2 Molti fenomeni di subduzione avengono negli oceani e i terremoti che ne derivano possono causare pericolosi tsunami. Aiutandoti con una ricerca in rete, crea un'infografica sul rischio tsunami. Condense le informazioni più rilevanti in frasi concise e presta attenzione all'aspetto grafico, scegliendo fotografie, disegni e icone che rendano più accattivante la tua infografica e ne incoraggino la lettura. Puoi fare esta attività anche in gruppo (2-3 persone).

ESERCIZI

263