DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

401 REALTÀ E MODELLI Per il progetto di una scala è stato richiesto di disporre 9 gradini per ogni rampa e di attenersi alla legge di Blondel:

![img-83.jpeg](img-83.jpeg)

$$2a + p = 63,$$

dove $a$ e $p$ indicano, rispettivamente, la alzata e la pedata di ogni gradino, espresse in cm.

a. Calcola la pendenza della Scala (il coefficiente angolare della retta obliqua in figura espresso in percentuale).
b. Calcola la distanza tra il vertic superiore del primo gradino e il vertic superiore del nono gradino.

[a) circa 56%; b) circa 272 cm]

Stabilisci se i punti seguenti sono allineati; nel caso in cui lo siano, scrivi l'equazione della retta su cui giacciono.

402 \(A(1; - 1),\qquad B(5; - 7),\qquad C(-1;2).\)
[3x+2y-1=0]
403 \(A\left(\frac{1}{2}, - \frac{3}{2}\right),\qquad B(1; - 1),\qquad C(-1;0).\)
[non allineati]
404 \(A(-9;1)\) \(B(-3;0)\) \(C(3; - 1)\)

405 TEST L'equazione della retta passante per i punti $A(3; 0)$, $B(0; 2)$ e $C\left(\frac{3}{2}; 1\right)$ è:

A $3x + 2y - 6 = 0$.

B $2x + 3y - 6 = 0$.

C $2x - 3y + 6 = 0$.

D $2x - 3y = 0$.

I punti dei seguenti gruppi appartengono tutti a una stessa retta, tranne uno. Scrivi l'equazione della retta e individua il punto che non appartiene alla retta.

406 \(A(-1; - 5),\qquad B(2;10),\qquad C(-3; - 15),\qquad D(-10; - 2).\)
[1]
407 \(A(3;9)\) \(B(-2;6)\) \(C(4;12)\) \(D(1;3)\)

408 SPIEGA PERCHE Rebecca: «Per determinare se tre punti $A$, $B$ e $C$ sono allineati, verifico che la distanza $AC$ sia uguale alla somma di $AB$ e $BC$».

Lorenzo: «Io scriverei l'equazione della retta $AC$ e verificherei se $B$ appartiene a essa».

Matilde: «Io verificherei solamente se i coefficienti angolari delle rette $AB$, $BC$ e $AC$ sono uguali».

Tu cosa faresti? Perché?

409 Dati i punti \(A(-2;1)\) e \(B(3;3)\) ,trova le coordinate di tre punti appartenenti al segmento \(AB\)
410 Scrivi le equazioni dei lati del triangolo \( ABC \) di vertici \( A(-2;1), B(1;0) \in C(3;2) \).

$$\{x + 3y - 1 = 0; x - y - 1 = 0; x - 5y + 7 = 0\}$$

411 Determina le equazioni delle mediane del triangolo $ABC$ di vertici $A(-3; 0)$, $B(1; 2)$ e $C(1; 6)$.

$$\{5x - 2y + 7 = 0; x - y + 3 = 0; x + 2y - 5 = 0\}$$

412 Scrivi le equazioni dei lati del quadrilatero di vertici $A(-3; 1)$, $B(4; 1)$, $C(2; 6)$, $D(-1; 6)$ e verifica che è un trapezio isoscele. $[y = 1; 5x + 2y - 22 = 0; y = 6; 5x - 2y + 17 = 0]$

413 LEGGI IL GRAFICO Utilizzando i dati della figura a lato, scrivi le equazioni dei lati del parallelogramma e quelle delle diagonali.

![img-84.jpeg](img-84.jpeg)

$$[y = -2; 5x - 2y - 29 = 0; y = 3; 5x - 2y + 6 = 0;$$

$$x + y - 3 = 0; 5x - 9y - 8 = 0]$$

414 Scrivi le equazioni dei lati del triangolo equilatero che ha un lato sull'asse $x$ e il centro nel punto $\left(0; \frac{\sqrt{3}}{3}\right)$.

$$[y = 0, y = -\sqrt{3}x + \sqrt{3}, y = \sqrt{3}x + \sqrt{3}]$$

243

ESERCIZIO