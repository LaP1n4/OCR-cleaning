POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

R

# Problemi

EDUCAZIONE FINANZIARIA PROBLEMI DI SCELTA

![img-53.jpeg](img-53.jpeg)

319 LEGGI IL GRAFICO Una palestra aperta tutti i giorni, comprese le domeniche, propone tre tipi di tariffa mensile:

proposta 1: una quota fissa più 1,30 € per agli ingresso;
proposta 2:4,50 € per agli ingresso;
proposta 3: una quota fissa mensile.

Nella figura sono rappresentate le funzioni del costo delle tre proposte.

Associa a ogni proposta la retta che la rappresenta e determina le quote fisse della proposta 1 e della proposta 3. Quale proposta è la più conveniente per una persona che pensa di andare in palestra tre volte a settimana? [proposta 1]

320 A una tecnica specializzata nella riparazione e manutenzione di caldaie da riscaldamento domestico vengono offerte tre alternative di retribuzione.

![img-54.jpeg](img-54.jpeg)

A: stipendio fisso mensile di 1200 €.
B: 65 € per agli caldaia riparata.
C: fisso mensile di \(800\in +25\in\) per agli caldaia riparata.

Quale delle tre alternative risulta più conveniente per la tecnica, al variare del numero di caldaie riparate?

[A per 0 ≤ x < 16; C per 16 < x < 20; B per x > 20]

![img-55.jpeg](img-55.jpeg)

321 Una ditta di trasporti propone a un'azienda agricola le seguenti condizioni di spesa per il trasporto della verdura.

A: 9 € al quintale.
B: 6 € al quintale più una spesa fissa di 300 €.
C: 12 € al quintale fino a 40 quintali e 6,60 € per agli quintale eccedente.

Per quali quantità è più conveniente ciascuna delle condizioni?

[A per 0 < x < 90; C per 90 < x < 140; B per x > 140]

322 Corrado compra online capsule per il caffè servendosi di due aziende, SiCaffè e BuonCaffè, che nei loro siti vendono entrambe confezioni da 10 capsule a 3,60 € a confezione, offrendo sconti differenti in base alla quantità delle confezioni acquistate:

![img-56.jpeg](img-56.jpeg)

SiCaffé offre uno sconto di 0,20 € per agli confezione se si acquistano più di 36 confezioni;
BuonCaffé offre uno sconto se si acquistano più di 48 confezioni e lo sconto è di 0,50 € su agli confezione in più.
a. Quante confezioni di capsule ha acquistato Corrado quello mese se, per convenienza, ha scelto BuonCaffé?
b. Se Corrado ha valutato che era indifferente acquistare da una o dall'altra azienda, quante confezioni di capsule potrebbe aver ordinato? [a] da 37 a 79 confezioni; b) da 0 a 36 o 80 confezioni]

323 Un gruppo fotografico di Torino sta organizzando un'uscita per andare a vedere una mostra a Milano. I soci del gruppo sono 30, ma non si sa quanti parteciperanno.

Il biglietto di ingresso alla mostra costa 20 € a persona per gruppi di 10 o più persone, altrimenti costa 25 €. Inoltre, bisogna valutare quale mezzo di trasporto usare. Le possibilità sono:

treno: \(25\in\) a persona;
noleggio di un pullman: 300 € fissi e 10 € a persona, fino a 30 persone.

Valutando tutte le combinazioni possibili, quale opzione è la più conveniente in base al numero di persone?

[meno di 20 persone: treno; più di 20 persone: pullman; 20 persone: indifferente]

235

ESERCIZI