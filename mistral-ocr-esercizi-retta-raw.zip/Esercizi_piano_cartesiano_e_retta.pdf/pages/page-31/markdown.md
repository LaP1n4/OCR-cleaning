Capitolo 4

PIANO CARTESIANO E RETTA

# LEGGI IL GRAFICO

Esprimi analiticamente le funzioni rappresentate dai seguenti grafici.

415

![img-85.jpeg](img-85.jpeg)

416

![img-86.jpeg](img-86.jpeg)

417

![img-87.jpeg](img-87.jpeg)

Deduci dai grafici:

a. le equazioni di \( f(x) \in g(x) \);
b. per quali valori di \(x\) si ha \(f(x) > g(x)\)

418

![img-88.jpeg](img-88.jpeg)

419

![img-89.jpeg](img-89.jpeg)

420

![img-90.jpeg](img-90.jpeg)

421

Disegna il grafico delle funzioni

$$f(x) = \begin{cases} -\frac{3}{2}x + 2 & \text{se } x < 2 \\ 2x - 5 & \text{se } x \ge 2 \end{cases} \quad \text{e} \quad g(x) = \begin{cases} x + 2 & \text{se } x < 1 \\ 3 & \text{se } x \ge 1 \end{cases}$$

e indica per quali valori di $x$ si ha $f(x) = g(x)$ e $f(x) < g(x)$.

$$[x = 0 \lor x = 4; 0 < x < 4]$$

# Con le relazioni di parallelismo e di perpendicolarità

# I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere le equazioni di una retta parallela e di una retta perpendicolare a una retta data

Data la retta $r$ di equazione $2y + x - 8 = 0$, determiniamo l'equazione della parallela $s$ e della perpendicolare $t$ passanti per $A(1; -1)$.

1 Scriviamo in forma esplicita l'equazione di $r$ e ricaviamo il suo coefficiente angolare.

![img-91.jpeg](img-91.jpeg)

$$y = -\frac{1}{2}x + 4 \rightarrow m = -\frac{1}{2}$$

2 Determiniamo $s$ e $t$ utilizzando la formula $y - y_1 = m(x - x_1)$.

s ha lo stesso coefficiente angolare di $r$.

$$y + 1 = -\frac{1}{2}(x - 1) \rightarrow$$

$$y = -\frac{1}{2}x - \frac{1}{2}$$

t ha coefficiente angolare pari a $-\frac{1}{m}$.

$$y + 1 = 2(x - 1) \rightarrow y = 2x - 3$$

Le condizioni di parallelismo e perpendicolarità danno informazioni sul coefficiente angolare.

Data una retta $r: y = m_1x + q$:

- una retta s parallela a r ha \(m_{1} = m_{1}\)
- una retta t perpendicular a r ha \(m_{t} = -\frac{1}{m_{t}}\)

ESERCITI

244