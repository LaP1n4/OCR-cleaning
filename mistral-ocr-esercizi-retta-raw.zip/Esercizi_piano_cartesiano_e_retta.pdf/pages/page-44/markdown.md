FASCI DI RETTE

Paragrafo 7

![img-111.jpeg](img-111.jpeg)

Scrivi l'equazione completa del fascio proprio di rette passante per ciascun punto indicato e disegna le rette aventi coefficiente angolare $m = 0$, $m = 2$, $m = -3$.

546 $A(2; -3)$

547 $D(7; -3)$

548 $Q\left(-\frac{1}{4}; \frac{3}{4}\right)$

GENERALIZZA CON PYTHON

Scrivi un programma che acquisisca in input le coordinate di un punto $P$, centro di un fascio di rette, e disegni quelle di coefficienti angolari interi da $-3$ a $3$.

549 Scrivi l'equazione del fascio proprio con il centro nel punto di intersezione delle rette \( r \) e \( s \) rispettovamente di equazioni \( x - y - 3 = 0 \) e \( 3x - 5y - 5 = 0 \).
550 Stabilisci se le rette di equazioni \( x - 2y + 6 = 0 \), \( x + 4y - 6 = 0 \) e \( 3x + 2y + 2 = 0 \) appartengono allo stesso fascio; in caso affirmativo, stabilisci il tipo di fascio e scrivi la sua equazione.
551 Scrivi l'equazione del fascio proprio con il centro in \(P(3; - 3)\) e determina l'equazione della retta del fascio:

a. parallela alla retta di equazione \(x - 3y + 5 = 0\)
b. perpendicularare alla retta di equazione \(6x + 3y - 4 = 0\)

c. passante per il punto $Q(-2; 7)$.

[a) $x - 3y - 12 = 0$; b) $x - 2y - 9 = 0$; c) $2x + y - 3 = 0$]

Per ciascuno dei seguenti fasci di rette indica se si tratta di un fascio proprio o improprio e, nel caso di un fascio proprio, determina il suo centro.

552 $2x - 2ky + 1 = 0$

RISOLVI IN 4 PASSI

1 Scrivi l'equazione del fascio in forma esplicita per mettere in evidenza il coefficiente angolare \(m\)
2 Classifica il fascio: se \(m\) non dipende dal parametro \(k\), il fascio è improprio, altrimenti è proprio.
3 Se il fascio è proprio, determina due rette del fascio assegnando valori a piacere al parametro \(k\).
4 Risolvi il systemà formato delle equazioni delle due rette e determina il centro del fascio.

553 $3kx - ky - 6 = 0$

555 $y = 2kx + x + 1$

557 $kx + 2ky - 3 = 0$

554 $2x + y + k - 5 = 0$

556 $y = (2 - k)x + k$

558 $(k - 1)x + 2ky - k = 0$

559 Quali delle seguenti rette appartengono al fascio di equazione $(1 - k)x + y + k = 0$?

a. $y = -1$

b. $3x + y - 2 = 0$

c. $2x + y - 2 = 0$

d. $6x - 2y - 8 = 0$

560 TEST Per quale valore di $k \in \mathbb{R}$ una retta del fascio di equazione $(k - 1)x - (3 - 3k)y + 2k - 3 = 0$ è parallela alla bisettrice del primo e terzo quadrante?

A $k = 1$

B $k = -1$

C $\forall k \in \mathbb{R}$

D $\nexists k \in \mathbb{R}$

561 Dato il fascio di equazione $2x - (2 + 2k)y + k + 1 = 0$, determina per quale valore di $k$ si ha una retta:

a. passante per il punto \((0; - 3)\)
b. parallela alla retta di equazione \(x - y + 1 = 0\)
c. perpendicularare alla retta di equazione \(y = 2x + 5\)

[a) $-1$; b) $0$; c) $-3$]

562 Dato il fascio di equazione $(1 - 2k)x + (3 + k)y + 2 - k = 0$, determina l'equazione della retta del fascio:

a. parallela all'asse $x$;

b. parallela all'asse $y$;

c. passante per l'origine.

[a) $y = -\frac{3}{7}$; b) $x = -\frac{5}{7}$; c) $3x - 5y = 0$]

563 Determina l'equazione della retta appartenente al fascio di equazione $(1 + k)x + (1 + k)y + 3k - 1 = 0$:

a. passante per l'origine;

c. che interseca l'asse delle ascisse per $x = 1$.

b. passante per $(-2; -5)$;

[a) $x + y = 0$; b) $x + y + 7 = 0$; c) $x + y - 1 = 0$]

564 Dato il fascio di equazione $5kx - (k + 4)y - 2 = 0$, determina l'equazione della retta che appartiene al fascio:

a. perpendicularare alla retta di equazione \(3x + 5y - 1 = 0\)
b. parallela alla retta di equazione \(x - y = 0\)

c. passante per il punto $\left(-\frac{1}{5}; 1\right)$.

[a) $5x - 3y - 1 = 0$; b) $5x - 5y - 2 = 0$; c) $15x + y + 2 = 0$]

257

ESERCIZIO