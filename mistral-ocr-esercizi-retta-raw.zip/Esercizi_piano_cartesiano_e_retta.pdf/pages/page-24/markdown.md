POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

332 FAI UN ESEMPIO Per ciascuna delle seguenti rette, scrivi le equazioni di due rette parallele e di due perpendicolari:

a. $3y - 2 = 0$;

b. $3x - 5 = 0$;

c. $2x - 4y + 1 = 0$.

333 Dato il punto $A(4; -6)$, disegna le rette parallele agli assi passanti per $A$ e scrivi le loro equazioni.

334 TEST L'equazione della retta $r$ è $5x + y - 6 = 0$. Il coefficiente angolare di una retta perpendicolare a $r$ è:

A 5.

B -5.

C $\frac{1}{5}$.

D $-\frac{1}{5}$.

335 ASSOCIA a ciascuna retta $t$, nella prima riga, la retta $r$, nella seconda riga, parallela a $t$.

a. $3x - y + 1 = 0$

b. $x - 3y + 6 = 0$

c. $3x + y - 1 = 0$

d. $x = -3y$

1. $6y - 2x = 9$

2. $y + 1 = 3x$

3. $x + 3y - 6 = 0$

4. $y = -3x + 2$

336 ASSOCIA a ciascuna retta $r$, nella prima riga, la retta $s$, nella seconda riga, perpendicolare a $r$.

a. $5x + 2y - 6 = 0$

b. $5x - 2y = 5$

c. $2x + 5y - 3 = 0$

d. $y = 5x - 1$

1. $2x + 5y - 2 = 0$

2. $5y - 2x = 0$

3. $2y = 5x + 3$

4. $5y = 1 - x$

337 COMPLETA

a. La retta di equazione \( x + 2y + 1 = 0 \) è parallela alla retta di equazione \( x + 6y + 5 = 0 \).
b. La retta di equazione \( x = 3 \) è parallela all'asse
c. \(y = -\frac{3}{2} x + 2\) e l'equazione di una retta perpendiculara alla retta di equazione \(x + 9y - 1 = 0\)
d. Le rette di equazioni \(x + 10y + 7 = 0\) e \(3x - 5y - 15 = 0\) sono parallele.

Per ogni retta scrivi l'equazione di una retta parallela a essa e l'equazione di una retta perpendicolare a essa.

338 $y = -\frac{1}{3}x + 5$;

$y = 2x + \frac{1}{4}$;

$y = 2$;

$y = \frac{1}{5}x$.

339 $4x - 2y + 1 = 0$;

$3x + 1 = 0$;

$7x + y + 3 = 0$;

$x = -3$.

# OLTRE I FONDAMENTALI

# Studiare rette parallele e perpendicolari con parametri

Determiniamo per quali valori di $k$ le rette di equazioni $x - ky + 1 = 0$ e $(k - 1)x - 2ky - 5 = 0$ sono parallele e per quali valori di $k$ sono perpendicolari.

1 Scriviamo la condizione di parallelismo più opportuna da applicare.

Individuiamo i coefficienti $a, b, a_1, b_1$ delle rette:

$$\frac{1}{a} \cdot \frac{x - ky}{b} + 1 = 0 \quad \text{e} \quad \frac{(k - 1)x - 2ky - 5}{b_1} - 5 = 0.$$

La condizione di parallelismo da applicare è $ab_1 - a_1b = 0$, perché permette di trovare anche le rette parallele all'asse $y$, che sono invece escluse se consideriamo la condizione $m = m_1$.

Imponiamo che le rette siano parallele con la condizione di parallelismo $ab_1 - a_1b = 0$.

Deve essere:

$$\frac{1}{a} \cdot \frac{(-2k)}{b_1} - \frac{(k - 1)}{a_1} \cdot \frac{(-k)}{b} = 0 \rightarrow -2k + k(k - 1) = 0 \rightarrow k(-2 + k - 1) = 0 \rightarrow k = 0 \lor k = 3.$$

Per $k = 0$ le rette hanno equazioni $x + 1 = 0$ e $x + 5 = 0$.

Per $k = 3$ le rette hanno equazioni $x - 3y + 1 = 0$ e $2x - 6y - 5 = 0$.

Osserviamo che abbiamo ottenuto anche le rette parallele all'asse $y$.

2 Scriviamo e applichiamo la condizione di perpendicolarità.

Le rette sono perpendicolari se $aa_1 + bb_1 = 0$.

$$\frac{1}{a} \cdot \frac{(k - 1)}{a_1} + \frac{(-k)}{b} \cdot \frac{(-2k)}{b_1} = 0 \rightarrow k - 1 + 2k^2 = 0 \rightarrow 2k^3 + k - 1 = 0 \rightarrow k = -1 \lor k = \frac{1}{2}.$$

Per $k = -1$ le rette hanno equazioni $x + y + 1 = 0$ e $-2x + 2y - 5 = 0$.

Per $k = \frac{1}{2}$ le rette hanno equazioni $x - \frac{1}{2}y + 1 = 0$ e $-\frac{1}{2}x - y - 5 = 0$.

ESERCIZI

237