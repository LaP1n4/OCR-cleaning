Capitolo 4 PIANO CARTESIANO E RETTA

ESERCITI

136 TEST Considera il piano cartesiano. Quanti sono i quadrati aventi un vertice in $(-1; -1)$ e tali che uno degli assi coordinati sia asse di simmetria del quadrato stesso?

A 2

B 3

C 4

D 5

E 6

(Kangourou Italia, Categoria Student)

137 Nel grafico, il punto $E$ ha coordinate $(0; 2)$ e $B$ giace sul semiasse $x$ positivo così che $\overline{BE} = \sqrt{7}$. Inoltre, il punto $C$ giace sul semiasse $x$ positivo così che $\overline{BC} = \overline{OB}$. Se il punto $D$ si trova nel primo quadrante in modo che $\overline{CBD} = 30^{\circ}$ e $\overline{BCD} = 90^{\circ}$, qual è la lunghezza di $ED$?

![img-20.jpeg](img-20.jpeg)

(CAN, Canadian Open Mathematics Challenge)

[√13]

138 Considera i punti $A(a + 2; 1)$ e $B(3; b - 1)$, con $a$ e $b$ numeri reali. Calcola $a$ e $b$ in modo che $\overline{AB}$ sia uguale a 1 e che il punto medio $M$ del segmento $AB$ abbia ordinata $\frac{1}{2}$. Trova poi i punti $C$ sull'asse $y$ la cui distanza da $A$ è $3\sqrt{10}$.

![img-21.jpeg](img-21.jpeg)

$$[a = 1, b = 1; C_1(0; 10), C_2(0; -8)]$$

139 LEGGI IL GRAFICO Calcola la misura del perimetro e dell'area del trapezio in figura. Congiungi $A$ e $D$ con il punto medio $M$ del lato $CB$ e verifica che il triangolo $ADM$ è isoscele. $[19 + \sqrt{61}; 39]$

![img-22.jpeg](img-22.jpeg)

140 Verifica che il triangolo di vertici $A(-3; -1)$, $B\left(2; \frac{3}{2}\right)$, $C(-9; 11)$ è rettangolo e che la mediana relativa all'ipotenusa è congruente alla metà dell'ipotenusa stessa.

141 Considera i punti $A(-2a; -1)$ e $B(a - 5; -1)$, con $a > 0$, e trova $a$ in modo che $\overline{AB}$ sia 7. Determina poi il punto $C$ di ascisa 5, in modo che il triangolo $ABC$ abbia area 35.

$$[a = 4; C_1(5; 9), C_2(5; -11)]$$

142 Del rombo $ABCD$ sono noti i vertici $A(1; 0)$, $B(5; 3)$ e il punto di incontro $M(1; 3)$ delle diagonali. Trova le coordinate degli altri vertici $C$ e $D$ e calcola il perimetro del rombo.

$$[C(1; 6), D(-3; 3); 20]$$

143 Determina il baricentro $G$ del triangolo di vertici $A(-1; 3)$, $B(6; 1)$, $C(4; 8)$ e verifica che la mediana $AM$ è divisa da $G$ in due parti, una doppia dell'altra. $[G(3; 4)]$

144 Determina le condizioni sul parametro $h$ affinché il baricentro del triangolo di vertici $P(1 + h; 2)$, $Q(h - 2; 2h)$ e $R(-3; h + 1)$ appartenga al secondo quadrante. $[-1 < h < 2]$

145 LEGGI IL GRAFICO Calcola il perimetro del triangolo che si ottiene congiungendo i punti medi dei lati del triangolo in figura e verifica che è la metà del perimetro del triangolo di partenza.

146 Dato il triangolo $ABC$ di vertici $A(0; 4)$, $B(1; -3)$ e $C(5; 0)$, calcola il perimetro e l'area. Trova poi il baricentro $G$ e il circocentro $P$ del triangolo.

$$\left[5\sqrt{2} + \sqrt{41} + 5; \frac{31}{2}; G\left(2; \frac{1}{3}\right), P\left(\frac{87}{62}; \frac{39}{62}\right)\right]$$

147 Determina le coordinate di un punto $P$ che ha l'ascissa uguale all'ordinata ed è equidistante dai punti $A(2; 0)$ e $B(0; 4)$ e trova il perimetro, l'area e il baricentro del triangolo $APB$.

$$\left[P(3; 3); \sqrt{10}(2 + \sqrt{2}); 5; G\left(\frac{5}{3}; \frac{7}{3}\right)\right]$$

148 I vertici di un triangolo sono $A(3; h + k + 1)$, $B(h - k; 2)$ e $C(h; h + 2k + 1)$. Per quali valori dei parametri $h$ e $k$ il baricentro è $G(1; 4)$? Rappresenta il triangolo ottenuto e, dopo aver verificato che è isoscele, determina il raggio della circonferenza in esso inscritta. (Suggerimento. La misura del raggio della circonferenza inscritta in un triangolo è uguale al rapporto tra le misure dell'area e del semiperimetro.)

$$\left[h = 1, k = 2; \frac{2\sqrt{5} - \sqrt{2}}{3}\right]$$

149 Nel triangolo isoscele $ABC$ i vertici della base sono $A(-2; 1)$ e $B(6; -1)$ e la misura dell'area è $\frac{85}{2}$.

a. Trova il vertice \(C\)
b. Determinina il raggio della circonferenza inscritta nel triangolo.

$$\left[a) C_1\left(\frac{9}{2}; 10\right), C_2\left(-\frac{1}{2}; -10\right); b) \frac{\sqrt{493} - 2\sqrt{17}}{5}\right]$$

222