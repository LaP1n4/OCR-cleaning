RETTE NEL PIANO CARTESIANO

Paragrafo 2

223 $$y = |x - 1| + |x - 2|$$

224 $$y = \sqrt{x^2 - 6x + 9} + |x| + 3$$

225 $$y = |2x + |x - 1| + 2|$$

226 $$y = \begin{cases} |x| - 1 & \text{se } x < 2 \\ -\frac{1}{2}x + 2 & \text{se } x \geq 2 \end{cases}$$

227 $$y = x + 2|x| - |1 - x|$$

228 $$y = \begin{cases} |x + 1| & \text{se } x \leq 0 \\ 2 - \left|\frac{1}{2}x - 1\right| & \text{se } x > 0 \end{cases}$$

Rappresenta graficamente le seguenti funzioni dopo averne determinato il dominio.

229 $$y = \frac{|x^2 + 2x|}{x + 2} - 3$$

RISOLVI IN 4 PASSI

1. Trova il dominio della funzione.

2. Studia il segno dell'argomento del valore assoluto, ponendolo maggiore o uguale a 0.

3. Applicando la definizione di valore assoluto, scrivi la funzione a tratti corrispondente a quella data.

4. Semplifica e rappresenta la funzione ottenuta, tenendo conto del dominio.

230 $$y = \frac{|x + 1|}{x + 1}$$

231 $$y = \frac{|2x|}{x} - 4$$

232 $$y = \frac{\sqrt{x^2}}{x} + |x - 2|$$

233 $$y = \frac{x^2 - 1}{|x - 1|}$$

234 $$y = \frac{x^2 - 2x - 3}{|x - 3|} + x$$

235 $$y = \frac{x^2}{|x|} - \frac{|x^2 - 2x|}{x - 2}$$

236 $$y = \frac{\sqrt{1 - 2x + x^2}}{x - 1} + 2$$

237 $$y = |x + 1| + \frac{|x - 2|}{2 - x}$$

238 $$y = \frac{|x + 1|}{x + 1} + |x - 2| + 2$$

239 $$y = \frac{x^2 - 3x + 2}{x - 1} + 1$$

240 $$y = \frac{x^2 - 7x + 6}{\sqrt{x^2 - 2x + 1}}$$

241 $$y = \frac{x^3 + 2x^2 - x - 2}{|x + 1|(x + 2)}$$

242 $$y = \frac{x^4 - 5x^2 + 4}{x^4 - 2x^2 - x + 2}$$

243 $$y = \frac{2x^3 + 5x + 3}{|x + 1|} - |x|$$

244 $$y = \frac{\sqrt{x^2 - 6x + 9}}{3 - x} + |x - 1| + 2$$

Traccia i grafici che rappresentano le soluzioni delle seguenti equazioni. Si tratta di funzioni?

245 $$|x| - x = 2$$

246 $$y + 2|y| = 3$$

247 $$|x| + |y| = 2$$

248 $$|x + 2| + |y - 2| - 4 = 0$$

249 $$2|x - 1| - 3|y + 2| = 5$$

250 $$|x + 4| - |y - 5| = 9$$

251 $$x = \frac{2y}{|y|} - 1$$

252 $$x = \sqrt{y^2 - 4y + 4} + y$$

253 Data la funzione $$f(x) = a|x - 3| + b$$, trova per quali valori di $$a$$ e $$b$$ il grafico di $$f(x)$$ passa per i punti $$(0; 2)$$ e $$(-2; 4)$$ e rappresentala nel piano cartesiano. $$[a = 1, b = -1]$$

254 Data la funzione $$f(x) = \frac{ax}{|3x|} - x + b$$, trova per quali valori di $$a$$ e $$b$$ il grafico della funzione $$f(x)$$ passa per i punti $$\left(5; -\frac{9}{2}\right)$$ e $$\left(-1; -\frac{5}{2}\right)$$ e rappresentala nel piano cartesiano. $$[a = 6, b = -\frac{3}{2}]$$

# Problemi

255 FISICA MOTO RETTILINEO Selene parte da casa per andare a trovare il suo amico Luca, che vive nella sua stessa via. La funzione che descrive la velocità di Selene (in m/s) al variare del tempo (in s) è:

![img-41.jpeg](img-41.jpeg)

$$v(t) = \begin{cases} 0,02t & \text{se } 0 \leq t \leq 60 \\ 1,2 & \text{se } 60 < t \leq 240 \\ -0,02t + 6 & \text{se } 240 < t \leq 300 \end{cases}$$

a. Qual è la velocità di Selene 30 s dopo la partenza?
b. C'è un'alto istante in cui la velocità di Selene è uguale a quella 30 s dopo la partenza? Se si, quale?
c. Rappresenta la velocità di Selene in un grafico velocità-tempo. [a) \(0,6\mathrm{m / s}\); b) \(4\mathrm{min}30\mathrm{s}\)

ESERCIZI

229