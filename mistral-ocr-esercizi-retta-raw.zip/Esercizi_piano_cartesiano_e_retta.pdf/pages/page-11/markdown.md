Capitolo 4

PIANO CARTESIANO E RETTA

# FAI IL PUNTO SULLE COMPETENZE

# Punti e segmenti nel piano cartesiano

Prima di iniziare,
esercitati su laZ Esercizi

1 Considera i triangoli che hanno come vertici \(A(0;2)\) \(B(2;2)\) e un punto \(C\) che appartiene all'asse \(x\) . Stabilisci quanti sono i triangoli \(ABC\) con perimetro uguali a 8. [2]
LEGGI L GRAFICO ASSOCIA ciascun insieme di punti rappresentato in colore nel piano cartesiano alla condizione sulle coordinate che lo definisce.

![img-23.jpeg](img-23.jpeg)

![img-24.jpeg](img-24.jpeg)

![img-25.jpeg](img-25.jpeg)

![img-26.jpeg](img-26.jpeg)

1. $$\begin{cases} x^2 - 2 \le x \\ y^4 < 1 \end{cases}$$

2. $$\begin{cases} y^4 - y^2 \ge 12 \\ x^3 + x^2 + 3x + 3 \ge 0 \end{cases}$$

3. $$\begin{cases} |x| \le 3 \\ y^2 + 2y > 3 \end{cases}$$

4. $$\begin{cases} x^3 - x^2 - x \ge 2 \\ y^2 + 10 \le 7y \end{cases}$$

3 Considera il triangolo di vertici $$A(-1; 3)$$, $$B(2; 1)$$ e $$C(5; 5)$$.

a. Calcola l'area del triangolo \( ABC \).
b. Determinina le coordinate del punto medio \(M\) del lato \(BC\) e il rapporto fra l'area del triangolo \(ABM\) e l'area del triangolo \(ABC\).

[a) 9; b) $$M\left(\frac{7}{2}; 3\right), \frac{1}{2}$$

4 Dati i punti $$A(0; 2)$$, $$B(4; -1)$$ e $$C(4; 4)$$:

a. determinina il punto medio \(M\) del segmento \(AC\) e il punto \(D\) simmetrico di \(B\) rispetto a \(M\)
b. verifica che il quadrilatero \(ABCD\) è un rombo e calcola la sua area. [a] \(M(2;3),D(0;7)\) b) 20]

5 Un triangolo ha vertici $$A(-1; 1 - 4b)$$, $$B(3a - 1; 2)$$ e $$C(5; -2)$$, dove $$a$$ e $$b$$ sono parametri reali.

a. Determinina i valori di \(a\) e \(b\) in modo che il baricentro sua \(G(b + 1;a - 2)\)
b. Per i valori trovati calcola l'area del triangolo ACG.

[a) $$a = 1, b = 1$$; b) $$\frac{9}{2}$$

6 a. Dati i punti \(A(1;1)\) e \(B(5;7)\) , quanti sono i punti \(C\) , appartenentiagliassi,per cui il triangolo \(ABC\) e isoscele?
b. Determinina quanti sono i punti \(C\) se sappiamo che \(AB\) è la base. [a] 10; b) 2]

7 Per quali valori di $$a$$ il punto $$P(2a - 4; |a + 1|)$$ appartiene al quadrato che ha i lati paralleli agli assi cartesiani, un vertice in $$A(-2; 3)$$ e un altro vertice in $$A'$$ simmetrico di $$A$$ rispetto al punto $$(1; 0)$$? $$[1 \le a \le 2]$$

8 REALTÀ E MODELLI In un allenamento per una gara di dressage Sofia, con la sua cavalla Luna, deve effettuare il percorso in figura fermandosi nei punti indicati. In quei punti, durante la gara, dovrà far compiere a Luna delle «riprese», cioè delle serie di figure e movimenti come piroette o cambi di passo.

![img-27.jpeg](img-27.jpeg)

![img-28.jpeg](img-28.jpeg)

a. Qual è la lunghezza del percorso?
b. Prima di farlo a cavallo, Sofia prova il percorso a piedi, alla fermarsi e a una velocità costante, impiegando 2 minuti. Qual è la velocità tenuta da Sofia?

[a) circa 173 m; b) circa 1,4 m/s]

ESERCIZI

224