Capitolo 4 PIANO CARTESIANO E RETTA

# LEGGI IL GRAFICO

12 Trova le equazioni delle rette a, b, c della figura.

13 Il triangolo ABC della figura è isoscele?

![img-123.jpeg](img-123.jpeg)

![img-124.jpeg](img-124.jpeg)

[si]

Disegna il grafico delle seguenti funzioni.

14 $$y = \begin{cases} 3 & \text{se } x < -1 \\ -3|x| + 6 & \text{se } -1 \le x < 2 \\ 3x - 6 & \text{se } x \ge 2 \end{cases}$$

15 $$y = \sqrt{4 - 4x + x^2}$$

16 $$y = \begin{cases} \left| \frac{1}{2}x + 4 \right| & \text{se } x < 0 \\ x + 2 & \text{se } 0 \le x < 2 \\ 4 & \text{se } x \ge 2 \end{cases}$$

17 $$y = \frac{\sqrt{(x-3)^2}}{3-x} + x$$

18 LEGGI IL GRAFICO Descrivi con un sistema di disequazioni la parte di piano evidenziata nella figura e poi calcolane l'area. Tracciata per C la parallela a DA che interseca il lato AB in E, calcola il rapporto tra le aree di AECD e EBC.

19 a. Rappresenta graficamente la curva di equazione $$\frac{1}{2}|x|-|y|+2=0$$.

b. Nello stesso sistema di riferimento rappresenta anche la curva di equazione

![img-125.jpeg](img-125.jpeg)

$$2|x|-|y|-4=0.$$

c. Calcola l'area della parte di piano racchiusa dai due grafici.
d. Indica come il secondo grafico cui èsso ottenuto a partire dal primo.

[c] 32]

Rappresenta nel piano l'insieme delle soluzioni dei seguenti sistemi di disequazioni.

20 $$\begin{cases} y \le 3 \\ 2y + 2 \ge x \\ \frac{3}{2}x \ge 3 - y \\ x - 4 < 0 \end{cases}$$

21 $$\begin{cases} y \ge |2-x| \\ x > 1 \\ y - 4 \le 0 \end{cases}$$

22 $$\begin{cases} y - x - 1 \ge 0 \\ 2y < x + 4 \\ y \ge -x - 1 \end{cases}$$

23 LEGGI IL GRAFICO Trova quali valori può assumere il coefficiente angolare delle rette per A in modo che attraversino il triangolo colorato. Determina l'equazione della retta parallela all'asse y che divide il triangolo in due parti equivalenti.

![img-126.jpeg](img-126.jpeg)

$$\left[ \frac{1}{6} < m < \frac{2}{3}; x = 6 - 3\sqrt{2} \right]$$

VERIFICA LE COMPETENZE

266