Capitolo 4

PIANO CARTESIANO E RETTA

VERIFICA LE COMPETENZE

33 Del triangolo ABC sono noti i vertici A(1; 1) e B(15; 8) e l'incentro F(3; 7). Determina le coordinate del vertice C. Verifica poi che il triangolo è rettangolo e trova il circocentro D.

$$\left[ C \left( - \frac { 1 7 } { 3 } ; \frac { 4 3 } { 3 } \right) ; D \left( \frac { 1 4 } { 3 } ; \frac { 6 7 } { 6 } \right) \right]$$

34 Sono dati i punti A(2; 3) e B(4; 0). Determina l'equazione del luogo geometrico dei punti P tali che $$\left| \overline { { P A } } ^ { 2 } - \overline { { P B } } ^ { 2 } \right| = 2$$ e calcola il perimetro e l'area del trapezio che il luogo forma con gli assi cartesiani.

$$\left[ 4 x - 6 y - 5 = 0 \lor 4 x - 6 y - 1 = 0 ; \frac { 3 \sqrt { 1 3 } + 1 0 } { 6 } ; \frac { 1 } { 2 } \right]$$

# Costruire e utilizzare modelli

![img-127.jpeg](img-127.jpeg)

35 EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA Serena e Helene cercano il centro sportivo più conveniente per le loro partite a tennis. Stanno valutando tre centri che propongono le seguenti tariffe:

A: \(10\in\) per agli ora di utilizzo del Campo da tennis;
B: \(10\in\) per l'accesso al Campo e \(5\in\) all'ora;
C: \(12\in\) per la prima ora e poi \(5\in\) per agli ora après la prima. Fatta eccezione per i \(12\in\) per la prima ora della tariffa C, tutte le altre tariffe orarie sono frazionabili.

a. Scrivi le espressioni delle tre funzioni del costo al variate del tempo di utilizzo del Campo.
b. Per quale tempo di utilizzo Serena e Helene pagherebbero la stessa cifra al centro A e al centro C?
c. Fra i tre centri sportivi ce n'e uno che non conviene scegliere qualunque sua la durata dell'utilizzo del campo. Quale?

$$\left[ \begin{array} { l l } { \mathrm { a ) } \mathrm { A : } y = 1 0 x , \mathrm { B : } y = 1 0 + 5 x , \mathrm { C : } y = \left\{ \begin{array} { l l } { 1 2 } & { \mathrm { s e } 0 \leq x \leq 1 } \\ { 5 x + 7 } & { \mathrm { s e } x > 1 } \end{array} \right. ; \mathrm { b ) } 1 \mathrm { o r a } \mathrm { e } 2 4 \mathrm { m i n } ; \mathrm { c ) } \mathrm { B } } \end{array} \right]$$

36 FISICA MOTO NEL PIANO Una barca salpa dal molo P, rappresentato in figura, con una velocità v di 20 km/h, in direzione est. Un vento diretto verso nord, con velocità costante w di 30 km/h, devia la traiettoria della barca. Determina le coordinate del punto Q in cui si troverà la barca dopo 30 minuti.

![img-128.jpeg](img-128.jpeg)

![img-129.jpeg](img-129.jpeg)

$$\left[ x _ { Q } = 1 3 \mathrm { k m } ; y _ { Q } = 1 9 \mathrm { k m } \right]$$

37 FISICA MOTO NEL PIANO Durante un allenamento si chiede ai giocatori di correre a zigzag da A a O seguendo il percorso indicato in figura, con i tratti rettilinei a due a due paralleli, e poi di tornare in A lungo la linea di bordo campo.

Se i giocatori tengono una velocità media di 12,5 km/h, quanto tempo impiegano per completare il percorso due volte?

[5 minuti e 10 secondi]

# Accetti la sfida?

Altri esercizi simili su la2 Tutor di matematica

38 Al variare del parametro reale k, in quanti punti la retta di equazione

$$( 2 + k ) x + ( 3 + k ) y - 3 k - 6 = 0$$

interseca i lati del quadrilatero concavo di estremi A(2; 3), B(2; 0), C(1; 2) e D(0; 2)?

$$\left[ 1 \text { p u n t o : } k = - 2 \lor k = - \frac { 7 } { 2 } ; 2 \text { p u n t i : } k < - \frac { 7 } { 2 } \lor - 2 < k < 0 ; 3 \text { p u n t i : } k = 0 ; 4 \text { p u n t i : } k > 0 \right]$$

268