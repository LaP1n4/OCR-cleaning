Capitolo 4

PIANO CARTESIANO E RETTA

Studia i seguenti fasci di rette individuandone le generatrici e, se si tratta di un fascio proprio, determina il centro e il senso di rotazione delle rette del fascio al crescere di k.

573 $kx - (k - 2)y + 4k - 6 = 0$

577 $(2k + 2)x - (k + 1)y - k = 0$

574 $(2k - 1)x - ky - 8k + 2 = 0$

578 $4kx + 2(1 - k)y + 5k - 1 = 0$

575 $(3 - k)x + (k + 1)y + 4k - 8 = 0$

579 $kx + 3ky + 1 - k = 0$

576 $ky + 2 = (k - 1)x$

580 $y = 2kx + 4k - 1 + ky$

581 Dato il fascio di rette di equazione $(k + 1)x + 2(k + 1)y - 2 = 0$:

a. stabilisci se si tratta di un fascio proprio o improprio, individuando l'eventuale centro;
b. determinina la retta del fascio passante per \(A(1;0)\)
c. determinina la retta che, incontrando l'asse \(x\), forma con l'origine un segmento lungo \(\frac{1}{3}\).

[a) fascio improprio; b) $x + 2y - 1 = 0$; c) due soluzioni: $k = -7, k = 5$]

582 Dato il fascio di rette di equazione $(k - 3)x + (2k + 2)y + 1 - 3k = 0$, determina:

a. le equazioni delle generatrici e il centro;
b. le rette del fascio che incontrano l'asse \(x\) in un punto \(A\) tale che \(\overline{AO} = 3\)
c. il valore di \(k\) corrispondente alla retta parallela all'asse \(x\).

[a) $-3x + 2y + 1 = 0, x + 2y - 3 = 0, C(1; 1)$; b) $x - 4y + 3 = 0, x + 2y - 3 = 0$; c) $k = 3$]

583 Dimostra che le equazioni $(x - y + 6) + k(x + y + 4) = 0$ e $(2x - y + 11) + h(x + 5) = 0$ rappresentano (a meno delle rette escluse) lo stesso fascio. Quali sono, nei due casi, le equazioni delle rette escluse? Sia $r_k$ la retta che si ottiene per un generico valore di $k$ con la prima equazione. Calcola, in funzione di $k$, il valore da assegnare a $h$ nella seconda equazione per ottenere la stessa retta.

$$\left[ x + y + 4 = 0, x + 5 = 0; h = \frac{3k - 1}{1 - k} \right]$$

584 Scrivi l'equazione della retta appartenente al fascio proprio di rette di centro (1; 1) che forma con le rette $x + y + 1 = 0$ e $x = 2$ un triangolo di area 2. $[y = -2x + 3; y = -10x + 11]$

585 Determina la retta comune ai due fasci di equazioni $y = mx - 2m + 1$ e $(2 - k)x - (k + 1)y - 3 = 0$, e indica i relativi valori di $m$ e $k$. $[y = 2x - 3, m = 2, k = 0]$

586 Considera il triangolo individuato dai centri $A, B, C$ dei tre fasci di rette di equazioni:

$$y = m(x - 1), \quad kx - y + 3k - 1 = 0, \quad y = hx - 4h - 3.$$

a. Determinina l'area di \( ABC \).
b. Trova per quali valori di \( m \) le rette del primo fascio intersecano il triangolo.
c. Determinina il valore di \( m \) corrispondente alla retta del primo fascio che passa per il baricentro di \( ABC \).

[a) $\frac{15}{2}$; b) $m \le -1 \lor m \ge \frac{1}{4}$; c) $4$]

587 Scrivi l'equazione del fascio generato dalle rette di equazioni $2x + y - 1 = 0$ e $4x + 2y + 3 = 0$ e trova:

a. l'equazione della retta che passa per il punto \(P(2;0)\)
b. le equazioni delle rette che incontrano gli assi in due punti \(A\) e \(B\) tali che l'area del triangolo AOB sua 1;
c. l'equazione della retta perpendicularare alla retta di equazione \(x - 3y - 1 = 0\)

[a) $2x + y - 4 = 0$; b) $2x + y - 2 = 0, 2x + y + 2 = 0$; c) non esiste]

588 Studia il fascio di rette di equazione $(k + 1)x + (2 - 3k)y - 7 + 3k = 0$ e determina:

a. le rette paralleleagli assicartesiani;
b. la retta del fascio parallela alla retta di equazione \(y = x - 3\)
c. la retta passante per il punto \(A(4;1)\)
d. le rette che hanno distanza dall'origine uguate a \(\frac{4}{5}\sqrt{5}\)

[a) $y = 2; x = 3$; b) $x - y - 1 = 0$; c) $x + y - 5 = 0$; d) $2x - y - 4 = 0, 2x - 29y + 52 = 0$]

ESERCIT

260