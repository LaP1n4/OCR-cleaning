Capitolo 4

PIANO CARTESIANO E RETTA

# ESERCIZI

12 Attività interattive,
9 Prova tu

10 Codici Python

# 1 Punti e segmenti

# Punti nel piano cartesiano

Teoria a pagina 193

1 attività interattiva

1 LEGGI IL GRAFICO Scrivi le coordinate dei punti indicati in figura.

![img-0.jpeg](img-0.jpeg)

2 LEGGI IL GRAFICO Per ogni figura scrivi quali punti hanno ordinata positiva e quali hanno ascissa negativa.

![img-1.jpeg](img-1.jpeg)

3 Rappresenta nel piano cartesiano i seguenti punti:

$$A(-2; 5); \quad B(-4; -1); \quad C(3; 0);$$

$$D(2; -5); \quad E\left(-\frac{5}{2}; 2\right).$$

4 Senza rappresentarli nel piano cartesiano indica a quale quadrante appartengono i seguenti punti:

$$A\left(-\frac{1}{2}; 2\right); \quad B(4; -5); \quad C(1 - \sqrt{2}; 1);$$

$$D(-6; -2).$$

5 VERO O FALSO?

a. I punti che si trovano sull'asse delle ordinate hanno coordinate \((a;0)\)
b. \(A(-1; - 3)\) si trovava nel terzo quadrante.
c. I punti che appartengono al quarto quadrante hanno coordinate opposte.
d. Tutti i punti di ascissa 0 si trovano sull'asse delle ordinate.

V F

V F

V F

V F

6 Disegna il quadrilatero di vertici:

$$A(5; -1), B(3; 3), C(-2; 4), D(-1; -4).$$

Rispondi alle seguenti domande.

a. Quale vertic ha I'ordinata maggiore?
b. Quale vertic ha l'ascissa minore?
c. Quali vertici hanno ascissa negativa?

7 Indica in quale quadrante si trova un punto se:

a. l'ascissa è negativa e l'ordinata positiva;
b. le sue coordinate sono entrambé positive;
c. le sue coordinate sono tali che \(xy > 0\)
d. le sue coordinate sono entrambé nulle;
e. I'ascissa e uguall'ordinata.

8 Per quale valore di $a$ il punto $P(-3a - 1; 6a + 6)$

appartiene all'asse $y$? E all'asse $x$?

$$\left[ -\frac{1}{3}; -1 \right]$$

9 YOU & MATHS The point $(a, b)$ is reflected over the $y$-axis to the point $(c, d)$, which is then reflected over the $x$-axis to the point $(e, f)$. Compute the value of $ab - ef$.

A $2ab$

C $-1$

E $1$

B $ab + b^2$

D $0$

(USA, Wolsborn-Drazovich Memorial Math Contest)

10 Dato il punto $P(3a; a + 2)$, determina per quali valori di $a$ il punto appartiene al secondo quadrante. $[-2 < a < 0]$

# RISOLVI IN 2 PASSI

1 Un punto \(P(x_{P};y_{P})\) appartiene al secondo quadrante se \(x_{P} <   0\mathrm{e}y_{P} > 0\)
2 Poni le due condizioni a sistema e risolvilo.

11 Trova per quali valori di $k$ $A(2 - k; 2k - 1)$ appartiene al primo quadrante.

$$\left[ \frac{1}{2} < k < 2 \right]$$

ESERCIZI

214