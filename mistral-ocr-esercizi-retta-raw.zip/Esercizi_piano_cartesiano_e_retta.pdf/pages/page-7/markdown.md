Capitolo 4

PIANO CARTESIANO E RETTA

ESERCIZI

105 I punti $A(3; 6)$, $B(-3; 3)$ e $C(-2; 2)$ sono vertici consecutivi del parallelogramma $ABCD$. Calcola le coordinate del quarto vertice $D$. [D(4; 5)]

# RISOLVI IN 2 PASSI

3 Trova il punto medio \(M\) della diagonale \(AC\)
2 Poiché \(M\) èanche punto medio della diagonale \(BD\) ,usa la formula del punto medio per trovare \(D\)

106 Del parallelogramma \(ABCD\) sono noti i vertici consecutivi \(A(1;5),B(-4; - 7),C(2;1)\) .Calcola le coordinate del vertice \(D\) e il perimetro. (7; 13; 46)
107 Un parallelogramma \(ABCD\) ha due vertici consecutivi in \(A(1;2)\in B(7; - 1)\) e il punto di intersezione delle dia-gonali e \(P(4;3)\) . Determinina \(C\in D\) , il perimetro e l'area del parallelogramma. \(\left[C(7;4),D(1;7);10 + 6\sqrt{5};30\right]\)
108 Dato il segmento di estremi \(A(-1;1)\) e \(B(4; - 2)\) ,trova il segmento simmetrico \(A^{\prime}B^{\prime}\) rispetto al punto \(P(1;2)\) e determina sull'asse \(x\) un punto \(C\) in modo che il triangolo \(A^{\prime}B^{\prime}C\) sa isoscele sulla base \(A^{\prime}B^{\prime}\)

$$\left[ A'(3; 3), B'(-2; 6); C\left(-\frac{11}{5}; 0\right) \right]$$

109 Individua il vertice $C$ di un triangolo isoscele di base $AB$ con $A(-1; 1)$ e $B(2; 0)$, sapendo che l'altezza relativa ad $AB$ misura $\frac{\sqrt{10}}{2}$. [C$_1$(1; 2), C$_2$(0; -1)]

# Baricentro di un triangolo

Teoria a pagina 195

1 attività interattiva

Calcola le coordinate del baricentro dei triangoli che hanno i seguenti vertici.

110 \(A(-1;0)\) ， \(B(5;1)\) ， \(C(2;2)\)
11 \(A(-1;3)\) ， \(B(2; - 2)\) ， \(C(-5; - 1)\)
112 \(A(-3;7)\) ， \(B(0;1)\) ， \(C(6;6)\)
113 \(A(2;4)\) ， \(B(-1; - 5)\) ， \(C(5; - 2)\)
114 \(A(-3;0)\) ， \(B\left(\frac{1}{2}; - 3\right)\) ， \(C\left(\frac{5}{2};3\right)\)

$$x_G = \frac{x_A + x_B + x_C}{3} \quad y_G = \frac{y_A + y_B + y_C}{3}$$

115 \(A(1;0)\) ， \(B\left(\frac{2}{3}; - 7\right)\) ， \(C\left(-\frac{5}{3}; - 1\right)\)
116 \(A\left(\frac{\sqrt{2}}{2};0\right)\) \(B(3\sqrt{2};1)\) \(C\left(\frac{1}{\sqrt{2}};2\right)\)

117 Un triangolo \( ABC \) con \( A(-3;2) \in B(4;1) \) ha baricentro \( G(1;3) \). Calcola le coordinate di \( C \). [(2;6)]
118 Determinina le coordinate del terzo vertic di un triangolo, sapendo che due vertici sono \(A(3;8)\) e \(B(-1;2)\) e il baricentro e \(G(2;3)\). [C(4; -1)]
Nel triangolo \(ABC\) , con \(A(0;5)\) \(B(1;1)\in C\) sull'asse \(x\) , il baricentro \(G\) ha ascisa 3.Determina le coordinate di \(C\in G\) [C(8;0),G(3;2)]
120 Trova il valore di \(k\) per cui il triangolo di vertici \(A(2k;3 - k)\) \(B(k - 5; - k)\in C(4 - k; - 7)\) ha il baricentro di ascisa 1. [2]
E dato il triangolo \( ABC \) di vertici \( A(k - 1;3) \), \( B(2k;h - 2) \in C(4; - 2h) \). Trova \( k \in h \) in modo che il baricentro del triangolo sa l'origine degli assisi. \( [k = -1, h = 1] \)
Il triangolo \( ABC \) ha come vertici \( A(4a + 1;2) \), \( B(3 - a; a^2 - 6) \in C(5;0) \). Per quali valori di \( a \) il baricentro del triangolo appariene al secondo quadrante? \( [a < -3] \)

123 Determinina per quale valore di \(a\) il triangolo di vertici \(A(3;a + 2)\) \(B(-2a;1)\in C(1;a - 4)\) ha il baricentro \(G\) sull'asse \(y\) e calcola la distanza di \(G\) dai tre vertici. \([a = 2;3\sqrt{2},4,\sqrt{10} ]\)
FISICA EQUILIBRIO DEI SOLIDI In figura è rap-presentata una lamina metallica nelle viene appesa a una parete. Determinina le coordinate del suo baricentro. La lamina è in equilibrio? Perché? [(4; 2)]

![img-18.jpeg](img-18.jpeg)

220