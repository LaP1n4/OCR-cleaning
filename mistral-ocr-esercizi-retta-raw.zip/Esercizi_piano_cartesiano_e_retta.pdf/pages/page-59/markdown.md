Capitolo 4 PIANO CARTESIANO E RETTA

VERCO LEGALE

40 In un triangolo ABC il vertice B ha coordinate (6; -1), la mediana CM e l'altezza CD hanno equazione rispettivamente y + 8x = 16 e y = 4x + 4. Determina:

a. le coordinate di \(A\in C\)
b. lortocentro \(H\) e il baricentro \(G\) del triangolo;
c. l'area del triangolo;
d. l'equazione della retta parallela al lato \(AB\) che, intersecando i due lati \(AC\) e \(CB\), individua con il vertice \(C\) un triangolo che ha area uguali a \(\frac{1}{4}\) di quella di \(ABC\).

[a) A(-2; 1), C(1; 8); b) H(-17/31; 56/31), G(5/3; 8/3); c) 31; d) 8y + 2x = 35]

41 Studia il fascio di rette di equazione

3kx - (1 + 2k)y - 6 = 0

al variare di k in R.

a. Determina, tra le rette del fascio, quale che incontrando gli assi cartesiani forma il triangolo OAB che ha incentro nel punto \((1; - 1)\) e quale che forma il triangolo OCD che ha baricentro in \(\left(-\frac{8}{3}; - 4\right)\).
b. Calcola il rapporto tra le aree dei triangoli OAB e OCD.
c. Indica per quali valori di \(k\) le rette del fascio intersecano il segmento di estremi \((-8;0)\) e \((4;0)\).

[fascio di centro (-4; -6), generatrici 2y - 3x = 0 e y + 6 = 0; a) 3x - 4y - 12 = 0; 3x + 2y + 24 = 0;

b) 1/8; c) k ≤ -1/4 ∨ k ≥ 1/2]

42 Rappresenta graficamente la funzione

y = √(x² - 4x + 4) + |x + 1|.

a. Determina le coordinate dei punti del grafico \(A, B\) e \(C\) le cui ascisse \((x_{A} < x_{B} < x_{C})\) sono soluzioni dell'equazione \(x^{3} + 2x^{2} - 5x - 6 = 0\).
b. Individua il punto \(D\) in modo tale che il quadrilatero \(ABCD\) sua un trapezio isoscele e calculane l'area.
c. Verifica che congiungendo i punti medi dei lati del trapezio si ottiene un rombo che ha l'area uguali alla meta di quella del trapezio.

[a) A(-3; 7), B(-1; 3), C(2; 3); b) D(4; 7); 20]

43 Date le rette di equazioni

2x + 2ay + 1 - a = 0 e (a + 1)x - ay + 1 = 0:

a. discuti al variate di \(a\) le posizioni reciproche delle due rette;
b. determinai centri \(C_1\in C_2\) dei fasci individuati da ciascuna equazione;
c. considera il punto \(P\) di ascisa 3 sull'asse del segmento \(C_1C_2\) e determina per quali valori di a si ottengo no le rette \(C_1P\) e \(C_2P\);
d. determinina il baricentro \(G\) e lortocentro \(H\) del triangolo \(C_1C_2P\).

[a) a = 0 ∨ a = -2: rette parallele, a ≠ 0 ∧ a ≠ -2: rette incidenti; b) C₁(-1/2; 1/2), C₂(-1; -1);

c) a₁ = 7/4, a₂ = -8/9; d) G(1/2; -2/3), H(-3/5; -3/10)]

![img-135.jpeg](img-135.jpeg)

44 LEGGI IL GRAFICO

a. Utilizzando i dati della figura scrivi le equazioni delle rette \( r, s \), \( a, b \) e determina le aree dei due triangoli colorati.
b. Verifica se i baricentri dei due triangoli sono allineati con \(C\)
c. Nel fascio generato dalle rette \(r\) e \(s\) trova per quale valore di \(k\) le rette del fascio intersecano entrambi i triangoli.

[a) r: y = 1/2 x - 2; s: y = -2x + 2; a: x = -3/2; b: x = 3; 961/80; 49/20;

c) k ≥ 0]

272