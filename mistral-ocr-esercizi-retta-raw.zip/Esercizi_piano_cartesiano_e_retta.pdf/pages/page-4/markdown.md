PUNTI E SEGMENTI

Paragrafo 1

46 Calcola il perimetro del quadrilatero i cui vertici sono \(A(-5;6),B(0;6),C(2;2),D(-3; - 3).\) \([5 + 5\sqrt{2} +2\sqrt{5} +\sqrt{85}]\)
47 Stabilisci se il triangolo \( ABC \) di vertici \( A(-5;6) \), \( B(-1;4) \), \( C(4; - 1) \) è isoscele. [no]
48 Verifica che il triangolo con i vertici nei punti \(A(-3;0),B(5;0)\in C(1;4\sqrt{3})\) è equilatero.
Un triangolo ha vertici \(A(-3;2)\in B(5;2)\) e area \(S = 16\) . Determina le coordinate del terzo vertice \(C\) , sapendo che appartiene al semiasse delle ordinate positive. \([C(0;6)]\)
50 Verifica che il quadrilatero con i vertici \(A(2;1)\) \(B(8;2),C(11;7),D(5;6)\) è un parallelogramma. (Suggerimento. Verifica che i lati opposti sono congruenti.)
Stabilisci se il triangolo \( ABC \) di vertici \( A(1; -2) \), \( B(-1; 2) \), \( C(-1; -3) \) è un triangolo rettangolo. (Suggerimento. Verifica se le misure dei lati soddisfano il teorema di Pitagora.)
52 Determinina il punto \(P\) sull'asse \(x\) equidistante da \(A(-5;5)\) e da \(B(0;2)\). \(\left[P\left(-\frac{23}{5};0\right)\right]\)
53 Individua il punto \(P\) che ha ordinata uguate all'asciissa ed è equidistante da \(A(-2;1)\) e \(B(5; - 4)\) \([P(9;9)]\)
54 Verifica che il triangolo di vertici \(A(2;2),B\left(6,\frac{3}{2}\right)\) \(C(4;5)\) è isoscele e calcola la misura del suo perimetro. \(\left[\sqrt{13}(1 + \sqrt{5})\right]\)
55 Trova per quali valori di \(k\) il punto \(P(k + 2; k + 1)\) è equidistante da \(A(-2;1)\) e \(B(4; -2)\). \(\left[-\frac{1}{2}\right]\)
RISOLVI CON PYTHON
Scriv un programma che risolva l'esercizio, using solve) della libreria SymPy.
56 Determinina per quali valori di a la distanza tra i punti \(A(2a + 3;2)\in B(1;2a)\) e uguate a 4. \(\pm 1]\)
57 Calcola per quali valori di \(k\) il segmento con estremi i punti \(P(2;1 + k)\in Q\left(\frac{k}{2};0\right)\) misura 5. \(\pm 4]\)
58 Dati i punti \(A(2k; - 1),B(-2; - k + 3),C(4;3)\) trova \(k\) in modo che risulti \(\overline{AB} = \overline{CO}\) ,essendo O l'origine degli assi cartesiani. \(\pm 1]\)
59 Trova il punto \(P(a; b)\) equidistante dai punti \(A(-4; 0), B(0; 3) \in C(1; 0)\). \(\left[P\left(-\frac{3}{2}, \frac{5}{6}\right)\right]\)
60 Determinina il circocentro del triangolo \( ABC \) con \( A(7;1),B(2;7),C(-2; - 2) \). (Suggerimento. Ricorda che il circocentro di un triangolo è il centro della circonferenza circoscritta ed è quindi equidistante dai tre vertici del triangolo.)

61 Dati i punti \(A(3;7),B(9; - 1)\in C(1;k)\) ,trova \(k\) in modo che il triangolo \(ABC\) sua rettangolo in C. [3]
62 Verifica che il quadrilatero AOBC di vertici \(A(-1; - 1),O(0;0),B(-2;2),C(-3;1)\) è un rettangolo. (Suggerimento. Verifica che i lati opposti sono congruenti e che le diagonali sono congruenti.)
Stabilisci se il quadrilatero di vertici consecutivi \(I(0;2),L(3; - 3),M(8;0),N(5;4)\) è un rettangolo.
64 LEGGI IL GRAFICO Verifica che il quadrilatero in figura è un rombo.

![img-13.jpeg](img-13.jpeg)

65 Dati i punti $A(-2;3)$, $B(1;-1)$ e $P(a-2;-3a)$, trova per quali valori di $a$ si ha:

$$\overline{PA}^2 + \overline{PB}^2 = 33. \quad \left[a = -1; a = \frac{7}{10}\right]$$

66 Determinina un punto \(P\) sull'asse \(x\) che abbia distanza da \(A(1;2)\) doppia della sua distanza da \(B(0;1)\). \(\left[(-1;0)\mathrm{o}\left(\frac{1}{3};0\right)\right]\)
67 Trova un punto \(P\) sull'asse \(y\) equidistante da \(A\left(-\frac{3}{2};1\right)\) e da \(B(2; - 1)\) . \(\left[\left(0; - \frac{7}{16}\right)\right]\)
68 Calcola le coordinate di un punto \(P\) , che ha ordinata positiva e tripla rispetto all'ascissa, in modo che \(\overline{PA} = 5\) , con \(A(-1;2)\) [(2;6)]
FISICA MOTO NEL PIANO Due corpi, \(A\in B\) ,si muovono su due strade rettilinee perpendicolari e al tempo \(t = 0\) si trovano entrambi in O. Il corpo A viaggia con moto uniformamente accelerato, con accelerazione \(a = 0,4\mathrm{m / s^2}\) e velocità \(\nu_{\mathrm{b}} = 4\mathrm{m / s}\) in O,mente B si muove con moto uniforme, con velocità \(\nu = 12\mathrm{m / s}\) Qual è la loro distanza dopo 1 minuto? [1,2 km]

![img-14.jpeg](img-14.jpeg)

![img-15.jpeg](img-15.jpeg)

217

ESERCIZI