Capitolo 4

PIANO CARTESIANO E RETTA

VENTO LEGALE

50

a. Trova per quale valore di \( k \) la retta di equazione \( y + x - 4 + k(y - x) = 0 \) interseca in \( A \) l'asse \( x \in B \) l'asse \( y \) in modo che l'ascissa di \( A \) sa negativa e che l'area del triangolo \( AOB \) sa 1.
b. Determinina le coordinate dell'incentro \(Q\) del triangolo AOB.
c. Trova le coordinate del circocentro \(H\) di AOB.
d. Calcola l'area del quadrilatero OAQH.

$$\left[ a) k = 3; b) Q \left( \frac{\sqrt{5} - 3}{2}; \frac{3 - \sqrt{5}}{2} \right); c) H \left( -1; \frac{1}{2} \right); d) \frac{7 - \sqrt{5}}{8} \right]$$

51

Considera i punti $A(5; 1)$ e $B(1; 2)$. Le rette $r, s$ e $t$ passano per il punto $A$, inoltre:

la retta r e parallela all'asse x;
la retta s e perpendicularare all'asse x;
la retta t ha pendenza (coefficiente angolare) 1.

a. Determinina le equazioni delle tre rette.
b. Considera una retta \( f \) di equazione \( y = kx + d \), con \( k, d \in \mathbb{R} \), che forma con l'asse \( x \) un angolo \( \alpha \). Sapendo che la retta \( f \) passa per il punto \( B \), determina per quale valore di \( \alpha \in ]0^{\circ}; 90^{\circ} \) le rette \( f \in r \) non si intersecano.
c. La retta \(g\) passa per il punto \(B\) e ha la stessa inclinazione della retta \(t\). Trova il punto di intersezione della retta \(s\) con la retta \(g\).

(Austria, tratto da Haupttermin, AHS, maggio 2019, prova 6 di compensazione, esercizio 1)

$$\left[ a) y = 1, x = 5, y = x - 4; b) \not\exists \alpha; c) (5; 6) \right]$$

52

Le rette $r: x - 2y + 4 = 0$ e $s: x + y - 5 = 0$ si intersecano nel punto $A$, mentre $B$ è il punto in cui $r$ interseca l'asse delle ordinate. Considera una generica retta $t$ del fascio proprio di centro $B$ e l'eventuale punto di intersezione $C$ tra la retta $t$ e la retta $s$.

a. Trova la retta \(t\) del fascio in modo che il baricentro del triangolo ABC abbia ascissa 1.
b. Trova le rette \(t_x\) e \(t_y\) del fascio tali che il circocentro del triangolo ABC appartenga o all'asse \(x\) o all'asse \(y\).
c. Indicati con \(G\) il baricentro del triangolo ABC determinato al punto a e con \(O_1\) e \(O_2\) i circocentri dei triangoli ABC determinati al punto b, calcola l'area del triangolo \(GO_1O_2\).

$$\left[ a) t: y = 2x + 2; b) t_x: y = -\frac{3}{7}x + 2, t_y: y = -3x + 2; c) \frac{9}{16} \right]$$

# Problemi di matematica e realtà

![img-138.jpeg](img-138.jpeg)

53

EDUCAZIONE FINANZIARIA PROBLEMA DI SCELTA Per trasportare un certo tipo di merce tra due luoghi fissati ci sono tre possibili alternative:

su rotaia con una spesa fissa di \(200\in\) una spesa variable di \(400\in\) per tonnellata trasportata;
su gomma con mezzi speciali forniti da un'impresa di trasporto, che preveDE una spesa fissa di \(400\in\) e una spesa variabile di \(360\in\) per tonnellata trasportata;
via mare con una spesa fissa di \(480\in\) e una spesa variable di \(320\in\) per tonnellata trasportata.

Il costo a tonnellata è frazionabile in tutte le tre alternative.

Determina l'alternativa più conveniente in base alla quantità $x$, in tonnellate, di merce da trasportare.

[$x < 3,5$ rotaia, $x = 3,5$ rotaia o mare, $x > 3,5$ mare]

![img-139.jpeg](img-139.jpeg)

54

Un'azienda può produrre croissant utilizzando tre linee di produzione, con caratteristiche differenti. La linea A necessita di 14 minuti per l'avviamento e produce 5 centinaia di croissant al minuto; la linea B richiede 10 minuti per avviarsi e prepara 4 centinaia di croissant al minuto; la linea C impiega 12 minuti per avviarsi e confeziona 3 centinaia di croissant al minuto. Quale linea consente di impiegare meno tempo, in funzione del numero di croissant da produrre?

[meno di 8000: B; più di 8000: A]

274