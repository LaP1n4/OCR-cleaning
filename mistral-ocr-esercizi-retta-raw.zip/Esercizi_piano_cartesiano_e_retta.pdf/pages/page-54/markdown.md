COMPETENZE ALLA PROVA

# Risolvere problemi

24

a. Verifica che il triangolo di vertici \(A(5;4)\) \(B(-1;6)\in C(7; - 2)\) e isoscele sulla base \(BC\)
b. Dimostra che le equazioni dell'altezza e della mediana relative a \(BC\) coincidono.
c. Trova il baricentro, l'ortocentro e il circocentro del triangolo.

$$\left[ c \left( \frac{11}{3}; \frac{8}{3} \right), (11; 10), (0; -1) \right]$$

25

Determina i vertici del quadrato PQRS che ha come diagonale il segmento di estremi $P(1; -3)$ e $R(-5; 1)$.

$$[Q(0; 2); S(-4; -4)]$$

26

a. Scrivi l'equazione della retta \( r \) passante per i punti \( A(4;0) \in B(0;6) \) e l'equazione della retta \( s \), parallela alla bisettrice del primo e terzo quadrante, passante per \( C(-1;0) \).
b. Nel fascio di rette generato da \( r \) e \( s \) determina la retta di coefficiente angolare \( -\frac{7}{8} \) e trova su diessa il punto \( D \) di ordinata \( -4 \). Calcola l'area del quadrilatero ABCD.
c. Verifica che il triangolo \(ABD\) è isoscele e determina il circocentro \(E\).

$$[a) \ r: 2y + 3x - 12 = 0, \ x: x - y + 1 = 0; \ b) \ 7x + 8y - 38 = 0, \ D(10; -4); \ 25; \ c) \ E(17; 13)]$$

27

a. Studia il fascio di rette di equazione \((k - 1)x + (1 - k)y + 2 - k = 0\),indicando la retta \(r\) del fascio che non viene rappresentata da nessun valore del parametro \(k\)
b. Individua le coordinate dei vertici \(C_1\) e \(C_2\) dei due triangoli isosceli, di area 24, aventi base \(AB\) con \(A\) e \(B\) appartenenti alla retta \(r\) e con l'ascissa che è soluzione dell'equazione \(x^2 - 2x - 3 = 0\).
c. Calcola l'area del quadrilatero \(AC_{1}BC_{2}\)

[a) fascio di rette parallele alla bisettrice del primo e terzo quadrante;

$$x - y - 1 = 0; \ b) \ C_1(-5; 6), \ C_2(7; -6); \ c) \ 48]$$

28

L'equazione di una retta che non passa per l'origine e non è parallela agli assi può sempre essere scritta nella forma $\frac{x}{p} + \frac{y}{q} = 1$, detta equazione segmentaria della retta.

a. Spiega il significato dei coefficienti \( p \) e \( q \) dell'equazione e indica la loro relazione con i coefficienti \( a, b \) e \( c \) dell'equazione della retta in forma implicita \( ax + by + c = 0 \).
b. Scrivi l'equazione segmentaria della retta di equazione \(2x - 3y + 6 = 0\)

$$\left[ b \right] - \frac{x}{3} + \frac{y}{2} = 1]$$

29

a. Studia il fascio di rette di equazione \((2k + 1)x + (k - 1)y + 8k + 7 = 0\) e individua la retta \(r\) del fascio che non viene rappresentata da alcun valore del parametro reale \(k\).
b. Determinina la retta s del fascio parallela alla retta di equazione \(5x + y = 0\)
c. Trova le rette \(t_1\) e \(t_2\) del fascio che formano con gli assi cartesiani nel secondo quadrante un triangolo di area 36.
d. Stabilisci per quali valori del parametro \(k\) le rette del fascio dato intersecano il segmento di estremi \(A(-8;0)\in B(-3;5)\)

[a) fascio proprio di rette di centro $(-5; 2), 2x + y + 8 = 0; \ b) \ 5x + y + 23 = 0;$

$$c) \ t_1: 2x - y + 12 = 0; \ t_2: 2x - 25y + 60 = 0; \ d) \ k \le -\frac{1}{8} \lor k \ge \frac{1}{7}]$$

30

Sono dati i punti $A(-2; 1), B(1; -1), D(2; 7)$ e la retta $r$ di equazione $2x - y - 7 = 0$.

a. Verifica che il triangolo \(ABD\) è rettangolo in \(A\).
b. Trova un punto \(C\) su \(r\) in modo che il quadrilatero \(ABCD\) sua un trapezio avente \(BC\) e \(AD\) come basi.
c. Calcola l'area del trapezio trovato. [b) C(9; 11); c) 39]

31

Siano $A(1; 3), B(4; 1), C(3; 5)$ i vertici di un triangolo. Determina le coordinate del baricentro e del circocentro e l'area del triangolo. Determina sul lato $AB$ un punto $P$ in modo che il rapporto tra l'area dei triangoli

$APC$ e $PBC$ sia $\frac{4}{5}$.

$$\left[ \left( \frac{8}{3}; 3 \right), \left( \frac{31}{10}; \frac{29}{10} \right); 5; P \left( \frac{7}{3}; \frac{19}{9} \right) \right]$$

32

Siano $r, s, t$ rispettivamente le rette di equazioni $y = 2, 4x - 3y + 2 = 0$ e $x + y - 10 = 0$. Si sa che $r$ e $s$ rappresentano le rette sulle quali giacciono due lati di un parallelogramma e che $t$ è la retta alla quale appartiene una diagonale. Determina i vertici, il perimetro e l'area del parallelogramma. Verifica inoltre che congiungendo i punti medi dei lati si ottiene un parallelogramma e calcola la sua area.

$$[(1; 2), (8; 2), (11; 6), (4; 6); 24; 28; 14]$$

VERIFICA LE COMPETENZE

267