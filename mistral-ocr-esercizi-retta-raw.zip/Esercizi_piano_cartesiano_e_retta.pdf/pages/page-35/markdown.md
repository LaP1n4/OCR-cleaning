Capitolo 4

PIANO CARTESIANO E RETTA

# 6 Luoghi geometrici e retta

I FONDAMENTALI

Prova tu fai un esercizio simile interattivo

# Scrivere l'equazione di un luogo geometrico

Scriviamo l'equazione del luogo geometrico dei punti del piano che hanno distanza $$\frac{3}{\sqrt{5}}$$ dalla retta $$r$$ di equazione $$2x + y + 3 = 0$$ e rappresentiamo tale luogo nel piano cartesiano.

Indichiamo con $$(x; y)$$ le coordinate di un generico punto $$P$$ del luogo cercato.

Detta $$H$$ la proiezione di $$P$$ sulla retta $$r$$, la distanza di $$P$$ da $$r$$ è:

$$\overline{PH} = \frac{|2 \cdot x + 1 \cdot y + 3|}{\sqrt{2^2 + 1^2}} = \frac{|2x + y + 3|}{\sqrt{5}}.$$

Poiché $$\overline{PH} = \frac{3}{\sqrt{5}}$$, allora:

![img-100.jpeg](img-100.jpeg)

$$\frac{|2x + y + 3|}{\sqrt{5}} = \frac{3}{\sqrt{5}} \rightarrow |2x + y + 3| = 3 \rightarrow 2x + y + 3 = \pm 3 \rightarrow$$

$$2x + y + 3 = -3 \quad \vee \quad 2x + y + 3 = 3 \rightarrow$$

$$2x + y + 6 = 0 \quad \vee \quad 2x + y = 0.$$

Il luogo cercato è costituito dall'unione di due rette, parallele alla retta data, di equazioni:

$$2x + y + 6 = 0 \quad \text{e} \quad 2x + y = 0.$$

Tutti i punti di un luogo geometrico soddisfano una stessa caratteristica. Traduci in termini analitici questa caratteristica per ottenere l'equazione.

453 Determinina e rappresenta l'equazione del luogo geometrico dei punti del piano che hanno distanza 1 alla retta di equazione \(3x + 4y + 5 = 0\)
\([3x + 4y = 0 \lor 3x + 4y + 10 = 0]\)
454 Scrivi l'equazione del luogo dei punti per i quali la somma dei quadrati delle distance dai due punti \(A(1;1)\) e \(B(1; - 1)\) è doppi rispetto al quadrato della distance dall'origine \(O\)
[1] \(x = 1\)
455 Dati i punti \(A(2;5)\) e \(B(6;5)\) , determina il luogo dei punti \(P\) tali che l'area del triangolo \(ABP\) sua 8.

$$[y = 1 \lor y = 9]$$

456 Sono dati i punti $$A(0; 1)$$, $$B(1; 0)$$ e $$C(4; 2)$$. Determina e rappresenta l'equazione del luogo dei punti $$P$$ del piano tali che:

$$\overline{PA}^2 + \overline{PB}^2 = 2\overline{PC}^2.$$

$$[7x + 3y - 19 = 0]$$

457 Date le rette parallele di equazioni \(x - 3y + 2 = 0\) e \(x - 3y + 6 = 0\), scrivi l'equazione del luogo geometrico dei punti equidistanti dalle due rette.
\([x - 3y + 4 = 0]\)
458 Determinina le equazioni delle due rette del piano distanti fra loro \(2\sqrt{5}\) ed equidistanti alla retta \(r\) di equazione \(x - 2y - 1 = 0\)
\([x - 2y + 4 = 0, x - 2y - 6 = 0]\)
459 Determinina l'equazione del luogo descritto dai punti \(P(k - 3;2k - 1)\) al variate di \(k\)

# COMPLETA LO SVOLGIMENTO

Scriviamo le equazioni parametriche del luogo:

$$\begin{cases} x = \_\_\_\_ - 3 \\ y = 2k - 1 \end{cases}$$

Troviamo la sua equazione cartesiana eliminando il parametro $$k$$ dalle due equazioni parametriche:

$$\begin{cases} k = x + 3 \\ y = 2 \_\_\_\_ - 1 \end{cases} \rightarrow y = 2x + \_\_\_\_.$$

ESERCIZIO

248