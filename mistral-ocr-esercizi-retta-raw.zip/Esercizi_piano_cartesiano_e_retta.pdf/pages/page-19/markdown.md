Capitolo 4 PIANO CARTESIANO E RETTA

ESERCIZI

286 $$\left\{ \begin{array}{l} y \geq 2 \\ y \leq x + 6 \end{array} \right.$$

287 $$\left\{ \begin{array}{l} y \leq 3x \\ y \geq x \end{array} \right.$$

288 $$\left\{ \begin{array}{l} y - x - 1 \leq 0 \\ x < 0 \\ y + 3 \geq 0 \end{array} \right.$$

289 $$\left\{ \begin{array}{l} 2y + 3x - 4 \leq 0 \\ 3y - 4x + 3 \geq 0 \end{array} \right.$$

290 $$\left\{ \begin{array}{l} x > \frac{3}{4} y - 3 \\ x \leq 2 - 2y \end{array} \right.$$

291 $$\left\{ \begin{array}{l} y \geq |x| \\ y \leq 4 \end{array} \right.$$

292 $$\left\{ \begin{array}{l} |x| < 2 \\ |x + y| < 2 \end{array} \right.$$

293 $$\left\{ \begin{array}{l} 2x - 3y + 6 \geq 0 \\ 9y + 4x - 36 \leq 0 \\ y > 1 \end{array} \right.$$

294 $$\left\{ \begin{array}{l} |y - 2x| \leq 1 \\ |y + x| < 1 \end{array} \right.$$

# FAI IL PUNTO SULLE COMPETENZE

# Rette nel piano cartesiano

Prima di iniziare, esercitati su laZ Esercizi

1 VERO O FALSO? Considera la retta di equazione $$kx + (1 - k)y - 3 = 0$$, con $$k \in \mathbb{R}$$.

a. Per \(k = 0\) l'equazione non rappresenta una funzione.
b. La retta ha coefficiente angolare negativo se \(0 < k < 1\)
c. Esiste un valore di \(k\) per cui la retta passa per l'origine.
d. Esiste un valore di \(k\) per cui i punti \((1;0)\) e \((-1; - 3)\) appartengono entrambi alla retta.
e. Per \(k = 1\) la retta giace solo nel II e nel III quadrante.

V F

V F

V F

V F

V F

2 Determina il dominio delle funzioni seguenti e rappresentate graficamente.

a. $$y = \frac{\sqrt{4x^2 - 4x + 1}}{|1 - 2x|} + x$$

b. $$y = \frac{|x - 3|}{3 - x} \cdot 2x - 4$$

[a) $$x \neq \frac{1}{2}$$; b) $$x \neq 3$$]

3 Determina, se esistono, i valori del parametro $$k$$ per cui la retta di equazione $$x + (k - 3)y + k = 0$$:

a. interseca l'asse \(y\) in un punto di ordinata positiva;
b. forma con il semiasse positivo delle ascisse un angolo ottuso;
c. non interseca l'asse \(y\)
d. passa per l'origine.

[a) $$0 < k < 3$$; b) $$k > 3$$; c) $$k = 3$$; d) $$k = 0$$]

4 Dati la retta di equazione $$4x - 2y + 1 = 0$$ e il punto $$C\left(1; \frac{1}{2}\right)$$, determina, se possibile, le coordinate dei punti $$A$$ e $$B$$ in modo che il triangolo $$ABC$$ sia isoscele, con la base $$AB$$ che giace sulla retta e i lati obliqui lunghi $$2\sqrt{2}$$.

$$\left[ \left(-1; -\frac{3}{2}\right), \left(\frac{7}{5}; \frac{33}{10}\right) \right]$$

5 REALTÀ E MODELLI Cristina sta riempendo la sua vasca da bagno, che ha una capacità di 200 L, quando riceve una telefonata. Chiude il rubinetto e lo riapre alla fine dei 25 minuti di telefonata, per richiuderlo poi quando c'è la giusta quantità d'acqua. Fatto il bagno toglie il tappo e lascia che la vasca si svuoti. La funzione della quantità di acqua $$y$$, in L, nella vasca al variare del tempo $$t$$, in minuti, dalla fine della telefonata è:

![img-50.jpeg](img-50.jpeg)

$$y = \begin{cases} 50 + 7t & \text{se } 0 \leq t < 10 \\ 120 & \text{se } 10 \leq t < 30. \\ -10t + 420 & \text{se } 30 \leq t \leq 42 \end{cases}$$

a. Rappresenta la funzione.
b. In che percentuale è piena la vasca all'arrivo della Telefonata?
c. Se Cristina avesse lasciato il rubinetto aperto durante la Telefonata, la vasca avrebbe potuto contentere tutte l'acqua? Supponi che la velocità di riempimento della vasca sia costante. [b] \(25\%\) c) no

6 TEST La retta $$r$$ forma con il semiasse positivo delle ascisse un angolo di $$150^{\circ}$$ e passa per il punto $$P$$, in cui la retta di equazione $$3x - 4y + 8 = 0$$ interseca l'asse $$y$$. Quale delle seguenti affermazioni è falsa?

A La retta $$r$$ ha coefficiente angolare negativo.

C La retta $$r$$ passa per il punto $$(-1; 0)$$.

B L'ordinata di $$r$$ all'origine è 2.

D La retta $$r$$ giace in tre quadranti.

232