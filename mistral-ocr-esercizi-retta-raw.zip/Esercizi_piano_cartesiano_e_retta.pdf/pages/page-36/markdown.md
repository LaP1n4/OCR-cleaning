LUOGHI GEOMETRICI E RETTA

Paragrafo 6

Determina l'equazione del luogo descritto dal punto P al variare di k.

460

$$P(k - 9; -1)$$

$$[y = -1]$$

463

$$P\left(\frac{2k - 1}{k}; \frac{k + 3}{k}\right)$$

$$[y + 3x - 7 = 0, x \neq 2]$$

461

$$P\left(2k + 3; 1 - \frac{k}{2}\right)$$

$$[x + 4y - 7 = 0]$$

464

$$P(1 - k^2; 2 + 2k^2)$$

$$[y = 4 - 2x]$$

462

$$P\left(\frac{k - 4}{3}; 2|k| + 8\right)$$

$$[y = 2 \cdot |3x + 4| + 8]$$

465

$$P\left(\frac{1 - k}{1 + k}; \frac{k}{2(1 + k)}\right)$$

$$[4y + x - 1 = 0, x \neq -1]$$

466

Determina il luogo geometrico descritto dal baricentro del triangolo di vertici $A(2; k - 3)$, $B(2k + 1; 6)$, $C(-5k + 1; 2k)$ al variare di $k$. [3x + 3y - 7 = 0]

467

FISICA MOTO NEL PIANO La torretta di un pantografo da incisione scorre con velocità costante $V_s$ lungo il braccio trasportatore, che a sua volta si muove in direzione perpendicolare con velocità costante di modulo $V_s$. La punta si trova inizialmente in A.

a. Determinina l'equazione della traiettoria descritta alla punta nel riferimento in figura, dove le coordinate sono in cm. Traccia il grafico nel piano cartesian.
b. Quanto è lunga l'incisione tracciata in 40 s? [a) \(2x + 3y - 411 = 0\); b) \(144\mathrm{cm}\)

![img-101.jpeg](img-101.jpeg)

# Asse di un segmento

Teoria a pagina 207

Determina l'equazione dell'asse del segmento che ha per estremi le seguenti coppie di punti.

468

$$A(-2; 1),$$

$$B(4; 3).$$

# COMPLETA LO SVOLGIMENTO

# Primo metodo

![img-102.jpeg](img-102.jpeg)

L'asse del segmento è la retta perpendicolare al segmento passante per il punto medio.

Determiniamo le coordinate del punto medio M di AB:

$$x_M = \frac{+4}{2} = 1, \quad y_M = \frac{1 +}{2} = 2 \rightarrow M(1; 2).$$

Calcoliamo il coefficiente angolare della retta AB:

$$m_{AB} = \frac{y_B - y_A}{x_B - x_A} = \frac{-1}{4 + 2} = \frac{1}{3}.$$

Il coefficiente angolare di una retta perpendicolare ad AB è $m = -3$. L'equazione dell'asse del segmento AB è:

$$y - 2 = 2(x - 1) \rightarrow y = -3x + 3 + 2 \rightarrow y = -3x + 5.$$

# Secondo metodo

L'asse del segmento AB è il luogo geometrico dei punti del piano equidistanti da A e da B.

Indichiamo con $P(x; y)$ un generico punto dell'asse. Vale l'uguaglianza: $\overline{PA} =$

Calcoliamo le distanze di P da A e da B:

$$\overline{PA} = \sqrt{(x + 2)^2 + (y - 3)^2}, \quad \overline{PB} = \sqrt{(x - 3)^2 + (y - 3)^2}.$$

Uguagliamo i quadrati delle distanze e ritroviamo l'equazione dell'asse:

$$x^2 + y^2 - 2y + 5 = x^2 + y^2 - 8x + 25 \rightarrow 12x + 4y - 20 = 0 \rightarrow 3x + y - 5 = 0.$$

469

$$A(2; 3),$$

$$B(4; 5).$$

$$[y = -x + 7]$$

471

$$A(-2; -\frac{1}{3}),$$

$$B(0; \frac{1}{3}).$$

$$[y = -3x - 3]$$

470

$$A(1; 1),$$

$$B(-1; 3).$$

$$[y = x + 2]$$

472

$$A(-2; -6),$$

$$B(2; 0).$$

$$[y = -\frac{2}{3}x - 3]$$

249

ESERCITA