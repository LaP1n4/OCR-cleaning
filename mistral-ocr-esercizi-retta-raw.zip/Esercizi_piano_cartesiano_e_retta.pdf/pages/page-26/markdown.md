DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

Scrivi l'equazione della retta passante per A e di coefficiente angolare m e rappresentala.

351 A(-1; 2), m = -1.

352 A(3; -1/2), m = 3.

353 A(-2; -3), m = 1/2.

357 LEGGI IL GRAFICO Scrivi le equazioni delle due rette rappresentate in figura e trova le coordinate del punto in cui si intersecano.

![img-59.jpeg](img-59.jpeg)

358 Scrivi l'equazione della retta passante per l'origine e di coefficiente angolare -2 e rappresentala. Trova i punti della retta che hanno distanza 3√5 dall'origine. [(3; -6), (-3; 6)]

354 A(0; -2), m = -5.

355 A(4/3; 5/2), m = -3/2.

356 A(3; 0), m = 4.

359 Scrivi l'equazione della retta che passa per il punto P(0; 5) e ha coefficiente angolare uguale a quello della retta di equazione 2x - 3y + 1 = 0.

[y = 2/3 x + 5]

360 Trova l'equazione della retta r che forma con l'asse x un angolo di 45° e passa per il punto P di ascissa 2 appartenente alla bisettrice del secondo e quarto quadrante. [y = x - 4]

361 TEST La retta r passante per il punto P(1; 1) forma con la retta s di equazione y + 3 = 0 un angolo di 45°. Quale tra le seguenti è l'equazione della retta r?

A \(y = x + 1\)
B \(x = y\)
C \(x = y + 1\)
D \(y = -x\)

# Coefficiente angolare, note le coordinate di due punti

Teoria a pagina 204

362 Determina, se è possibile, il coefficiente angolare delle rette AB e CD, conoscendo le coordinate dei punti A(-1; 3), B(3; 5), C(-3; -2) e D(-3; 1).

# COMPLETA LO SVOLGIMENTO

Calcoliamo il coefficiente angolare m(AB) della retta passante per A e per B.

m(AB) = -3/(3 - 1) = 2/4 = 1/2

Dati P1(x1; y1) e P2(x2; y2), il coefficiente angolare della retta passante per P1 e P2 è m = (y2 - y1)/(x2 - x1).

Osserviamo che C e D hanno la stessa ascissa, quindi, se volessimo usare la stessa formula per m(CD), avremmo al denominatore xD - xC = -(-3) = .

La frazione perciò non esiste e non ha senso parlare di coefficiente angolare. La retta infatti è parallela all'asse e ha equazione x = -3.

Determina, se è possibile, il coefficiente angolare della retta passante per la coppia di punti indicata.

363 A(0; 3), B(2; 4).

364 A(1; 5), B(3; 6).

365 C(2; 5), D(4; 5).

366 A(1/3; -1/2), B(2/3; -3/2).

367 E(0; 2), F(0; -2).

368 A(3; -1), B(3; -3).

369 Il punto A(-1; 4) appartiene alla retta AB il cui coefficiente angolare è 2/3. Qual è l'ordinata del punto B se la sua ascissa è 5?

COMPLETA inserendo il valore mancante, sapendo che m è il coefficiente angolare della retta AB.

370 m = 3, A(1; 2), B(3; ).

371 m = , A(3; 2), B(4; 4).

372 m = -1/4, A(2; -1), B( ; -3/2).

373 m = -3, A(-6; -6), B( ; -2).

239

ESERCIZIO