RETTE NEL PIANO CARTESIANO

Paragrafo 2

## 2 Rette nel piano cartesiano

1 attività interattiva

Teoria a pagina 196

### Dall'equazione al grafico

161 LEGGI IL GRAFICO ASSOCIA all'equazione di ogni retta il relativo grafico.

a. $-x - 2 = 0$

b. $y = -x - 2$

c. $y = -2$

d. $y - x - 2 = 0$

![img-29.jpeg](img-29.jpeg)

![img-30.jpeg](img-30.jpeg)

![img-31.jpeg](img-31.jpeg)

![img-32.jpeg](img-32.jpeg)

# I FONDAMENTALI

Prova tu foi un esercizio simile interattiva

### Disegnare una retta, data la sua equazione

Tracciamo le rette di equazioni:

a. $x = -3$;

b. $y = 4$;

c. $x + 4y - 4 = 0$.

a. $x = -3 \rightarrow$ tutti i punti hanno ascissa $-3$ (figura a).
b. $y = 4 \rightarrow$ tutti i punti hanno ordinata 4 (figura b).
c. Scriviamo l'equazione in forma esplicita: $y = -\frac{1}{4}x + 1$.
Troviamo alcuni punti della retta assegnando dei valori a piacere all'ascissa e calcolando l'ordinata.
Disegniamo i punti e tracciamo la retta (figura c).

Una retta di equazione:

- $x = h$ è parallela all'asse $y$;
- $y = k$ è parallela all'asse $x$.

Per rappresentare una retta non parallela ad alcun asse conviene scrivere la sua equazione in forma esplicita, così da calcolare più facilmente l'ordinata di un punto che le appartiene, partendo da un valore a piacere dell'ascissa.

![img-33.jpeg](img-33.jpeg)

![img-34.jpeg](img-34.jpeg)

![img-35.jpeg](img-35.jpeg)

### Rappresenta nel piano cartesiano le rette che hanno le seguenti equazioni.

162 $2x - 1 = 0$;

$y - 5 = 0$.

166 $y = -x + 4$;

$y = \frac{1}{4}x - 1$.

163 $2x - y = 0$;

$4y + 1 = 0$.

167 $x = 4$;

$x - y + 3 = 0$.

164 $y = -\frac{2}{3}x + 1$;

$x = \frac{5}{2}$.

168 $4x - 3 = 0$;

$2x + y - 1 = 0$.

165 $2x + 7 = 0$;

$4x - y + 4 = 0$.

169 $y - x + 1 = 0$;

$2x - 3y + 6 = 0$.

# 170 VERO O FALSO?

a. L'equazione $ax + 1 = 0$ rappresenta, per $a \neq 0$, l'equazione di una retta parallela all'asse $x$.
b. L'equazione $ax + by + c = 0$ rappresenta sempre, al variare di $a, b, c$, una retta del piano cartesiano.
c. $x = 2$ nel piano cartesiano rappresenta il punto $(2; 0)$ dell'asse $x$.
d. La retta $4x - 5y = 0$ passa per l'origine.

V F

V F

V F

V F

225

ESERCIZIO