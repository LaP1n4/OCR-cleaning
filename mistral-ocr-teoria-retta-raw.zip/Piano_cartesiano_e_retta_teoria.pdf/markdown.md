CAPITOLO

4

# Piano cartesiano e retta

![img-0.jpeg](img-0.jpeg)

# 1 Punti e segmenti

# Punti nel piano cartesiano

Esercizi a pagina 214

Fissiamo in un piano un sistema di riferimento cartesiano ortogonale, detto anche piano cartesiano, considerando due rette orientate tra loro perpendicolari. Le due rette sono gli assi del riferimento e vengono chiamate asse delle ascisse, o asse x, e asse delle ordinate, o asse y. Il loro punto di intersezione O è l'origine.

Scelta un'unità di misura su entrambi gli assi, ogni punto P del piano è rappresentato da una coppia ordinata di numeri reali (x_P; y_P) e viceversa.

![img-1.jpeg](img-1.jpeg)

Si crea così una corrispondenza biunivoca tra i punti del piano e le coppie ordinate di numeri reali.

In ogni coppia (x_P; y_P), x_P e y_P sono le coordinate del punto, il primo numero è l'ascissa e il secondo è l'ordinata.

Chiamiamo quadranti i punti interni ai quattro angoli retti in cui il piano cartesiano è diviso dagli assi. I quadranti sono ordinati in senso antiorario a partire dal quadrante in alto a destra. Le coordinate dei punti del piano sono positive o negative a seconda del quadrante in cui i punti si trovano.

![img-2.jpeg](img-2.jpeg)

I punti dell'asse x hanno ordinata 0, quelli dell'asse y hanno ascissa 0. L'origine O ha coordinate (0; 0).

Per esempio, il punto A(-4; 3) appartiene al secondo quadrante, mentre B(0; -5) appartiene all'asse y.

2 Video

1 Podcast,

3 Listen to it

1 Codice Python

Listen to it

A Cartesian coordinate system in the plane is given by a pair of axes that intersect at a point, called the origin: every point in the plane is uniquely identified by an ordered pair of coordinates, the abscissa (x) and the ordinate (y).

Video

Coordinate geografiche

Come funzionano le coordinate geografiche terrestri?
Come possono essere rappresentate su un piano?

193

Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

# Distanza fra due punti

Esercizi a pagina 216

# I punti hanno la stessa ordinata o la stessa ascissa

La distanza fra due punti $A(x_A; y_A)$ e $B(x_B; y_B)$ che hanno la stessa ordinata $y_A = y_B$ è la differenza delle loro ascisse, presa in valore assoluto, in modo da non doverci preoccupare di qual è la maggiore:

![img-3.jpeg](img-3.jpeg)

$$\overline{AB} = |x_B - x_A|.$$

Per esempio, nella figura a: $\overline{AB} = |x_B - x_A| = |3 - (-4)| = 7$.

Analogamente, la distanza fra due punti $A(x_A; y_A)$ e $B(x_B; y_B)$ con la stessa ascissa $x_A = x_B$ è:

![img-4.jpeg](img-4.jpeg)

$$\overline{AB} = |y_B - y_A|.$$

Per esempio, nella figura b: $\overline{AB} = |-1 - 2| = 3$.

# Il caso generale

Consideriamo il segmento $AB$ non parallelo agli assi cartesiani e indichiamo con $H$ il punto di intersezione tra la retta parallela all'asse $x$ tracciata da $A$ e la retta parallela all'asse $y$ tracciata da $B$. $H$ ha ascissa $x_B$ e ordinata $y_A$.

Applichiamo il teorema di Pitagora al triangolo rettangolo $ABH$:

![img-5.jpeg](img-5.jpeg)

$$\overline{AB} = \sqrt{AH^2 + BH^2}.$$

$$\overline{AH} = |x_B - x_A| \quad \text{e} \quad \overline{BH} = |y_B - y_A|.$$

quindi:

![img-6.jpeg](img-6.jpeg)

$$\overline{AB} = \sqrt{(x_B - x_A)^2 + (y_B - y_A)^2}.$$

Per esempio, nella figura c:

$$\overline{AB} = \sqrt{(5 - 2)^2 + (7 - 3)^2} = \sqrt{3^2 + 4^2} = \sqrt{9 + 16} = 5.$$

La formula è applicabile anche nei due casi particolari precedenti.

Inoltre, la distanza di un punto $P(x; y)$ dall'origine $O$ è $\overline{OP} = \sqrt{x^2 + y^2}$.

# Punto medio di un segmento

Esercizi a pagina 218

Consideriamo i punti $A(x_A; y_A)$ e $B(x_B; y_B)$. Vogliamo calcolare le coordinate del punto medio $M$ del segmento $AB$.

Dopo aver tracciato le parallele agli assi passanti per i punti $A, B$ e $M$, applichiamo il teorema di Talete dei segmenti congruenti: dato un fascio di rette parallele tagliato da due trasversali, a segmenti congruenti su una trasversale corrispondono segmenti congruenti sull'altra trasversale.

![img-7.jpeg](img-7.jpeg)

$AM \cong MB$, perché per ipotesi $M$ è punto medio di $AB$, quindi $A'M' \cong M'B'$ e $A''M'' \cong M''B''$.

$$\overline{A'M'} = \overline{M'B'}, \quad \text{quindi} \quad |x_M - x_A| = |x_B - x_M|.$$

Poiché $x_A < x_M$ e $x_M < x_B$, eliminiamo i valori assoluti:

$$x_M - x_A = x_B - x_M.$$

Ricaviamo $x_M$:

$$x_M + x_M = x_A + x_B \rightarrow 2x_M = x_A + x_B \rightarrow x_M = \frac{x_A + x_B}{2}.$$

Con considerazioni analoghe, otteniamo: $y_M = \frac{y_A + y_B}{2}$.

194

PUNTI E SEGMENTI

Paragrafo 1

In sintesi, dati i punti $A(x_A; y_A)$ e $B(x_B; y_B)$, il punto medio $M$ del segmento $AB$ ha coordinate:

$$x_M = \frac{x_A + x_B}{2}, \quad y_M = \frac{y_A + y_B}{2}.$$

# ESEMPIO

Determiniamo il punto medio $M$ del segmento $AB$ con $A(2; 1)$ e $B(8; 5)$.

![img-8.jpeg](img-8.jpeg)

$$x_M = \frac{2 + 8}{2} = 5;$$

$$y_M = \frac{1 + 5}{2} = 3.$$

# Baricentro di un triangolo

Esercizi a pagina 220

Il baricentro di un triangolo è il punto di incontro delle tre mediane. Ognuna di esse è divisa dal baricentro in due parti tali che quella che ha un estremo nel vertice è doppia dell'altra.

![img-9.jpeg](img-9.jpeg)

Consideriamo i punti non allineati $A(x_A; y_A)$, $B(x_B; y_B)$ e $C(x_C; y_C)$. Vogliamo calcolare le coordinate $(x_G; y_G)$ del baricentro $G$ del triangolo $ABC$.

Determiniamo le coordinate di $M$, punto medio del lato $AB$, con le formule del punto medio:

$$x_M = \frac{x_A + x_B}{2}, \quad y_M = \frac{y_A + y_B}{2}.$$

Per la proprietà del baricentro, vale la relazione: $CG \cong 2GM$.

Tracciamo le parallele all'asse $y$ passanti per $M$, $G$ e $C$ e, considerando le trasversali $MC$ e $M'C'$, applichiamo il teorema di Talete.

Poiché $CG \cong 2GM$, allora $C'G' \cong 2G'M'$.

Determiniamo le misure dei segmenti $C'G'$ e $G'M'$:

$$\overline{C'G'} = x_C - x_G, \quad \overline{G'M'} = x_G - x_M.$$

Poiché $\overline{C'G'} = 2\overline{G'M'}$, sostituendo otteniamo:

$$x_C - x_G = 2(x_G - x_M).$$

Ricaviamo $x_G$:

$$x_C - x_G = 2x_G - 2x_M \rightarrow 3x_G = x_C + 2x_M \rightarrow x_G = \frac{x_C + 2x_M}{3}.$$

Sostituendo $x_M = \frac{x_A + x_B}{2}$, si ottiene:

$$x_G = \frac{x_C + 2x_M}{3} = \frac{x_C + 2\frac{x_A + x_B}{2}}{3} = \frac{x_A + x_B + x_C}{3}.$$

Analogamente, se proiettiamo $M$, $G$ e $C$ sull'asse $y$, troviamo $y_G = \frac{y_A + y_B + y_C}{3}$.

Quindi, dato un triangolo di vertici $A(x_A; y_A)$, $B(x_B; y_B)$, $C(x_C; y_C)$, le coordinate del suo baricentro $G$ sono espresse dalle formule:

$$x_G = \frac{x_A + x_B + x_C}{3}, \quad y_G = \frac{y_A + y_B + y_C}{3}.$$

# PROVA SUBITO

# Punto medio

Determina il punto medio del segmento che ha per estremi i punti $(-2; 0)$ e $(4; -3)$.

# Teorema di Talete

In un fascio di rette parallele tagliate da due trasversali, i segmenti su una trasversale sono proporzionali ai segmenti corrispondenti sull'altra.

195

TEORIA

Capitolo 4

PIANO CARTESIANO E RETTA

VICOLI

# ESEMPIO

![img-10.jpeg](img-10.jpeg)

Troviamo il baricentro del triangolo ABC di vertici A(0; -1), B(6; 2) e C(3; 5).

Il baricentro G del triangolo ABC ha coordinate:

$$\begin{array}{l} x_{G} = \frac{0 + 6 + 3}{3} = 3, \\ y_{G} = \frac{-1 + 2 + 5}{3} = 2. \end{array}$$

## 2 Rette nel piano cartesiano

Esercizi a pagina 225

# Equazione lineare in due variabili

Un'equazione lineare in due variabili x e y è un'equazione di primo grado rispetto a entrambe le incognite. Può essere scritta nella forma:

$$ax + by + c = 0,$$

con a, b, c ∈ ℝ (a e b non entrambi nulli).

Una soluzione dell'equazione è una coppia (x₀; y₀) di numeri reali che la soddisfa, cioè che rende vera l'uguaglianza.

# ESEMPIO

Data l'equazione 3x + 2y - 6 = 0, sostituiamo dei valori a x, per esempio:

$$\begin{array}{l} x = 0 \rightarrow 3 \cdot 0 + 2y - 6 = 0 \rightarrow 2y = 6 \rightarrow y = 3; \\ x = 1 \rightarrow 3 \cdot 1 + 2y - 6 = 0 \rightarrow 2y = 3 \rightarrow y = \frac{3}{2}. \end{array}$$

Le coppie (0; 3) e (1; 3/2) sono due soluzioni dell'equazione.

Le soluzioni sono infinite; se a ≠ 0 e b ≠ 0, per ottenerle basta sostituire a x un qualsiasi numero reale e determinare il corrispondente valore di y.

# Equazione della retta in forma implicita

Data un'equazione lineare in due variabili, a ogni soluzione corrisponde un punto del piano cartesiano, mentre, dato un punto del piano, non sempre le sue coordinate sono una delle infinite soluzioni dell'equazione.

Si può dimostrare la seguente proprietà.

A ogni retta del piano cartesiano corrisponde un'equazione lineare in due variabili e, viceversa, a ogni equazione lineare in due variabili corrisponde una retta.

L'equazione

$$ax + by + c = 0,$$

con a, b e c numeri reali e a, b non entrambi nulli, rappresenta, al variare di a, b e c, tutte le rette del piano e viene detta equazione della retta in forma implicita perché nessuna delle variabili è ricavata in funzione dell'altra.

# PROVA SUBITO

# Baricentro di un triangolo

Calcola le coordinate del baricentro del triangolo di vertici (-5; -2), (-3; -2) e (-4; 4).

# STORIE DI MATEMATICA

# Descartes e la geometria analitica

Il francese René Descartes, conosciuto in Italia come Cartesio, sviluppa nel Seicento l'idea di considerare gli oggetti geometrici in relazione a un sistema di coordinate. Nasce così la geometria analitica.

Podcast

# PROVA SUBITO

# Soluzioni di un'equazione lineare

Trova alcune soluzioni dell'equazione

$$y - x + 4 = 0.$$

196

RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Casi particolari dell'equazione $ax + by + c = 0$

Nell'equazione $ax + by + c = 0$ sono presenti tre parametri reali: $a$, $b$ e $c$. Vediamo che cosa accade se uno o due di essi si annullano, con $a$ e $b$ non entrambi nulli.

# 1. Retta parallela all'asse $x$.

Se $a = 0$ e $b \neq 0$, l'equazione $ax + by + c = 0$ diventa

$$by + c = 0 \rightarrow y = -\frac{c}{b}, \quad \text{con } b \neq 0.$$

Se poniamo $-\frac{c}{b} = k$, otteniamo $y = k$.

Detto $A(0; k)$ il punto di intersezione con l'asse $y$ di una retta parallela all'asse $x$:

- tutti i punti della retta hanno ordinata \(k\)
- ogni punto di ordinata \(k\) appartiene alla retta.

![img-11.jpeg](img-11.jpeg)

Quindi tutti e soli i punti della retta soddisfano l'equazione:

$y = k$, equazione di una retta parallela all'asse $x$.

Per esempio, $y = -2$ è l'equazione della retta parallela all'asse $x$ i cui punti hanno tutti ordinata $-2$.

![img-12.jpeg](img-12.jpeg)

Se $k = 0$, ovvero $c = 0$, la retta coincide con l'asse $x$, che ha quindi equazione:

$$y = 0. \quad \text{equazione dell'asse } x$$

# 2. Retta parallela all'asse $y$.

Se $a \neq 0$ e $b = 0$, l'equazione diventa

$$ax + c = 0 \rightarrow x = -\frac{c}{a}, \quad \text{con } a \neq 0.$$

Se poniamo $-\frac{c}{a} = h$, otteniamo $x = h$.

Detto $B(h; 0)$ il punto di intersezione con l'asse $x$ di una retta parallela all'asse $y$:

![img-13.jpeg](img-13.jpeg)

- tutti i punti della retta hanno ascissa \( h \)
- ogni punto di ascissa \( h \) appartiene alla retta.

Quindi tutti e soli i punti della retta soddisfano l'equazione:

$x = h$, equazione di una retta parallela all'asse $y$.

Per esempio, $x = \frac{1}{2}$ è l'equazione della retta parallela all'asse $y$ i cui punti hanno tutti ascissa $\frac{1}{2}$.

![img-14.jpeg](img-14.jpeg)

Se $h = 0$, ovvero $c = 0$, la retta coincide con l'asse $y$, che ha quindi equazione:

$$x = 0. \quad \text{equazione dell'asse } y$$

![img-15.jpeg](img-15.jpeg)

# 3. Retta passante per l'origine.

Se $a \neq 0$, $b \neq 0$ e $c = 0$, l'equazione diventa $ax + by = 0$ e rappresenta una retta che passa per l'origine degli assi.

Infatti, se sostituiamo le coordinate dell'origine $O(0; 0)$ nell'equazione, otteniamo $a \cdot 0 + b \cdot 0 = 0 \rightarrow 0 = 0$: l'equazione è soddisfatta per qualunque valore di $a$ e $b$.

# Equazione della retta in forma esplicita

Se nell'equazione della retta $ax + by + c = 0$ esplicitiamo la variabile $y$, otteniamo:

$$by = -ax - c \xrightarrow{b \neq 0} y = -\frac{a}{b}x - \frac{c}{b}.$$

Nel considerare $b \neq 0$ escludiamo il caso $ax + c = 0$, che rappresenta una retta parallela all'asse $y$.

# PROVA SUBITO

Retta parallela all'asse $x$

Disegna la retta di equazione $3y + 9 = 0$.

# PROVA SUBITO

Retta parallela all'asse $y$

Disegna la retta di equazione $5x - 10 = 0$.

197

TEORIA

Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

Poniamo $m = -\frac{a}{b}$ e $q = -\frac{c}{b}$ e scriviamo $y = mx + q$, che è l'equazione di una retta generica non parallela all'asse $y$.

L'equazione $y = mx + q$ è detta equazione della retta in forma esplicita perché in essa viene espressa la variabile $y$ in funzione di $x$.

$y = mx + q$ è l'equazione di una funzione lineare.

# Casi particolari dell'equazione $y = mx + q$

Nell'equazione $y = mx + q$ sono presenti due parametri reali, $m$ e $q$, che possono annullarsi.

# 1. Retta parallela all'asse $x$

Se $m = 0$, l'equazione diventa $y = q$, che, come abbiamo visto, rappresenta una retta parallela all'asse $x$.

Se anche $q = 0$, otteniamo $y = 0$, l'equazione dell'asse $x$.

# 2. Retta passante per l'origine

Se $q = 0$, l'equazione diventa

$$y = mx,$$

che rappresenta una retta passante per l'origine degli assi.

Infatti, sostituendo le coordinate di $O(0; 0)$ nell'equazione, per ogni $m \in \mathbb{R}$ abbiamo: $0 = m \cdot 0 \to 0 = 0$.

Per esempio, rappresentiamo l'equazione $y = 2x$ assegnando a $x$ alcuni valori.

|  x | y  |
| --- | --- |
|  -1 | -2  |
|  0 | 0  |
|  1/2 | 1  |
|  1 | 2  |

![img-16.jpeg](img-16.jpeg)

![img-17.jpeg](img-17.jpeg)

Viceversa, data una retta passante per l'origine, che non coincida con l'asse $y$, prendiamo a caso alcuni suoi punti, per esempio quelli della figura, $P, P'$ e $P''$. Indichiamo con $H, H'$ e $H''$ le loro proiezioni sull'asse $x$. I triangoli $OPH, OP'H'$ e $OP''H''$ sono simili tra loro, quindi:

$$\frac{PH}{OH'} = \frac{P'H'}{OH''} = \frac{P''H''}{OH''}.$$

Considerando le coordinate dei punti, possiamo allora scrivere:

$$\frac{y_P}{x_P} = \frac{y_{P'}}{x_{P'}} = \frac{y_{P''}}{x_{P''}} = m,$$

dove $m$ è un numero reale costante. Tutti i punti della retta godono di questa proprietà e, viceversa, si può dimostrare che la proprietà è vera soltanto per essi. In conclusione, una retta passante per l'origine, escluso l'asse $y$, ha equazione

$$y = mx$$

![img-18.jpeg](img-18.jpeg)

e viceversa.

Se $m = 1$, i punti della retta hanno l'ascissa uguale all'ordinata (figura a lato). Il triangolo $OHP$ è rettangolo e isoscele, quindi $H\widehat{OP}$ è metà dell'angolo retto e la retta è la bisettrice del primo e terzo quadrante.

$y = x$ — equazione della bisettrice del primo e terzo quadrante

# PROVA SUBITO

Dalla forma implicita alla forma esplicita

Scrivi in forma esplicita l'equazione della retta $8x + 4y - 6 = 0$.

198

RETTE NEL PIANO CARTESIANO

Paragrafo 2

Analogamente, se $m = -1$, i punti della retta hanno coordinate opposte (figura a lato). Il triangolo $OKQ$ è rettangolo e isoscele e l'angolo $K\overline{O}Q$ è metà dell'angolo retto.

![img-19.jpeg](img-19.jpeg)

$y = -x$ — equazione della bisettrice del secondo e quarto quadrante

Se $m = 0$, otteniamo nuovamente l'equazione dell'asse $x$.

Se confrontiamo quanto esaminato per le due equazioni, in forma implicita ed esplicita, confermiamo che le uniche rette non rappresentate dall'equazione $y = mx + q$, al variare di $m$ e $q$, sono le rette parallele all'asse $y$, di equazione $x = h$. Si ha quindi che

$$ax + by + c = 0 \quad \text{equivale a} \quad y = mx + q \lor x = h.$$

Se $b \neq 0$, per passare dalla forma implicita a quella esplicita basta risolvere l'equazione rispetto a $y$. Tale operazione è utile per mettere in evidenza i valori di $m$ e di $q$, che hanno un preciso significato nel grafico della retta.

# Significato di $m$ e $q$ nell'equazione $y = mx + q$

# Coefficiente angolare e pendenza

![img-20.jpeg](img-20.jpeg)

Chiamiamo angolo fra retta e asse $x$ l'angolo orientato $\alpha$ che ha per vertice il loro punto di intersezione e come lati la semiretta costituita dai punti della retta con ordinata positiva e la semiretta sull'asse $x$ di verso positivo. L'angolo è misurato in senso antiorario a partire dal semiasse positivo delle ascisse.

Il valore di $m$ è funzione di tale angolo ed esprime la pendenza della retta rispetto all'asse $x$. Per questo motivo, il coefficiente $m$ si chiama coefficiente angolare.

# ESEMPIO

Osserviamo la figura a fianco. Ricordando le relazioni fra le misure dei lati di un triangolo con angoli acuti di $30^{\circ}$ e di $60^{\circ}$, se l'angolo fra la retta passante per l'origine e l'asse $x$ è di $60^{\circ}$, $P(1; \sqrt{3})$ appartiene alla retta, quindi:

$$\sqrt{3} = m \cdot 1 \rightarrow m = \sqrt{3}.$$

Nella figura a fianco vediamo come varia $m$ al variare dell'angolo $\alpha$:

![img-21.jpeg](img-21.jpeg)

se \(\alpha\) e nullo o piatto, \(m\) e nullo;
se \(\alpha\) e acuto, \(m\) assume valori positivi e sempre maggiori man mano che l'angolo si avvicina all'angolo retto;
se \(\alpha\) e retto, non esiste un corrispondente valore di \(m\) in quanto le rette parallele all'asse \(y\) non hanno equazione esprimibile nella forma \(y = mx\);
se \(\alpha\) e ottuso, \(m\) e negativo e assume valori sempre minori,cioe sempre maggiori in valore assoluto, all'avicinarisi di \(\alpha\) all'angolo retto.

# ESEMPIO

![img-22.jpeg](img-22.jpeg)

In base alla normativa, una rampa per disabili non può avere una pendenza superiore all'8%. Questo significa che, per una rampa con la massima pendenza consentita, uno spostamento orizzontale di $1 \text{ m} = 100 \text{ cm}$ comporta uno spostamento verticale di $8 \text{ cm}$.

A quale coefficiente angolare corrisponde tale pendenza?

>SEGUE

![img-23.jpeg](img-23.jpeg)

![img-24.jpeg](img-24.jpeg)

Se $\overline{OA} = 1$, allora $\overline{OP} = 2$ e $\overline{AP} = \sqrt{3}$, quindi $P(1; \sqrt{3})$.

# PROVA SUBITO

# Angolo di $30^{\circ}$

Qual è il coefficiente angolare di una retta passante per l'origine che forma con l'asse $x$ un angolo di $30^{\circ}$?

199

TECNIA

Capitolo 4

PIANO CARTESIANO E RETTA

ITROVA

Possiamo rappresentare il profilo della rampa in un piano cartesiano con una retta che passa per l'origine e per il punto P(100; 8).

La coppia (100; 8) deve quindi essere soluzione dell'equazione y = mx, cioè:

![img-25.jpeg](img-25.jpeg)

$$8 = m \cdot 100 \rightarrow m = \frac{2}{25}.$$

$$m = \frac{2}{25} = \frac{8}{100} = 8\%$$ è proprio la pendenza della rampa.

# Ordinata all'origine e intersezione con l'asse y

![img-26.jpeg](img-26.jpeg)

Il valore di q rappresenta l'ordinata del punto di intersezione della retta con l'asse y.

Per questo motivo, il termine noto dell'equazione

$$y = mx + q$$

si chiama ordinata all'origine o intercetta.

Se q = 0, la retta passa per l'origine.

# 3 Posizione reciproca di due rette

Due rette r e s possono essere incidenti, parallele e distinte, parallele e coincidenti.

La posizione reciproca di r e s è collegata al sistema formato dalle equazioni delle due rette:

$$\begin{cases} ax + by + c = 0 \\ a'x + b'y + c' = 0 \end{cases}$$

# Rette incidenti

Esercizi a pagina 233

# ESEMPIO

![img-27.jpeg](img-27.jpeg)

Un'azienda ha due linee di produzione per fabbricare viti. L'utilizzo di ogni linea prevede dei costi fissi di avviamento e dei costi variabili che dipendono dal numero di confezioni di viti prodotte:

linea A: \(5\in\) per l'avvio \(+2,50\in\) a confezione;
linea B: \(10\in\) per l'avvio \(+2\in\) a confezione.

A ogni avvio si producono al massimo 9 confezioni di un certo tipo di viti, mentre di un secondo tipo di viti si producono sempre più di 12 confezioni.

Quale linea conviene utilizzare per la produzione del primo tipo di viti? E per la produzione del secondo?

Indichiamo con x il numero di confezioni prodotte e con y il costo totale (x > 0 e y > 0), ipotizzando che possano assumere tutti i valori reali positivi, e scriviamo le equazioni che corrispondono alle due possibilità:

![img-28.jpeg](img-28.jpeg)

![img-29.jpeg](img-29.jpeg)

# PROVA SUBITO

# Coefficiente angolare e pendenza

Quale coefficiente angolare ha una retta che rappresenta il profilo di una strada in cui a uno spostamento in orizzontale di 80 m corrisponde uno spostamento in verticale di 4 m?

# Video

# Fabbrica di auto

Quante auto deve vendere una fabrica automobilistica per copire i costi di impianto e andare in par?
E per ave un utile del 5% sul fatturato?

200

POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

Rappresentiamo le rette e troviamo il punto di intersezione.

![img-30.jpeg](img-30.jpeg)

$$\left\{ \begin{array}{l} y = 5 + 2,50x \\ y = 10 + 2x \end{array} \right. \rightarrow \left\{ \begin{array}{l} 10 + 2x = 5 + 2,50x \\ y = 10 + 2x \end{array} \right. \rightarrow$$

$$\left\{ \begin{array}{l} 0,50x = 5 \\ y = 10 + 2x \end{array} \right. \rightarrow \left\{ \begin{array}{l} x = 10 \\ y = 30 \end{array} \right.$$

La linea di produzione più conveniente da usare è quella che, al variare di $x$, comporta costi più bassi.

Per $x = 10$ le due linee di produzione sono equivalenti, per $x < 10$ conviene la A, per $x > 10$ conviene la B. Per il primo tipo di viti, di cui si producono al massimo 9 confezioni, all'azienda conviene avviare la linea A, mentre per il secondo tipo, di cui si producono più di 12 confezioni alla volta, conviene avviare la linea B.

## Rette parallele

Esercizi a pagina 236

Dimostriamo il seguente teorema.

# TEOREMA

# Rette parallele

Due rette $r$ e $s$ (non parallele all'asse $y$), di equazioni $y = mx + q$ e $y = m_1x + q_1$, sono parallele se e solo se hanno lo stesso coefficiente angolare:

$$r \parallel s \leftrightarrow m = m_1.$$

# DIMOSTRAZIONE

Due rette sono parallele se non hanno punti in comune oppure se coincidono. Il sistema delle loro equazioni,

$$\left\{ \begin{array}{l} y = mx + q \\ y = m_1x + q_1, \end{array} \right.$$

non può essere determinato, altrimenti le rette sarebbero incidenti.

Quindi il sistema deve essere impossibile o indeterminato.

Utilizzando il metodo del confronto, otteniamo l'equazione

$$mx + q = m_1x + q_1 \rightarrow mx - m_1x = q_1 - q \rightarrow (m - m_1)x = q_1 - q,$$

che è impossibile o indeterminata se e solo se:

$$m - m_1 = 0 \rightarrow m = m_1.$$

# ESEMPIO

![img-31.jpeg](img-31.jpeg)

Le rette di equazioni $y = 2x + 4$ e $y = 2x - 1$ sono parallele perché hanno lo stesso coefficiente angolare 2. Le rappresentiamo nella figura a lato.

Se le rette $r$ e $s$, non parallele all'asse $y$, hanno equazioni in forma implicita

$$r: ax + by + c = 0, \quad s: a_1x + b_1y + c_1 = 0,$$

i loro coefficienti angolari sono $m = -\frac{a}{b}$ e $m_1 = -\frac{a_1}{b_1}$.

Quindi, $r$ e $s$ sono parallele se e solo se:

$$m = m_1 \leftrightarrow -\frac{a}{b} = -\frac{a_1}{b_1} \leftrightarrow ab_1 = a_1b \leftrightarrow ab_1 - a_1b = 0.$$

In sintesi:

$$r \parallel s \leftrightarrow m = m_1 \leftrightarrow ab_1 - a_1b = 0.$$

Puoi verificare che la condizione di parallelismo $ab_1 - a_1b = 0$ è valida anche per rette parallele all'asse $y$. Per esempio:

$$r: x - 4 = 0, \quad s: 5x + 10 = 0; \quad r \parallel s \leftrightarrow 1 \cdot 0 - 5 \cdot 0 = 0.$$

# PROVA SUBITO

# Rette parallele

Stabilisci quali, fra le seguenti equazioni, rappresentano rette parallele, distinguendo tra coincidenti e distinte.

a. \(13y - 39x + 26 = 0\)
b. \(y = 3x - 2\)
c. \(6x - 2y + 5 = 0\)
d. \(3x + y + 4 = 0\)

201

TEORAMA

Capitolo 4

PIANO CARTESIANO E RETTA

ITOGNA

Le rette sono parallele e distinte se

$$m = m_1 \quad \text{e} \quad q \neq q_1.$$

Le rette sono parallele e coincidenti se

$$m = m_1 \quad \text{e} \quad q = q_1.$$

Riassumiamo i casi possibili della posizione reciproca di due rette.

![img-32.jpeg](img-32.jpeg)

![img-33.jpeg](img-33.jpeg)

![img-34.jpeg](img-34.jpeg)

a. Le rette sono incidenti:

$$\frac{a}{a_1} \neq \frac{b}{b_1} \leftrightarrow m \neq m_1.$$

Il sistema è determinato e ammette per soluzione le coordinate di P.

b. Le rette sono parallele e distinte:

$$\frac{a}{a_1} = \frac{b}{b_1} \neq \frac{c}{c_1} \leftrightarrow (m = m_1) \wedge (q \neq q_1).$$

Il sistema è impossibile.

c. Le rette sono coincidenti:

$$\frac{a}{a_1} = \frac{b}{b_1} = \frac{c}{c_1} \leftrightarrow (m = m_1) \wedge (q = q_1).$$

Il sistema è indeterminato.

# Rette perpendicolari

Esercizi a pagina 236

Vale il seguente teorema.

# TEOREMA

# Rette perpendicolari

Due rette r e s (non parallele agli assi), di equazioni y = mx + q e y = m₁x + q₁, sono perpendicolari se e solo se il prodotto dei loro coefficienti angolari è -1:

$$r \perp s \leftrightarrow mm_1 = -1.$$

# DIMOSTRAZIONE

1 Consideriamo le rette r' e s' parallele a r e s e passanti per l'origine. Le loro equazioni sono:

![img-35.jpeg](img-35.jpeg)

$$r': y = mx, \quad s': y = m_1x.$$

Gli angoli che si formano fra r' e s' sono congruenti a quelli formati da r e s, quindi r' e s' sono perpendicolari se e solo se lo sono r e s.

Se dimostriamo il teorema per r' e s', esso vale anche per r e s.

2 Su r' e s' prendiamo i punti A e B con ascissa 1:

$$A(1; m), B(1; m_1).$$

![img-36.jpeg](img-36.jpeg)

Il triangolo AOB è rettangolo in O se e solo se vale il teorema di Pitagora:

$$\overline{AB}^2 = \overline{OA}^2 + \overline{OB}^2.$$

Esprimiamo $\overline{AB}^2, \overline{OA}^2$ e $\overline{OB}^2$ in funzione di m e m₁:

$$\overline{AB} = |m - m_1| \rightarrow \overline{AB}^2 = (m - m_1)^2;$$

$$\overline{OA} = \sqrt{(1 - 0)^2 + (m - 0)^2} \rightarrow \overline{OA}^2 = 1 + m^2;$$

$$\overline{OB} = \sqrt{(1 - 0)^2 + (m_1 - 0)^2} \rightarrow \overline{OB}^2 = 1 + m_1^2.$$

202

DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

Sostituiamo nell'uguaglianza del teorema di Pitagora:

$$\begin{array}{l} (m - m _ {1}) ^ {2} = (1 + m ^ {2}) + (1 + m _ {1} ^ {2}) \rightarrow \\ \mu_ {1} ^ {\prime 4} + \mu_ {1} ^ {\prime 4} - 2 m m _ {1} = 2 + \mu_ {1} ^ {\prime 4} + \mu_ {1} ^ {\prime 4} \rightarrow m \cdot m _ {1} = - 1. \end{array}$$

# **ESEMPIO**

![img-37.jpeg](img-37.jpeg)

Le rette di equazioni $y = 2x + 2$ e $y = -\frac{1}{2}x + 1$ sono perpendicolari perché il prodotto dei loro coefficienti angolari è $-1$:

$$2 \cdot \left(- \frac {1}{2}\right) = - 1.$$

Consideriamo le rette $r$ e $s$, che hanno equazioni in forma implicita

$$r: a x + b y + c = 0, \quad s: a _ {1} x + b _ {1} y + c _ {1} = 0.$$

$r$ e $s$ sono perpendicolari se e solo se:

$$m = - \frac {1}{m _ {1}} \leftrightarrow - \frac {a}{b} = - \frac {1}{- \frac {a _ {1}}{b _ {1}}} \leftrightarrow - \frac {a}{b} = \frac {b _ {1}}{a _ {1}} \leftrightarrow a a _ {1} + b b _ {1} = 0.$$

In sintesi:

$$r \perp s \leftrightarrow m = - \frac {1}{m _ {1}} \leftrightarrow a a _ {1} + b b _ {1} = 0.$$

Puoi verificare che la condizione di perpendicolarità $aa_{1} + bb_{1} = 0$ è valida anche per rette parallele agli assi cartesiani. Per esempio:

$$r: y - 4 = 0, \quad s: 2 x + 5 = 0; \quad r \perp s \leftrightarrow 0 \cdot 2 + 1 \cdot 0 = 0.$$

## 4 Determinare l'equazione di una retta

Vogliamo trovare l'equazione di una retta quando di essa sono noti un punto e il coefficiente angolare oppure due punti.

Poiché il coefficiente angolare contiene le informazioni sulla pendenza della retta, dalla geometria euclidea sappiamo che ciascuna delle due condizioni permette di individuare univocamente la retta stessa.

# **Equazione di una retta passante per un punto e di coefficiente angolare noto**

Esercizi a pagina 238

Se una retta, non parallela all'asse $y$, passa per un punto $P(x_1; y_1)$, le coordinate del punto devono soddisfare l'equazione

$$y = m x + q,$$

quindi deve valere

$$y _ {1} = m x _ {1} + q.$$

Sottraendo i due membri della seconda uguaglianza a quelli della prima, otteniamo:

$$y - y _ {1} = m \cdot (x - x _ {1}). \quad \text {e q u a z i o n e d e l l a r t t a d i c o e f f i c i e n t e} \\ \text {a n g o l a r e m p a s s a n t e p e r} P (x _ {1}; y _ {1})$$

# **ESEMPIO**

L'equazione della retta di coefficiente angolare $\frac{3}{4}$ e passante per $P(1;2)$ è:

$$y - 2 = \frac {3}{4} \cdot (x - 1) \quad \rightarrow \quad y = \frac {3}{4} x + \frac {5}{4}.$$

# **PROVA SUBITO**

# **Rette perpendicolari**

Stabilisci quali, fra le seguenti equazioni, rappresentano rette perpendicolari.

a. \(4x + y - 1 = 0\)
b. \(4x - y + 5 = 0\)
c. \(4y - x + 5 = 0\)

# **PROVA SUBITO**

# **Retta per P, noto m**

a. Scrivi l'equazione della retta che passa per il punto (1; 1) e ha coefficiente angolare 5.
b. Scrivi l'equazione della retta parallela a \( r \): \( y = -3x + 5 \) e passante per (0; -3).
c. Trova l'equazione della retta perpendicolare a \( s: y = \frac{3}{4} x - \frac{1}{4} \) e passante per (3; 2).

203

TECNIA

Capitolo 4

PIANO CARTESIANO E RETTA

VACCIA

# Coefficiente angolare, note le coordinate di due punti

Esercizi a pagina 239

Ricaviamo il coefficiente angolare m di una retta di equazione y = mx + q in funzione delle coordinate di due suoi punti distinti, A(x₁; y₁) e B(x₂; y₂).

y₁ = mx₁ + q, perché A è un punto della retta;

y₂ = mx₂ + q, perché B è un punto della retta.

Sottraendo membro a membro la prima equazione dalla seconda:

$$y_2 - y_1 = mx_2 - mx_1 \quad \rightarrow \quad y_2 - y_1 = m(x_2 - x_1) \quad \rightarrow \quad m = \frac{y_2 - y_1}{x_2 - x_1}.$$

# PROPRIETÀ

![img-38.jpeg](img-38.jpeg)

Il coefficiente angolare di una retta non parallela all'asse y è il rapporto fra la differenza delle ordinate e la differenza delle ascisse di due punti distinti della retta, prese nello stesso ordine:

$$m = \frac{y_2 - y_1}{x_2 - x_1}, \quad \text{con } x_2 \neq x_1.$$

# ESEMPIO

![img-39.jpeg](img-39.jpeg)

Qual è il coefficiente angolare della retta passante per i punti A(-2; 2) e B(3; -1/2)?

$$m = \frac{-\frac{1}{2} - 2}{3 - (-2)} = \frac{-\frac{5}{2}}{5} = -\frac{1}{2}.$$

Se indichiamo con Δx l'incremento x₂ - x₁ dei valori di x e con Δy la corrispondente variazione y₂ - y₁ dei valori di y, otteniamo:

$$m = \frac{y_2 - y_1}{x_2 - x_1} = \frac{\Delta y}{\Delta x}.$$

Se Δx = 1, allora Δy = m.

La proprietà che abbiamo ricavato fa comprendere che il coefficiente angolare è il tasso di variazione della variabile y al variare di x, poiché indica di quanto aumenta o diminuisce y sulla retta per un aumento unitario di x: quando l'ascissa aumenta di 1, l'ordinata varia di m.

# ESEMPIO

![img-40.jpeg](img-40.jpeg)

![img-41.jpeg](img-41.jpeg)

a. Nella retta di equazione \( y = 2x - 1 \), \( m = 2 \): quello indica che per andare da \( A(1;1) \) a \( B(2;3) \), quando \( x \) aumenta di 1, \( y \) aumenta di 2,osi come per passare dal punto \( B \) a \( C(3;5) \).
b. Nella retta di equazione \( y = -3x + 1 \), \( m = -3 \): quando l'ascissa aumenta di 1, l'ordinata varia di -3,cioè diminuisce di 3.

Per andare da A(-2; 7) a B(1; -2), x aumenta di 3, dunque y diminuisce di 9 = 3 · 3.

# Listen to it

For a generic line the slope is the ratio of the difference between the y-coordinates to the difference between the x-coordinates of two points on the line. This definition does not apply to vertical lines.

# PROVA SUBITO

Coefficiente angolare di una retta per due punti

Calcola il coefficiente angolare della retta che passa per l'origine e per il punto (6; 2).

La formula ottenuta permette di calcolare il coefficiente angolare della retta passante per due punti, ma non l'equazione di tale retta. Per ottenere l'equazione servono condizioni aggiuntive, come il passaggio da uno dei due punti dati.

204

DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

# Retta passante per due punti

Esercizi a pagina 241

Vogliamo scrivere l'equazione della retta passante per i punti $A(x_1; y_1)$ e $B(x_2; y_2)$, con $x_1 \neq x_2$ e $y_1 \neq y_2$.

Il suo coefficiente angolare è $m = \frac{y_2 - y_1}{x_2 - x_1}$.

Scriviamo l'equazione della retta passante per $A$ e di coefficiente angolare $m$:

$$y - y_1 = \frac{y_2 - y_1}{x_2 - x_1}(x - x_1) \rightarrow$$

$$\frac{y - y_1}{y_2 - y_1} = \frac{x - x_1}{x_2 - x_1} \quad \text{equazione della retta per } A(x_1; y_1) \text{ e } B(x_2; y_2), \text{ con } x_2 \neq x_1 \text{ e } y_2 \neq y_1$$

# ESEMPIO

Ricaviamo l'equazione della retta passante per $(-1; 2)$ e $(3; 1)$.

$$\frac{y - 2}{1 - 2} = \frac{x - (-1)}{3 - (-1)} \rightarrow \frac{y - 2}{-1} = \frac{x + 1}{4} \rightarrow 4y - 8 = -x - 1 \rightarrow$$

$$y = -\frac{x}{4} + \frac{7}{4}$$

Se $x_1 = x_2$, la retta $AB$ è parallela all'asse $y$ e ha equazione $x = x_1$; se $y_1 = y_2$, la retta è parallela all'asse $x$ e ha equazione $y = y_1$.

In questi due casi, scrivere l'equazione non richiede calcoli.

# ESEMPIO

a. L'equazione della retta passante per \(A(-7;\sqrt{2})\) e \(B(-7;12)\) è: \(x = -7\).
b. L'equazione della retta passante per \(A(2;5)\) e \(B(-8;5)\) è: \(y = 5\)

# IDEE E PROBLEMI

# Piano cartesiano e robotica

![img-42.jpeg](img-42.jpeg)

L'utilizzo dei robot nella produzione industriale, per esempio nelle operazioni di taglio di materiali, garantisce una maggior precisione e una riduzione di sprechi e di costi. I robot cartesiani, come suggerisce il nome, sono macchinari che vengono programmati attraverso un sistema di riferimento cartesiano.

Un robot cartesiano per il taglio laser di lamiere metalliche deve essere programmato per ritagliare all'interno di una lamiera quadrata il quadrilatero $ABCD$, come mostrato nella figura.

![img-43.jpeg](img-43.jpeg)

Determiniamo le equazioni delle rette da fornire al robot. Per la retta $AB$ abbiamo:

$$\frac{y - 10}{50 - 10} = \frac{x - 0}{30 - 0} \rightarrow y - 10 = \frac{40}{30}x \rightarrow y = \frac{4}{3}x + 10.$$

Procedendo in modo analogo, abbiamo le altre equazioni:

$$y = 2x - 70, \text{ retta } CD;$$

$$y = -\frac{2}{7}x + 10, \text{ retta } AD;$$

$$y = -x + 80, \text{ retta } BC.$$

# PROVA SUBITO

# Retta per due punti

Scrivi l'equazione della retta che passa per i punti $(3; -2)$ e $(-1; 2)$.

# TECNOLOGIA

# ESERCIZIO

a. Con riferimento alla figura precedente, determina l'area del quadrilatero ABCD tagliato.
b. Il robot taglia alla velocità costante di \(45~\mathrm{cm / s}\). Quanto impiega per il taglio dell'intero quadrilatero?

[a) $1300 \text{ cm}^2$; b) $3,3 \text{ s}$]

205

TECNOLA

Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

# 5 Distanza di un punto da una retta

Esercizi a pagina 247

Tracciamo da un punto P la perpendicolare a una retta r. Chiamiamo H la proiezione ortogonale di P su r, ossia il punto di intersezione fra la retta stessa e la perpendicolare. La misura del segmento di perpendicolare PH è la distanza del punto P dalla retta r.

![img-44.jpeg](img-44.jpeg)

Consideriamo un punto P(x₀; y₀) e una retta r nel piano cartesiano. Esaminiamo i due casi possibili.

- La retta r è parallela all'asse x o all'asse y. In questo caso la distanza di P da r è il valore assoluto della differenza delle ordinate o delle ascisse di P e H.

![img-45.jpeg](img-45.jpeg)

![img-46.jpeg](img-46.jpeg)

- La retta r non è parallela agli assi. Se la retta non è parallela a uno degli assi, consideriamo la distanza come altezza di un particolare triangolo.

# ESEMPIO

Dato il punto P(3; 1), calcoliamo la sua distanza PH dalla retta di equazione 4x - 3y + 3 = 0.

![img-47.jpeg](img-47.jpeg)

Per farlo, tracciamo da P le parallele agli assi fino a incontrare la retta nei punti A e B. Individuiamo così il triangolo rettangolo APB, di cui PH è l'altezza relativa all'ipotenusa.

A ha ordinata 1, come P. Sostituendola nell'equazione della retta, determiniamo la sua ascissa:

$$4x - 3 \cdot 1 + 3 = 0 \rightarrow x = 0.$$

In modo analogo, poiché l'ascissa di B è uguale a quella di P, ricaviamo l'ordinata di B, che è 5.

Otteniamo quindi: A(0; 1), B(3; 5).

Il doppio dell'area di APB si ottiene moltiplicando le misure dei cateti AP e PB. Se dividiamo poi per la misura dell'ipotenusa AB, otteniamo la misura cercata dell'altezza PH relativa all'ipotenusa:

$$\overline{PH} = \frac{\overline{PA} \cdot \overline{PB}}{\overline{AB}} = \frac{3 \cdot 4}{5} = \frac{12}{5}.$$

Utilizzando lo stesso procedimento dell'esempio, si dimostra che, in generale, la distanza d di un punto P(x₀; y₀) da una retta di equazione ax + by + c = 0 è:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

# PROVA SUBITO

Distanza di un punto dalla bisettrice del I e III quadrante

Calcola la distanza del punto

(-2; -7) dalla retta di

equazione y = x.

206

LUOGHI GEOMETRICI E RETTA

Paragrafo 6

# ESEMPIO

Calcoliamo la distanza dell'esempio precedente usando la formula.

Poiché il punto ha coordinate $P(3; 1)$ e la retta ha equazione $4x - 3y + 3 = 0$:

$$d = \frac{|4 \cdot 3 - 3 \cdot 1 + 3|}{\sqrt{4^2 + 3^2}} = \frac{|12 - 3 + 3|}{\sqrt{25}} = \frac{12}{5}.$$

![img-48.jpeg](img-48.jpeg)

# 6 Luoghi geometrici e retta

Un luogo geometrico è l'insieme di tutti e soli i punti che godono di una proprietà, detta proprietà caratteristica del luogo.

Per studiare nel piano cartesiano un luogo geometrico si cerca un'equazione in due incognite $f(x; y) = 0$ le cui soluzioni sono le coordinate di tutti e soli i punti del luogo:

$$P(x_0; y_0) \text{ appartiene al luogo} \quad \leftrightarrow \quad f(x_0; y_0) = 0.$$

L'equazione $f(x; y) = 0$ è detta equazione del luogo.

Una retta può essere vista come il luogo dei punti che godono della proprietà di allineamento. Come sappiamo, l'equazione di questo luogo è un'equazione lineare.

# Asse di un segmento

Esercizi a pagina 249

L'asse di un segmento è la retta perpendicolare al segmento stesso passante per il suo punto medio.

L'equazione dell'asse può essere ricavata ricordando che l'asse è il luogo dei punti equidistanti dagli estremi del segmento.

# ESEMPIO

![img-49.jpeg](img-49.jpeg)

Ricaviamo l'equazione dell'asse del segmento di estremi $A(-1; 5)$ e $B(3; 1)$ considerando che l'asse è il luogo dei punti $P(x; y)$ tali che $\overline{PA} = \overline{PB}$.

Determiniamo le due distanze e uguagliamo:

$$\sqrt{(x+1)^2 + (y-5)^2} = \sqrt{(x-3)^2 + (y-1)^2}.$$

Poiché i due radicali sono non negativi, eleviamo al quadrato entrambi i membri e svolgiamo i calcoli:

$$x^2 + 2x + 1 + y^2 - 10y + 25 = x^2 - 6x + 9 + y^2 - 2y + 1 \rightarrow$$

$$y = x + 2.$$

# Bisettrici degli angoli formati da due rette

Esercizi a pagina 250

La bisettrice di un angolo lo divide in due angoli congruenti ed è il luogo dei punti equidistanti dai lati dell'angolo.

![img-50.jpeg](img-50.jpeg)

Consideriamo due rette $r$ e $s$, non parallele tra loro, di equazioni:

$$r: ax + by + c = 0,$$

$$s: a'x + b'y + c' = 0.$$

Per determinare l'equazione delle due bisettrici, consideriamo un generico punto $P(x; y)$. Esso appartiene a una bisettrice se e solo se ha la stessa distanza dalle rette $r$ e $s$.

# MATEMATICA E STORIA

Alle origini del metodo delle coordinate

Perché il metodo delle coordinate èosi utile?
- Quali problemi ha consentito di risolverre?
Com'e nato e come si e sviluppato nel corso del tempo?

Cerca nel Web:

geometria analitica, Dicearco, Descartes, Fermat

# PROVA SUBITO

Asse di un segmento

Qual è l'equazione dell'asse del segmento che ha per estremi $(1; 4)$ e $(1; -6)$?

207

TEORIA

Capitolo 4 PIANO CARTESIANO E RETTA

TROMA

Utilizzando la formula della distanza di un punto da una retta, si ha

$$\frac{|ax + by + c|}{\sqrt{a^2 + b^2}} = \frac{|a'x + b'y + c'|}{\sqrt{(a')^2 + (b')^2}} \rightarrow \frac{ax + by + c}{\sqrt{a^2 + b^2}} = \pm \frac{a'x + b'y + c'}{\sqrt{(a')^2 + (b')^2}}.$$

Svolgendo i calcoli si ottengono le equazioni delle due rette bisettrici.

# **ESEMPIO**

![img-51.jpeg](img-51.jpeg)

Consideriamo le rette $r$ e $s$:

$r: 4x + 3y - 1 = 0,$

$s: 3x + 4y + 1 = 0.$

Troviamo l'equazione delle bisettrici degli angoli formati dalle due rette.

Se il punto $P(x; y)$ è un generico punto di una bisettrice, allora deve avere la stessa distanza dalle rette $r$ e $s$, cioè: $\overline{PH} = \overline{PK}$.

Si ha: $\frac{|4x + 3y - 1|}{5} = \frac{|3x + 4y + 1|}{5} \rightarrow |4x + 3y - 1| = |3x + 4y + 1|$.

Questa equazione ha per soluzioni quelle delle due equazioni

$4x + 3y - 1 = \pm (3x + 4y + 1),$

cioè:

$$\begin{array}{l} 4x + 3y - 1 = -(3x + 4y + 1) \vee 4x + 3y - 1 = 3x + 4y + 1 \rightarrow \\ x + y = 0 \vee x - y - 2 = 0. \end{array}$$

Le bisettrici degli angoli formati da $r$ e $s$ hanno per equazioni:

$x + y = 0, x - y - 2 = 0.$

# 7 Fasci di rette

# Fascio improprio

Esercizi a pagina 255

Consideriamo una retta $r$ del piano: l'insieme formato da $r$ e da tutte le rette a essa parallele si chiama **fascio improprio** di rette parallele a $r$.

Se $r$, non parallela all'asse $y$, ha equazione $y = mx + q$, le altre rette del fascio hanno tutte lo stesso coefficiente angolare $m$, mentre $q$ varia da retta a retta.

![img-52.jpeg](img-52.jpeg)

# **ESEMPIO**

Troviamo l'equazione del fascio improprio di cui fa parte la retta $r$ che interseca gli assi in $(0; 3)$ e $(1; 0)$.

L'intersezione della retta $r$ con l'asse $y$ è $(0; 3)$, quindi la sua ordinata all'origine è $3$.

Nel passaggio dal punto di ascissa $0$ a quello di ascissa $1$, l'ordinata diminuisce di $3$, quindi il coefficiente angolare è $-3$.

L'equazione della retta $r$ è: $y = -3x + 3$.

Il fascio improprio ha equazione: $y = -3x + q$.

Al variare di $q$, otteniamo tutte le rette del fascio, di cui $q$ è l'ordinata all'origine.

Se $r$ è parallela all'asse $y$, il fascio di rette ha equazione $x = k$.

# **PROVA SUBITO**

# **Bisettrici**

Scrivi le equazioni delle bisettrici degli angoli formati dalle rette

$r: x + y - 4 = 0$ e $s: x - y + 2 = 0.$

208

FASCI DI RETTE

Paragrafo 7

# Fascio proprio

Esercizi a pagina 256

L'insieme di tutte le rette del piano che passano per uno stesso punto P si chiama fascio proprio di rette per P. Il punto P comune a tutte le rette del fascio è il centro del fascio.

# ESEMPIO

![img-53.jpeg](img-53.jpeg)

Determiniamo l'equazione del fascio proprio di rette di centro P(2; 4).

L'equazione di una retta di coefficiente angolare m e passante per (x₁; y₁) è y - y₁ = m(x - x₁). Quindi, se il centro del fascio è P(2; 4), otteniamo:

$$y - 4 = m(x - 2).$$

Al variare di m otteniamo le rette del fascio:

per \(m = 1\) abbiamo la retta \(y - 4 = x - 2\) ,cioe \(y = x + 2\)
per \(m = -2\) la retta \(y - 4 = -2x + 4\) ,cioe \(y = -2x + 8\)
per \(m = 0\) la parallela all'asse \(x\) , di equazione \(y = 4\) , e cosi via.

L'equazione della parallela all'asse y passante per P(2; 4) è x = 2, ma non esiste alcun valore di m che, sostituito nell'equazione, fornisca questa equazione.

Pertanto, il fascio è descritto da:

$$y - 4 = m(x - 2) \vee x = 2, \quad \text{con } m \in \mathbb{R}.$$

In generale, con l'equazione y - y₁ = m(x - x₁), al variare di m si ottengono tutte le rette del fascio passanti per P, tranne la parallela all'asse y, che ha equazione x = x₁. Quindi, il fascio di rette di centro (x₁; y₁) è descritto da:

$$y - y_1 = m(x - x_1) \vee x = x_1, \quad \text{con } m \in \mathbb{R}.$$

# Fasci generati da due rette

Esercizi a pagina 258

Un fascio di rette può essere generato anche partendo da due rette, r e s, di cui si conoscono le equazioni. Se r e s sono incidenti si ottiene un fascio proprio, se invece sono parallele si ha un fascio improprio.

Il fascio si scrive utilizzando la combinazione lineare delle equazioni delle rette.

# Combinazione lineare di due equazioni

Date due equazioni A(x; y) = 0 e B(x; y) = 0, chiamiamo combinazione lineare delle due equazioni ogni equazione del tipo:

$$p \cdot A(x; y) + q \cdot B(x; y) = 0, \quad \text{con } p, q \in \mathbb{R} \text{ non entrambi nulli.}$$

p e q sono detti parametri della combinazione lineare.

# ESEMPIO

Combinazione lineare delle equazioni 3x - 5y - 4 = 0 e x - 2y + 1 = 0:

$$p \cdot (3x - 5y - 4) + q \cdot (x - 2y + 1) = 0, \text{con } p, q \in \mathbb{R} \text{ non entrambi nulli.}$$

Se la coppia (c; d) è soluzione di entrambe le equazioni date, allora è anche soluzione di ogni loro combinazione lineare. Infatti, per ogni valore di p e di q, se (c; d) è soluzione delle due equazioni, allora:

$$A(c; d) = 0, \quad B(c; d) = 0 \rightarrow p \cdot A(c; d) + q \cdot B(c; d) = p \cdot 0 + q \cdot 0 = 0.$$

# Listen to it

The set of all lines passing through a point P in the plane is called the sheaf of lines through P.

# PROVA SUBITO

# Fascio proprio di rette

Determina l'equazione del fascio di rette di centro (-2; 0).

# Equazione completa del fascio

Talvolta, per brevità, si omette la retta x = x₁ nell'equazione del fascio. Quando viene esplicitamente inclusa, si parla di equazione completa del fascio.

# PROVA SUBITO

# Combinazione lineare

Verifica che le equazioni

$$\begin{array}{l} 2x - y + 1 = 0, \\ -3x + 2y - 4 = 0 \end{array}$$

e ogni loro combinazione lineare hanno come soluzione comune (2; 5).

ITALIANA

209

Capitolo 4

PIANO CARTESIANO E RETTA

Studiamo ora i fasci di rette le cui equazioni si possono ottenere dalla combinazione lineare delle equazioni di due rette.

# Fascio proprio

Date le equazioni di due rette r: ax + by + c = 0 e s: a'x + b'y + c' = 0 che si incontrano nel punto C(x₁; y₁), si può dimostrare che le equazioni di tutte le rette del fascio proprio per C si ottengono dalla combinazione lineare:

$$p \cdot (ax + by + c) + q \cdot (a'x + b'y + c') = 0,$$

con p, q ∈ ℝ non entrambi nulli.

Le rette r e s vengono dette generatrici del fascio.

Le loro equazioni si ottengono, rispettivamente, per q = 0 e per p = 0.

Poiché p e q non sono entrambi nulli, supposto p ≠ 0, possiamo dividere entrambi i membri della combinazione lineare per p e, ponendo k = q/p, otteniamo:

$$ax + by + c + k \cdot (a'x + b'y + c') = 0, \quad \text{con } k \in \mathbb{R}.$$

Nell'equazione, a ogni valore di k corrisponde l'equazione di una retta del fascio. In particolare, per k = 0 si ottiene l'equazione della retta r.

Non è invece vero l'inverso in quanto l'equazione della retta s non corrisponde ad alcun valore di k. Tuttavia, la retta s è l'unica retta esclusa.

# ESEMPIO

▶ Combiniamo linearmente le equazioni delle rette r e s, e studiamo il fascio di rette che generano:

$$r: 2x - y - 1 = 0, \quad s: x + y - 5 = 0.$$

Se combiniamo linearmente le equazioni delle due rette, introducendo un solo parametro reale k, otteniamo:

$$2x - y - 1 + k(x + y - 5) = 0.$$

Questa equazione rappresenta, al variare di k, le infinite rette passanti per il punto di intersezione C delle due rette date, esclusa la retta s, ossia rappresenta il fascio proprio di rette di centro C.

Per esempio, per k = 2 si ottiene la retta t: 4x + y - 11 = 0, per k = -2 si ottiene la retta u: y = 3 e così via.

La retta r si ottiene per k = 0, mentre la retta s è l'unica che non si ottiene dall'equazione.

Tuttavia, se nell'equazione

![img-54.jpeg](img-54.jpeg)

$$2x - y - 1 + k(x + y - 5) = 0$$

dividiamo per k, otteniamo l'equazione

$$\frac{1}{k}(2x - y - 1) + (x + y - 5) = 0;$$

se a k sostituiamo valori sempre maggiori, ossia per k → +∞ (si legge: «k tendente a più infinito»), allora 1/k diventa sempre più piccolo, cioè 1/k tende a 0 e otteniamo l'equazione di s: x + y - 5 = 0.

Con un ragionamento analogo, se a k sostituiamo valori negativi sempre minori, ossia per k → -∞ (si legge: «k tendente a meno infinito»), allora 1/k tende a 0 e otteniamo ancora l'equazione di s.

Diciamo allora che la retta s si ottiene dall'equazione del fascio per k → ±∞.

# PROVA SUBITO

# Fascio generato da due rette

Scrivi l'equazione del fascio generato dalle rette di equazioni y = -x + 1 e y = 2x.

# PROVA SUBITO

# Generatrici di un fascio

Trova le generatrici del fascio di rette di equazione

$$x(2k - 1) + ky - 5 = 0, \quad \text{con } k \in \mathbb{R}.$$

ITALIANO

210

FASCI DI RETTE

Paragrafo 7

Le generatrici del fascio possono essere due rette qualsiasi del fascio. In particolare, se consideriamo le due rette parallele agli assi passanti per $P_i(x_i; y_i)$, di equazioni $x - x_i = 0$ e $y - y_i = 0$, otteniamo

$$p \cdot (x - x_i) + q \cdot (y - y_i) = 0,$$

da cui, con $q \neq 0$ e posto $-\frac{p}{q} = m$, abbiamo

$$y - y_i = m \cdot (x - x_i),$$

ossia l'equazione della retta passante per un punto e di coefficiente angolare $m$ che abbiamo già ricavato in altro modo.

# Fascio improprio

Si può dimostrare che anche l'equazione di un fascio improprio di rette si può ottenere dalla combinazione lineare delle equazioni di due rette del fascio.

# ESEMPIO

▶ Combiniamo linearmente le equazioni delle due rette parallele $a$ e $b$, e studiamo il fascio di rette che generano:

$$a: x - y + 1 = 0, \quad b: x - y - 3 = 0.$$

Se combiniamo linearmente le equazioni delle due rette, introducendo un parametro reale $k$, otteniamo l'equazione:

$$x - y + 1 + k(x - y - 3) = 0.$$

![img-55.jpeg](img-55.jpeg)

Esplicitiamo la $y$:

$$\begin{array}{l} x - y + 1 + kx - ky - 3k = 0 \rightarrow \\ (k + 1)y = (k + 1)x + 1 - 3k \xrightarrow{k \neq -1} \\ y = x + \frac{1 - 3k}{k + 1}. \end{array}$$

Otteniamo, al variare di $k$ (con $k \neq -1$), una retta parallela alle generatrici, quindi l'equazione è relativa a un fascio improprio.

In generale, date due rette distinte, $r$ e $s$, di equazioni

$$r: ax + by + c = 0, \quad s: a'x + b'y + c' = 0,$$

il fascio di rette generato da $r$ e $s$ ha equazione

$$ax + by + c + k(a'x + b'y + c') = 0,$$

ossia

$$(a + ka')x + (b + kb')y + c + kc' = 0.$$

Esse sono le equazioni di un fascio:

proprio se \(\frac{a}{b}\neq \frac{a^{\prime}}{b^{\prime}}\)
improprio se \(\frac{a}{b} = \frac{a^{\prime}}{b^{\prime}}\)

In entrambi i casi, l'equazione rappresenta tutte le rette del fascio tranne la retta $s$.

Se viene data un'equazione lineare in $x$ e $y$ con i coefficienti che dipendono dal parametro $k$, essa rappresenta un fascio di rette e solitamente occorre studiare le sue caratteristiche. Vedremo esempi negli esercizi.

# Famiglia di rette

Se nell'equazione

parametrica il grado del

parametro $k$ è maggiore di 1,

non si ha un fascio di rette

ma una più generica famiglia

di rette, che possono essere

fra loro parallele o incidenti.

Per esempio, nell'equazione

$$(k^2 - 1)x + ky + 2 = 0$$

per \(k = 1\)
\(y + 2 = 0\rightarrow y = -2\)
per \(k = -1\)
-y+2=0-y=2
per \(k = 0\)
\(-x + 2 = 0\rightarrow x = 2\)

Le prime due rette sono

parallele, mentre la terza e

ciascuna delle altre due sono

incidenti.

TECNIA

211

TEORIA IN SINTESI

# TEORIA
# IN SINTESI

Mappa dei
fondamentali

Mappa
interattiva

Nel segmento di estremi $P_1(x_1; y_1)$ e $P_2(x_2; y_2)$:

il punto medio $M(x_M; y_M)$ ha coordinate

$$x_M = \frac{x_1 + x_2}{2}, \quad y_M = \frac{y_1 + y_2}{2};$$

la distanza fra $P_1$ e $P_2$ è:

$$P_1 P_2 = \sqrt{(x_1 - x_2)^2 + (y_1 - y_2)^2}.$$

In un triangolo di vertici $A(x_A; y_A)$, $B(x_B; y_B)$ e $C(x_C; y_C)$, le coordinate del baricentro $G$ sono:

$$x_G = \frac{x_A + x_B + x_C}{3}, \quad y_G = \frac{y_A + y_B + y_C}{3}.$$

Equazione di una retta:

- in forma implicita: $ax + by + c = 0$;
- in forma esplicita: $y = mx + q$ (retta non parallela all'asse $y$); $m$ coefficiente angolare, $q$ ordinata all'origine
- parallela all'asse $x$: $y = k$;
- parallela all'asse $y$: $x = h$;
- passante per l'origine $O(0; 0)$: $y = mx$.

Angolo fra una retta e l'asse $x$: è acuto se $m > 0$, ottuso se $m < 0$. Se $m = 0$, allora la retta è parallela all'asse $x$. Il coefficiente angolare non esiste se la retta è parallela all'asse $y$.

Equazione di una retta di coefficiente angolare $m$ e passante per $P(x_1; y_1)$: $y - y_1 = m \cdot (x - x_1)$.

Due rette, $r$: $y = mx + q$ e $s$: $y = m_1x + q_1$, non parallele all'asse $y$, sono fra loro:

- parallele quando hanno lo stesso coefficiente angolare;
- perpendicolari quando il prodotto dei loro coefficienti angolari è uguale a $-1$.

Se le rette hanno equazioni in forma implicita $r$: $ax + by + c = 0$ e $s$: $a_1x + b_1y + c_1 = 0$:

- $r \parallel s \leftrightarrow m = m_1 \leftrightarrow ab_1 - a_1b = 0$;
- $r \perp s \leftrightarrow m = -\frac{1}{m_1} \leftrightarrow aa_1 + bb_1 = 0$.

Distanza di un punto $P(x_0; y_0)$ da una retta $r$ di equazione $ax + by + c = 0$: misura del segmento che ha per estremi il punto $P$ e il piede della perpendicolare a $r$ passante per $P$. Si calcola con:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

Luogo geometrico: l'insieme di tutti e soli i punti che godono di una proprietà.

- Asse di un segmento: la retta perpendicolare al segmento passante per il suo punto medio; è il luogo dei punti equidistanti dagli estremi del segmento.
- Bisettrice di un angolo: la retta che divide l'angolo in due angoli congruenti; è il luogo dei punti equidistanti dai lati dell'angolo.

Date due rette non parallele di equazioni $ax + by + c = 0$ e $a'x + b'y + c' = 0$, le equazioni delle bisettrici degli angoli che le due rette formano sono:

$$\frac{|ax + by + c|}{\sqrt{a^2 + b^2}} = \frac{|a'x + b'y + c'|}{\sqrt{(a')^2 + (b')^2}} \rightarrow \frac{ax + by + c}{\sqrt{a^2 + b^2}} = \pm \frac{a'x + b'y + c'}{\sqrt{(a')^2 + (b')^2}}.$$

Date due rette distinte, $r$ e $r'$, di equazioni

$$r: ax + by + c = 0 \text{ e } r': a'x + b'y + c' = 0,$$

il fascio di rette generato da $r$ e $r'$ ha equazione:

$$ax + by + c + k(a'x + b'y + c') = 0.$$

- Se $r$ e $r'$ si intersecano in un punto $C$, il fascio è proprio con centro in $C$.
- Se $r$ e $r'$ sono parallele, il fascio è improprio.

213

TEORIA