Capitolo 4

PIANO CARTESIANO E RETTA

ITROVA

Possiamo rappresentare il profilo della rampa in un piano cartesiano con una retta che passa per l'origine e per il punto P(100; 8).

La coppia (100; 8) deve quindi essere soluzione dell'equazione y = mx, cioè:

![img-25.jpeg](img-25.jpeg)

$$8 = m \cdot 100 \rightarrow m = \frac{2}{25}.$$

$$m = \frac{2}{25} = \frac{8}{100} = 8\%$$ è proprio la pendenza della rampa.

# Ordinata all'origine e intersezione con l'asse y

![img-26.jpeg](img-26.jpeg)

Il valore di q rappresenta l'ordinata del punto di intersezione della retta con l'asse y.

Per questo motivo, il termine noto dell'equazione

$$y = mx + q$$

si chiama ordinata all'origine o intercetta.

Se q = 0, la retta passa per l'origine.

# 3 Posizione reciproca di due rette

Due rette r e s possono essere incidenti, parallele e distinte, parallele e coincidenti.

La posizione reciproca di r e s è collegata al sistema formato dalle equazioni delle due rette:

$$\begin{cases} ax + by + c = 0 \\ a'x + b'y + c' = 0 \end{cases}$$

# Rette incidenti

Esercizi a pagina 233

# ESEMPIO

![img-27.jpeg](img-27.jpeg)

Un'azienda ha due linee di produzione per fabbricare viti. L'utilizzo di ogni linea prevede dei costi fissi di avviamento e dei costi variabili che dipendono dal numero di confezioni di viti prodotte:

linea A: \(5\in\) per l'avvio \(+2,50\in\) a confezione;
linea B: \(10\in\) per l'avvio \(+2\in\) a confezione.

A ogni avvio si producono al massimo 9 confezioni di un certo tipo di viti, mentre di un secondo tipo di viti si producono sempre più di 12 confezioni.

Quale linea conviene utilizzare per la produzione del primo tipo di viti? E per la produzione del secondo?

Indichiamo con x il numero di confezioni prodotte e con y il costo totale (x > 0 e y > 0), ipotizzando che possano assumere tutti i valori reali positivi, e scriviamo le equazioni che corrispondono alle due possibilità:

![img-28.jpeg](img-28.jpeg)

![img-29.jpeg](img-29.jpeg)

# PROVA SUBITO

# Coefficiente angolare e pendenza

Quale coefficiente angolare ha una retta che rappresenta il profilo di una strada in cui a uno spostamento in orizzontale di 80 m corrisponde uno spostamento in verticale di 4 m?

# Video

# Fabbrica di auto

Quante auto deve vendere una fabrica automobilistica per copire i costi di impianto e andare in par?
E per ave un utile del 5% sul fatturato?

200