LUOGHI GEOMETRICI E RETTA

Paragrafo 6

# ESEMPIO

Calcoliamo la distanza dell'esempio precedente usando la formula.

Poiché il punto ha coordinate $P(3; 1)$ e la retta ha equazione $4x - 3y + 3 = 0$:

$$d = \frac{|4 \cdot 3 - 3 \cdot 1 + 3|}{\sqrt{4^2 + 3^2}} = \frac{|12 - 3 + 3|}{\sqrt{25}} = \frac{12}{5}.$$

![img-48.jpeg](img-48.jpeg)

# 6 Luoghi geometrici e retta

Un luogo geometrico è l'insieme di tutti e soli i punti che godono di una proprietà, detta proprietà caratteristica del luogo.

Per studiare nel piano cartesiano un luogo geometrico si cerca un'equazione in due incognite $f(x; y) = 0$ le cui soluzioni sono le coordinate di tutti e soli i punti del luogo:

$$P(x_0; y_0) \text{ appartiene al luogo} \quad \leftrightarrow \quad f(x_0; y_0) = 0.$$

L'equazione $f(x; y) = 0$ è detta equazione del luogo.

Una retta può essere vista come il luogo dei punti che godono della proprietà di allineamento. Come sappiamo, l'equazione di questo luogo è un'equazione lineare.

# Asse di un segmento

Esercizi a pagina 249

L'asse di un segmento è la retta perpendicolare al segmento stesso passante per il suo punto medio.

L'equazione dell'asse può essere ricavata ricordando che l'asse è il luogo dei punti equidistanti dagli estremi del segmento.

# ESEMPIO

![img-49.jpeg](img-49.jpeg)

Ricaviamo l'equazione dell'asse del segmento di estremi $A(-1; 5)$ e $B(3; 1)$ considerando che l'asse è il luogo dei punti $P(x; y)$ tali che $\overline{PA} = \overline{PB}$.

Determiniamo le due distanze e uguagliamo:

$$\sqrt{(x+1)^2 + (y-5)^2} = \sqrt{(x-3)^2 + (y-1)^2}.$$

Poiché i due radicali sono non negativi, eleviamo al quadrato entrambi i membri e svolgiamo i calcoli:

$$x^2 + 2x + 1 + y^2 - 10y + 25 = x^2 - 6x + 9 + y^2 - 2y + 1 \rightarrow$$

$$y = x + 2.$$

# Bisettrici degli angoli formati da due rette

Esercizi a pagina 250

La bisettrice di un angolo lo divide in due angoli congruenti ed è il luogo dei punti equidistanti dai lati dell'angolo.

![img-50.jpeg](img-50.jpeg)

Consideriamo due rette $r$ e $s$, non parallele tra loro, di equazioni:

$$r: ax + by + c = 0,$$

$$s: a'x + b'y + c' = 0.$$

Per determinare l'equazione delle due bisettrici, consideriamo un generico punto $P(x; y)$. Esso appartiene a una bisettrice se e solo se ha la stessa distanza dalle rette $r$ e $s$.

# MATEMATICA E STORIA

Alle origini del metodo delle coordinate

Perché il metodo delle coordinate èosi utile?
- Quali problemi ha consentito di risolverre?
Com'e nato e come si e sviluppato nel corso del tempo?

Cerca nel Web:

geometria analitica, Dicearco, Descartes, Fermat

# PROVA SUBITO

Asse di un segmento

Qual è l'equazione dell'asse del segmento che ha per estremi $(1; 4)$ e $(1; -6)$?

207

TEORIA