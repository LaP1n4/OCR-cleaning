DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

Sostituiamo nell'uguaglianza del teorema di Pitagora:

$$\begin{array}{l} (m - m _ {1}) ^ {2} = (1 + m ^ {2}) + (1 + m _ {1} ^ {2}) \rightarrow \\ \mu_ {1} ^ {\prime 4} + \mu_ {1} ^ {\prime 4} - 2 m m _ {1} = 2 + \mu_ {1} ^ {\prime 4} + \mu_ {1} ^ {\prime 4} \rightarrow m \cdot m _ {1} = - 1. \end{array}$$

# **ESEMPIO**

![img-37.jpeg](img-37.jpeg)

Le rette di equazioni $y = 2x + 2$ e $y = -\frac{1}{2}x + 1$ sono perpendicolari perché il prodotto dei loro coefficienti angolari è $-1$:

$$2 \cdot \left(- \frac {1}{2}\right) = - 1.$$

Consideriamo le rette $r$ e $s$, che hanno equazioni in forma implicita

$$r: a x + b y + c = 0, \quad s: a _ {1} x + b _ {1} y + c _ {1} = 0.$$

$r$ e $s$ sono perpendicolari se e solo se:

$$m = - \frac {1}{m _ {1}} \leftrightarrow - \frac {a}{b} = - \frac {1}{- \frac {a _ {1}}{b _ {1}}} \leftrightarrow - \frac {a}{b} = \frac {b _ {1}}{a _ {1}} \leftrightarrow a a _ {1} + b b _ {1} = 0.$$

In sintesi:

$$r \perp s \leftrightarrow m = - \frac {1}{m _ {1}} \leftrightarrow a a _ {1} + b b _ {1} = 0.$$

Puoi verificare che la condizione di perpendicolarità $aa_{1} + bb_{1} = 0$ è valida anche per rette parallele agli assi cartesiani. Per esempio:

$$r: y - 4 = 0, \quad s: 2 x + 5 = 0; \quad r \perp s \leftrightarrow 0 \cdot 2 + 1 \cdot 0 = 0.$$

## 4 Determinare l'equazione di una retta

Vogliamo trovare l'equazione di una retta quando di essa sono noti un punto e il coefficiente angolare oppure due punti.

Poiché il coefficiente angolare contiene le informazioni sulla pendenza della retta, dalla geometria euclidea sappiamo che ciascuna delle due condizioni permette di individuare univocamente la retta stessa.

# **Equazione di una retta passante per un punto e di coefficiente angolare noto**

Esercizi a pagina 238

Se una retta, non parallela all'asse $y$, passa per un punto $P(x_1; y_1)$, le coordinate del punto devono soddisfare l'equazione

$$y = m x + q,$$

quindi deve valere

$$y _ {1} = m x _ {1} + q.$$

Sottraendo i due membri della seconda uguaglianza a quelli della prima, otteniamo:

$$y - y _ {1} = m \cdot (x - x _ {1}). \quad \text {e q u a z i o n e d e l l a r t t a d i c o e f f i c i e n t e} \\ \text {a n g o l a r e m p a s s a n t e p e r} P (x _ {1}; y _ {1})$$

# **ESEMPIO**

L'equazione della retta di coefficiente angolare $\frac{3}{4}$ e passante per $P(1;2)$ è:

$$y - 2 = \frac {3}{4} \cdot (x - 1) \quad \rightarrow \quad y = \frac {3}{4} x + \frac {5}{4}.$$

# **PROVA SUBITO**

# **Rette perpendicolari**

Stabilisci quali, fra le seguenti equazioni, rappresentano rette perpendicolari.

a. \(4x + y - 1 = 0\)
b. \(4x - y + 5 = 0\)
c. \(4y - x + 5 = 0\)

# **PROVA SUBITO**

# **Retta per P, noto m**

a. Scrivi l'equazione della retta che passa per il punto (1; 1) e ha coefficiente angolare 5.
b. Scrivi l'equazione della retta parallela a \( r \): \( y = -3x + 5 \) e passante per (0; -3).
c. Trova l'equazione della retta perpendicolare a \( s: y = \frac{3}{4} x - \frac{1}{4} \) e passante per (3; 2).

203

TECNIA