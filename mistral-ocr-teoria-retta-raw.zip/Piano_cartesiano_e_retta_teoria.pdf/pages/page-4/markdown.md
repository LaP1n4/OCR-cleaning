Capitolo 4

PIANO CARTESIANO E RETTA

VICOLI

# ESEMPIO

![img-10.jpeg](img-10.jpeg)

Troviamo il baricentro del triangolo ABC di vertici A(0; -1), B(6; 2) e C(3; 5).

Il baricentro G del triangolo ABC ha coordinate:

$$\begin{array}{l} x_{G} = \frac{0 + 6 + 3}{3} = 3, \\ y_{G} = \frac{-1 + 2 + 5}{3} = 2. \end{array}$$

## 2 Rette nel piano cartesiano

Esercizi a pagina 225

# Equazione lineare in due variabili

Un'equazione lineare in due variabili x e y è un'equazione di primo grado rispetto a entrambe le incognite. Può essere scritta nella forma:

$$ax + by + c = 0,$$

con a, b, c ∈ ℝ (a e b non entrambi nulli).

Una soluzione dell'equazione è una coppia (x₀; y₀) di numeri reali che la soddisfa, cioè che rende vera l'uguaglianza.

# ESEMPIO

Data l'equazione 3x + 2y - 6 = 0, sostituiamo dei valori a x, per esempio:

$$\begin{array}{l} x = 0 \rightarrow 3 \cdot 0 + 2y - 6 = 0 \rightarrow 2y = 6 \rightarrow y = 3; \\ x = 1 \rightarrow 3 \cdot 1 + 2y - 6 = 0 \rightarrow 2y = 3 \rightarrow y = \frac{3}{2}. \end{array}$$

Le coppie (0; 3) e (1; 3/2) sono due soluzioni dell'equazione.

Le soluzioni sono infinite; se a ≠ 0 e b ≠ 0, per ottenerle basta sostituire a x un qualsiasi numero reale e determinare il corrispondente valore di y.

# Equazione della retta in forma implicita

Data un'equazione lineare in due variabili, a ogni soluzione corrisponde un punto del piano cartesiano, mentre, dato un punto del piano, non sempre le sue coordinate sono una delle infinite soluzioni dell'equazione.

Si può dimostrare la seguente proprietà.

A ogni retta del piano cartesiano corrisponde un'equazione lineare in due variabili e, viceversa, a ogni equazione lineare in due variabili corrisponde una retta.

L'equazione

$$ax + by + c = 0,$$

con a, b e c numeri reali e a, b non entrambi nulli, rappresenta, al variare di a, b e c, tutte le rette del piano e viene detta equazione della retta in forma implicita perché nessuna delle variabili è ricavata in funzione dell'altra.

# PROVA SUBITO

# Baricentro di un triangolo

Calcola le coordinate del baricentro del triangolo di vertici (-5; -2), (-3; -2) e (-4; 4).

# STORIE DI MATEMATICA

# Descartes e la geometria analitica

Il francese René Descartes, conosciuto in Italia come Cartesio, sviluppa nel Seicento l'idea di considerare gli oggetti geometrici in relazione a un sistema di coordinate. Nasce così la geometria analitica.

Podcast

# PROVA SUBITO

# Soluzioni di un'equazione lineare

Trova alcune soluzioni dell'equazione

$$y - x + 4 = 0.$$

196