CAPITOLO

4

# Piano cartesiano e retta

![img-0.jpeg](img-0.jpeg)

# 1 Punti e segmenti

# Punti nel piano cartesiano

Esercizi a pagina 214

Fissiamo in un piano un sistema di riferimento cartesiano ortogonale, detto anche piano cartesiano, considerando due rette orientate tra loro perpendicolari. Le due rette sono gli assi del riferimento e vengono chiamate asse delle ascisse, o asse x, e asse delle ordinate, o asse y. Il loro punto di intersezione O è l'origine.

Scelta un'unità di misura su entrambi gli assi, ogni punto P del piano è rappresentato da una coppia ordinata di numeri reali (x_P; y_P) e viceversa.

![img-1.jpeg](img-1.jpeg)

Si crea così una corrispondenza biunivoca tra i punti del piano e le coppie ordinate di numeri reali.

In ogni coppia (x_P; y_P), x_P e y_P sono le coordinate del punto, il primo numero è l'ascissa e il secondo è l'ordinata.

Chiamiamo quadranti i punti interni ai quattro angoli retti in cui il piano cartesiano è diviso dagli assi. I quadranti sono ordinati in senso antiorario a partire dal quadrante in alto a destra. Le coordinate dei punti del piano sono positive o negative a seconda del quadrante in cui i punti si trovano.

![img-2.jpeg](img-2.jpeg)

I punti dell'asse x hanno ordinata 0, quelli dell'asse y hanno ascissa 0. L'origine O ha coordinate (0; 0).

Per esempio, il punto A(-4; 3) appartiene al secondo quadrante, mentre B(0; -5) appartiene all'asse y.

2 Video

1 Podcast,

3 Listen to it

1 Codice Python

Listen to it

A Cartesian coordinate system in the plane is given by a pair of axes that intersect at a point, called the origin: every point in the plane is uniquely identified by an ordered pair of coordinates, the abscissa (x) and the ordinate (y).

Video

Coordinate geografiche

Come funzionano le coordinate geografiche terrestri?
Come possono essere rappresentate su un piano?

193