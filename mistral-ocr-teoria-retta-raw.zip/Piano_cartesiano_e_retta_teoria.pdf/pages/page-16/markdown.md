Capitolo 4 PIANO CARTESIANO E RETTA

TROMA

Utilizzando la formula della distanza di un punto da una retta, si ha

$$\frac{|ax + by + c|}{\sqrt{a^2 + b^2}} = \frac{|a'x + b'y + c'|}{\sqrt{(a')^2 + (b')^2}} \rightarrow \frac{ax + by + c}{\sqrt{a^2 + b^2}} = \pm \frac{a'x + b'y + c'}{\sqrt{(a')^2 + (b')^2}}.$$

Svolgendo i calcoli si ottengono le equazioni delle due rette bisettrici.

# **ESEMPIO**

![img-51.jpeg](img-51.jpeg)

Consideriamo le rette $r$ e $s$:

$r: 4x + 3y - 1 = 0,$

$s: 3x + 4y + 1 = 0.$

Troviamo l'equazione delle bisettrici degli angoli formati dalle due rette.

Se il punto $P(x; y)$ è un generico punto di una bisettrice, allora deve avere la stessa distanza dalle rette $r$ e $s$, cioè: $\overline{PH} = \overline{PK}$.

Si ha: $\frac{|4x + 3y - 1|}{5} = \frac{|3x + 4y + 1|}{5} \rightarrow |4x + 3y - 1| = |3x + 4y + 1|$.

Questa equazione ha per soluzioni quelle delle due equazioni

$4x + 3y - 1 = \pm (3x + 4y + 1),$

cioè:

$$\begin{array}{l} 4x + 3y - 1 = -(3x + 4y + 1) \vee 4x + 3y - 1 = 3x + 4y + 1 \rightarrow \\ x + y = 0 \vee x - y - 2 = 0. \end{array}$$

Le bisettrici degli angoli formati da $r$ e $s$ hanno per equazioni:

$x + y = 0, x - y - 2 = 0.$

# 7 Fasci di rette

# Fascio improprio

Esercizi a pagina 255

Consideriamo una retta $r$ del piano: l'insieme formato da $r$ e da tutte le rette a essa parallele si chiama **fascio improprio** di rette parallele a $r$.

Se $r$, non parallela all'asse $y$, ha equazione $y = mx + q$, le altre rette del fascio hanno tutte lo stesso coefficiente angolare $m$, mentre $q$ varia da retta a retta.

![img-52.jpeg](img-52.jpeg)

# **ESEMPIO**

Troviamo l'equazione del fascio improprio di cui fa parte la retta $r$ che interseca gli assi in $(0; 3)$ e $(1; 0)$.

L'intersezione della retta $r$ con l'asse $y$ è $(0; 3)$, quindi la sua ordinata all'origine è $3$.

Nel passaggio dal punto di ascissa $0$ a quello di ascissa $1$, l'ordinata diminuisce di $3$, quindi il coefficiente angolare è $-3$.

L'equazione della retta $r$ è: $y = -3x + 3$.

Il fascio improprio ha equazione: $y = -3x + q$.

Al variare di $q$, otteniamo tutte le rette del fascio, di cui $q$ è l'ordinata all'origine.

Se $r$ è parallela all'asse $y$, il fascio di rette ha equazione $x = k$.

# **PROVA SUBITO**

# **Bisettrici**

Scrivi le equazioni delle bisettrici degli angoli formati dalle rette

$r: x + y - 4 = 0$ e $s: x - y + 2 = 0.$

208