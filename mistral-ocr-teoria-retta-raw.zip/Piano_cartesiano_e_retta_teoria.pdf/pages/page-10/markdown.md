Capitolo 4

PIANO CARTESIANO E RETTA

ITOGNA

Le rette sono parallele e distinte se

$$m = m_1 \quad \text{e} \quad q \neq q_1.$$

Le rette sono parallele e coincidenti se

$$m = m_1 \quad \text{e} \quad q = q_1.$$

Riassumiamo i casi possibili della posizione reciproca di due rette.

![img-32.jpeg](img-32.jpeg)

![img-33.jpeg](img-33.jpeg)

![img-34.jpeg](img-34.jpeg)

a. Le rette sono incidenti:

$$\frac{a}{a_1} \neq \frac{b}{b_1} \leftrightarrow m \neq m_1.$$

Il sistema è determinato e ammette per soluzione le coordinate di P.

b. Le rette sono parallele e distinte:

$$\frac{a}{a_1} = \frac{b}{b_1} \neq \frac{c}{c_1} \leftrightarrow (m = m_1) \wedge (q \neq q_1).$$

Il sistema è impossibile.

c. Le rette sono coincidenti:

$$\frac{a}{a_1} = \frac{b}{b_1} = \frac{c}{c_1} \leftrightarrow (m = m_1) \wedge (q = q_1).$$

Il sistema è indeterminato.

# Rette perpendicolari

Esercizi a pagina 236

Vale il seguente teorema.

# TEOREMA

# Rette perpendicolari

Due rette r e s (non parallele agli assi), di equazioni y = mx + q e y = m₁x + q₁, sono perpendicolari se e solo se il prodotto dei loro coefficienti angolari è -1:

$$r \perp s \leftrightarrow mm_1 = -1.$$

# DIMOSTRAZIONE

1 Consideriamo le rette r' e s' parallele a r e s e passanti per l'origine. Le loro equazioni sono:

![img-35.jpeg](img-35.jpeg)

$$r': y = mx, \quad s': y = m_1x.$$

Gli angoli che si formano fra r' e s' sono congruenti a quelli formati da r e s, quindi r' e s' sono perpendicolari se e solo se lo sono r e s.

Se dimostriamo il teorema per r' e s', esso vale anche per r e s.

2 Su r' e s' prendiamo i punti A e B con ascissa 1:

$$A(1; m), B(1; m_1).$$

![img-36.jpeg](img-36.jpeg)

Il triangolo AOB è rettangolo in O se e solo se vale il teorema di Pitagora:

$$\overline{AB}^2 = \overline{OA}^2 + \overline{OB}^2.$$

Esprimiamo $\overline{AB}^2, \overline{OA}^2$ e $\overline{OB}^2$ in funzione di m e m₁:

$$\overline{AB} = |m - m_1| \rightarrow \overline{AB}^2 = (m - m_1)^2;$$

$$\overline{OA} = \sqrt{(1 - 0)^2 + (m - 0)^2} \rightarrow \overline{OA}^2 = 1 + m^2;$$

$$\overline{OB} = \sqrt{(1 - 0)^2 + (m_1 - 0)^2} \rightarrow \overline{OB}^2 = 1 + m_1^2.$$

202