PUNTI E SEGMENTI

Paragrafo 1

In sintesi, dati i punti $A(x_A; y_A)$ e $B(x_B; y_B)$, il punto medio $M$ del segmento $AB$ ha coordinate:

$$x_M = \frac{x_A + x_B}{2}, \quad y_M = \frac{y_A + y_B}{2}.$$

# ESEMPIO

Determiniamo il punto medio $M$ del segmento $AB$ con $A(2; 1)$ e $B(8; 5)$.

![img-8.jpeg](img-8.jpeg)

$$x_M = \frac{2 + 8}{2} = 5;$$

$$y_M = \frac{1 + 5}{2} = 3.$$

# Baricentro di un triangolo

Esercizi a pagina 220

Il baricentro di un triangolo è il punto di incontro delle tre mediane. Ognuna di esse è divisa dal baricentro in due parti tali che quella che ha un estremo nel vertice è doppia dell'altra.

![img-9.jpeg](img-9.jpeg)

Consideriamo i punti non allineati $A(x_A; y_A)$, $B(x_B; y_B)$ e $C(x_C; y_C)$. Vogliamo calcolare le coordinate $(x_G; y_G)$ del baricentro $G$ del triangolo $ABC$.

Determiniamo le coordinate di $M$, punto medio del lato $AB$, con le formule del punto medio:

$$x_M = \frac{x_A + x_B}{2}, \quad y_M = \frac{y_A + y_B}{2}.$$

Per la proprietà del baricentro, vale la relazione: $CG \cong 2GM$.

Tracciamo le parallele all'asse $y$ passanti per $M$, $G$ e $C$ e, considerando le trasversali $MC$ e $M'C'$, applichiamo il teorema di Talete.

Poiché $CG \cong 2GM$, allora $C'G' \cong 2G'M'$.

Determiniamo le misure dei segmenti $C'G'$ e $G'M'$:

$$\overline{C'G'} = x_C - x_G, \quad \overline{G'M'} = x_G - x_M.$$

Poiché $\overline{C'G'} = 2\overline{G'M'}$, sostituendo otteniamo:

$$x_C - x_G = 2(x_G - x_M).$$

Ricaviamo $x_G$:

$$x_C - x_G = 2x_G - 2x_M \rightarrow 3x_G = x_C + 2x_M \rightarrow x_G = \frac{x_C + 2x_M}{3}.$$

Sostituendo $x_M = \frac{x_A + x_B}{2}$, si ottiene:

$$x_G = \frac{x_C + 2x_M}{3} = \frac{x_C + 2\frac{x_A + x_B}{2}}{3} = \frac{x_A + x_B + x_C}{3}.$$

Analogamente, se proiettiamo $M$, $G$ e $C$ sull'asse $y$, troviamo $y_G = \frac{y_A + y_B + y_C}{3}$.

Quindi, dato un triangolo di vertici $A(x_A; y_A)$, $B(x_B; y_B)$, $C(x_C; y_C)$, le coordinate del suo baricentro $G$ sono espresse dalle formule:

$$x_G = \frac{x_A + x_B + x_C}{3}, \quad y_G = \frac{y_A + y_B + y_C}{3}.$$

# PROVA SUBITO

# Punto medio

Determina il punto medio del segmento che ha per estremi i punti $(-2; 0)$ e $(4; -3)$.

# Teorema di Talete

In un fascio di rette parallele tagliate da due trasversali, i segmenti su una trasversale sono proporzionali ai segmenti corrispondenti sull'altra.

195

TEORIA