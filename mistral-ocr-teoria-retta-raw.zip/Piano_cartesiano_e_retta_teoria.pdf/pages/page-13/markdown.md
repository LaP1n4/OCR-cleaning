DETERMINARE L'EQUAZIONE DI UNA RETTA

Paragrafo 4

# Retta passante per due punti

Esercizi a pagina 241

Vogliamo scrivere l'equazione della retta passante per i punti $A(x_1; y_1)$ e $B(x_2; y_2)$, con $x_1 \neq x_2$ e $y_1 \neq y_2$.

Il suo coefficiente angolare è $m = \frac{y_2 - y_1}{x_2 - x_1}$.

Scriviamo l'equazione della retta passante per $A$ e di coefficiente angolare $m$:

$$y - y_1 = \frac{y_2 - y_1}{x_2 - x_1}(x - x_1) \rightarrow$$

$$\frac{y - y_1}{y_2 - y_1} = \frac{x - x_1}{x_2 - x_1} \quad \text{equazione della retta per } A(x_1; y_1) \text{ e } B(x_2; y_2), \text{ con } x_2 \neq x_1 \text{ e } y_2 \neq y_1$$

# ESEMPIO

Ricaviamo l'equazione della retta passante per $(-1; 2)$ e $(3; 1)$.

$$\frac{y - 2}{1 - 2} = \frac{x - (-1)}{3 - (-1)} \rightarrow \frac{y - 2}{-1} = \frac{x + 1}{4} \rightarrow 4y - 8 = -x - 1 \rightarrow$$

$$y = -\frac{x}{4} + \frac{7}{4}$$

Se $x_1 = x_2$, la retta $AB$ è parallela all'asse $y$ e ha equazione $x = x_1$; se $y_1 = y_2$, la retta è parallela all'asse $x$ e ha equazione $y = y_1$.

In questi due casi, scrivere l'equazione non richiede calcoli.

# ESEMPIO

a. L'equazione della retta passante per \(A(-7;\sqrt{2})\) e \(B(-7;12)\) è: \(x = -7\).
b. L'equazione della retta passante per \(A(2;5)\) e \(B(-8;5)\) è: \(y = 5\)

# IDEE E PROBLEMI

# Piano cartesiano e robotica

![img-42.jpeg](img-42.jpeg)

L'utilizzo dei robot nella produzione industriale, per esempio nelle operazioni di taglio di materiali, garantisce una maggior precisione e una riduzione di sprechi e di costi. I robot cartesiani, come suggerisce il nome, sono macchinari che vengono programmati attraverso un sistema di riferimento cartesiano.

Un robot cartesiano per il taglio laser di lamiere metalliche deve essere programmato per ritagliare all'interno di una lamiera quadrata il quadrilatero $ABCD$, come mostrato nella figura.

![img-43.jpeg](img-43.jpeg)

Determiniamo le equazioni delle rette da fornire al robot. Per la retta $AB$ abbiamo:

$$\frac{y - 10}{50 - 10} = \frac{x - 0}{30 - 0} \rightarrow y - 10 = \frac{40}{30}x \rightarrow y = \frac{4}{3}x + 10.$$

Procedendo in modo analogo, abbiamo le altre equazioni:

$$y = 2x - 70, \text{ retta } CD;$$

$$y = -\frac{2}{7}x + 10, \text{ retta } AD;$$

$$y = -x + 80, \text{ retta } BC.$$

# PROVA SUBITO

# Retta per due punti

Scrivi l'equazione della retta che passa per i punti $(3; -2)$ e $(-1; 2)$.

# TECNOLOGIA

# ESERCIZIO

a. Con riferimento alla figura precedente, determina l'area del quadrilatero ABCD tagliato.
b. Il robot taglia alla velocità costante di \(45~\mathrm{cm / s}\). Quanto impiega per il taglio dell'intero quadrilatero?

[a) $1300 \text{ cm}^2$; b) $3,3 \text{ s}$]

205

TECNOLA