RETTE NEL PIANO CARTESIANO

Paragrafo 2

# Casi particolari dell'equazione $ax + by + c = 0$

Nell'equazione $ax + by + c = 0$ sono presenti tre parametri reali: $a$, $b$ e $c$. Vediamo che cosa accade se uno o due di essi si annullano, con $a$ e $b$ non entrambi nulli.

# 1. Retta parallela all'asse $x$.

Se $a = 0$ e $b \neq 0$, l'equazione $ax + by + c = 0$ diventa

$$by + c = 0 \rightarrow y = -\frac{c}{b}, \quad \text{con } b \neq 0.$$

Se poniamo $-\frac{c}{b} = k$, otteniamo $y = k$.

Detto $A(0; k)$ il punto di intersezione con l'asse $y$ di una retta parallela all'asse $x$:

- tutti i punti della retta hanno ordinata \(k\)
- ogni punto di ordinata \(k\) appartiene alla retta.

![img-11.jpeg](img-11.jpeg)

Quindi tutti e soli i punti della retta soddisfano l'equazione:

$y = k$, equazione di una retta parallela all'asse $x$.

Per esempio, $y = -2$ è l'equazione della retta parallela all'asse $x$ i cui punti hanno tutti ordinata $-2$.

![img-12.jpeg](img-12.jpeg)

Se $k = 0$, ovvero $c = 0$, la retta coincide con l'asse $x$, che ha quindi equazione:

$$y = 0. \quad \text{equazione dell'asse } x$$

# 2. Retta parallela all'asse $y$.

Se $a \neq 0$ e $b = 0$, l'equazione diventa

$$ax + c = 0 \rightarrow x = -\frac{c}{a}, \quad \text{con } a \neq 0.$$

Se poniamo $-\frac{c}{a} = h$, otteniamo $x = h$.

Detto $B(h; 0)$ il punto di intersezione con l'asse $x$ di una retta parallela all'asse $y$:

![img-13.jpeg](img-13.jpeg)

- tutti i punti della retta hanno ascissa \( h \)
- ogni punto di ascissa \( h \) appartiene alla retta.

Quindi tutti e soli i punti della retta soddisfano l'equazione:

$x = h$, equazione di una retta parallela all'asse $y$.

Per esempio, $x = \frac{1}{2}$ è l'equazione della retta parallela all'asse $y$ i cui punti hanno tutti ascissa $\frac{1}{2}$.

![img-14.jpeg](img-14.jpeg)

Se $h = 0$, ovvero $c = 0$, la retta coincide con l'asse $y$, che ha quindi equazione:

$$x = 0. \quad \text{equazione dell'asse } y$$

![img-15.jpeg](img-15.jpeg)

# 3. Retta passante per l'origine.

Se $a \neq 0$, $b \neq 0$ e $c = 0$, l'equazione diventa $ax + by = 0$ e rappresenta una retta che passa per l'origine degli assi.

Infatti, se sostituiamo le coordinate dell'origine $O(0; 0)$ nell'equazione, otteniamo $a \cdot 0 + b \cdot 0 = 0 \rightarrow 0 = 0$: l'equazione è soddisfatta per qualunque valore di $a$ e $b$.

# Equazione della retta in forma esplicita

Se nell'equazione della retta $ax + by + c = 0$ esplicitiamo la variabile $y$, otteniamo:

$$by = -ax - c \xrightarrow{b \neq 0} y = -\frac{a}{b}x - \frac{c}{b}.$$

Nel considerare $b \neq 0$ escludiamo il caso $ax + c = 0$, che rappresenta una retta parallela all'asse $y$.

# PROVA SUBITO

Retta parallela all'asse $x$

Disegna la retta di equazione $3y + 9 = 0$.

# PROVA SUBITO

Retta parallela all'asse $y$

Disegna la retta di equazione $5x - 10 = 0$.

197

TEORIA