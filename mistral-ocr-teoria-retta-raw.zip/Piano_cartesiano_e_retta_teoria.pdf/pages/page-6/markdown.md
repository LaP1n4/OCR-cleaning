Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

Poniamo $m = -\frac{a}{b}$ e $q = -\frac{c}{b}$ e scriviamo $y = mx + q$, che è l'equazione di una retta generica non parallela all'asse $y$.

L'equazione $y = mx + q$ è detta equazione della retta in forma esplicita perché in essa viene espressa la variabile $y$ in funzione di $x$.

$y = mx + q$ è l'equazione di una funzione lineare.

# Casi particolari dell'equazione $y = mx + q$

Nell'equazione $y = mx + q$ sono presenti due parametri reali, $m$ e $q$, che possono annullarsi.

# 1. Retta parallela all'asse $x$

Se $m = 0$, l'equazione diventa $y = q$, che, come abbiamo visto, rappresenta una retta parallela all'asse $x$.

Se anche $q = 0$, otteniamo $y = 0$, l'equazione dell'asse $x$.

# 2. Retta passante per l'origine

Se $q = 0$, l'equazione diventa

$$y = mx,$$

che rappresenta una retta passante per l'origine degli assi.

Infatti, sostituendo le coordinate di $O(0; 0)$ nell'equazione, per ogni $m \in \mathbb{R}$ abbiamo: $0 = m \cdot 0 \to 0 = 0$.

Per esempio, rappresentiamo l'equazione $y = 2x$ assegnando a $x$ alcuni valori.

|  x | y  |
| --- | --- |
|  -1 | -2  |
|  0 | 0  |
|  1/2 | 1  |
|  1 | 2  |

![img-16.jpeg](img-16.jpeg)

![img-17.jpeg](img-17.jpeg)

Viceversa, data una retta passante per l'origine, che non coincida con l'asse $y$, prendiamo a caso alcuni suoi punti, per esempio quelli della figura, $P, P'$ e $P''$. Indichiamo con $H, H'$ e $H''$ le loro proiezioni sull'asse $x$. I triangoli $OPH, OP'H'$ e $OP''H''$ sono simili tra loro, quindi:

$$\frac{PH}{OH'} = \frac{P'H'}{OH''} = \frac{P''H''}{OH''}.$$

Considerando le coordinate dei punti, possiamo allora scrivere:

$$\frac{y_P}{x_P} = \frac{y_{P'}}{x_{P'}} = \frac{y_{P''}}{x_{P''}} = m,$$

dove $m$ è un numero reale costante. Tutti i punti della retta godono di questa proprietà e, viceversa, si può dimostrare che la proprietà è vera soltanto per essi. In conclusione, una retta passante per l'origine, escluso l'asse $y$, ha equazione

$$y = mx$$

![img-18.jpeg](img-18.jpeg)

e viceversa.

Se $m = 1$, i punti della retta hanno l'ascissa uguale all'ordinata (figura a lato). Il triangolo $OHP$ è rettangolo e isoscele, quindi $H\widehat{OP}$ è metà dell'angolo retto e la retta è la bisettrice del primo e terzo quadrante.

$y = x$ — equazione della bisettrice del primo e terzo quadrante

# PROVA SUBITO

Dalla forma implicita alla forma esplicita

Scrivi in forma esplicita l'equazione della retta $8x + 4y - 6 = 0$.

198