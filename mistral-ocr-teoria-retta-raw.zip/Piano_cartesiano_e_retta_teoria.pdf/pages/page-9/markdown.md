POSIZIONE RECIPROCA DI DUE RETTE

Paragrafo 3

Rappresentiamo le rette e troviamo il punto di intersezione.

![img-30.jpeg](img-30.jpeg)

$$\left\{ \begin{array}{l} y = 5 + 2,50x \\ y = 10 + 2x \end{array} \right. \rightarrow \left\{ \begin{array}{l} 10 + 2x = 5 + 2,50x \\ y = 10 + 2x \end{array} \right. \rightarrow$$

$$\left\{ \begin{array}{l} 0,50x = 5 \\ y = 10 + 2x \end{array} \right. \rightarrow \left\{ \begin{array}{l} x = 10 \\ y = 30 \end{array} \right.$$

La linea di produzione più conveniente da usare è quella che, al variare di $x$, comporta costi più bassi.

Per $x = 10$ le due linee di produzione sono equivalenti, per $x < 10$ conviene la A, per $x > 10$ conviene la B. Per il primo tipo di viti, di cui si producono al massimo 9 confezioni, all'azienda conviene avviare la linea A, mentre per il secondo tipo, di cui si producono più di 12 confezioni alla volta, conviene avviare la linea B.

## Rette parallele

Esercizi a pagina 236

Dimostriamo il seguente teorema.

# TEOREMA

# Rette parallele

Due rette $r$ e $s$ (non parallele all'asse $y$), di equazioni $y = mx + q$ e $y = m_1x + q_1$, sono parallele se e solo se hanno lo stesso coefficiente angolare:

$$r \parallel s \leftrightarrow m = m_1.$$

# DIMOSTRAZIONE

Due rette sono parallele se non hanno punti in comune oppure se coincidono. Il sistema delle loro equazioni,

$$\left\{ \begin{array}{l} y = mx + q \\ y = m_1x + q_1, \end{array} \right.$$

non può essere determinato, altrimenti le rette sarebbero incidenti.

Quindi il sistema deve essere impossibile o indeterminato.

Utilizzando il metodo del confronto, otteniamo l'equazione

$$mx + q = m_1x + q_1 \rightarrow mx - m_1x = q_1 - q \rightarrow (m - m_1)x = q_1 - q,$$

che è impossibile o indeterminata se e solo se:

$$m - m_1 = 0 \rightarrow m = m_1.$$

# ESEMPIO

![img-31.jpeg](img-31.jpeg)

Le rette di equazioni $y = 2x + 4$ e $y = 2x - 1$ sono parallele perché hanno lo stesso coefficiente angolare 2. Le rappresentiamo nella figura a lato.

Se le rette $r$ e $s$, non parallele all'asse $y$, hanno equazioni in forma implicita

$$r: ax + by + c = 0, \quad s: a_1x + b_1y + c_1 = 0,$$

i loro coefficienti angolari sono $m = -\frac{a}{b}$ e $m_1 = -\frac{a_1}{b_1}$.

Quindi, $r$ e $s$ sono parallele se e solo se:

$$m = m_1 \leftrightarrow -\frac{a}{b} = -\frac{a_1}{b_1} \leftrightarrow ab_1 = a_1b \leftrightarrow ab_1 - a_1b = 0.$$

In sintesi:

$$r \parallel s \leftrightarrow m = m_1 \leftrightarrow ab_1 - a_1b = 0.$$

Puoi verificare che la condizione di parallelismo $ab_1 - a_1b = 0$ è valida anche per rette parallele all'asse $y$. Per esempio:

$$r: x - 4 = 0, \quad s: 5x + 10 = 0; \quad r \parallel s \leftrightarrow 1 \cdot 0 - 5 \cdot 0 = 0.$$

# PROVA SUBITO

# Rette parallele

Stabilisci quali, fra le seguenti equazioni, rappresentano rette parallele, distinguendo tra coincidenti e distinte.

a. \(13y - 39x + 26 = 0\)
b. \(y = 3x - 2\)
c. \(6x - 2y + 5 = 0\)
d. \(3x + y + 4 = 0\)

201

TEORAMA