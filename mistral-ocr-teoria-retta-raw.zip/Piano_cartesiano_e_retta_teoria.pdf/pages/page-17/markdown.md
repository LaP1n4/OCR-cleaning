FASCI DI RETTE

Paragrafo 7

# Fascio proprio

Esercizi a pagina 256

L'insieme di tutte le rette del piano che passano per uno stesso punto P si chiama fascio proprio di rette per P. Il punto P comune a tutte le rette del fascio è il centro del fascio.

# ESEMPIO

![img-53.jpeg](img-53.jpeg)

Determiniamo l'equazione del fascio proprio di rette di centro P(2; 4).

L'equazione di una retta di coefficiente angolare m e passante per (x₁; y₁) è y - y₁ = m(x - x₁). Quindi, se il centro del fascio è P(2; 4), otteniamo:

$$y - 4 = m(x - 2).$$

Al variare di m otteniamo le rette del fascio:

per \(m = 1\) abbiamo la retta \(y - 4 = x - 2\) ,cioe \(y = x + 2\)
per \(m = -2\) la retta \(y - 4 = -2x + 4\) ,cioe \(y = -2x + 8\)
per \(m = 0\) la parallela all'asse \(x\) , di equazione \(y = 4\) , e cosi via.

L'equazione della parallela all'asse y passante per P(2; 4) è x = 2, ma non esiste alcun valore di m che, sostituito nell'equazione, fornisca questa equazione.

Pertanto, il fascio è descritto da:

$$y - 4 = m(x - 2) \vee x = 2, \quad \text{con } m \in \mathbb{R}.$$

In generale, con l'equazione y - y₁ = m(x - x₁), al variare di m si ottengono tutte le rette del fascio passanti per P, tranne la parallela all'asse y, che ha equazione x = x₁. Quindi, il fascio di rette di centro (x₁; y₁) è descritto da:

$$y - y_1 = m(x - x_1) \vee x = x_1, \quad \text{con } m \in \mathbb{R}.$$

# Fasci generati da due rette

Esercizi a pagina 258

Un fascio di rette può essere generato anche partendo da due rette, r e s, di cui si conoscono le equazioni. Se r e s sono incidenti si ottiene un fascio proprio, se invece sono parallele si ha un fascio improprio.

Il fascio si scrive utilizzando la combinazione lineare delle equazioni delle rette.

# Combinazione lineare di due equazioni

Date due equazioni A(x; y) = 0 e B(x; y) = 0, chiamiamo combinazione lineare delle due equazioni ogni equazione del tipo:

$$p \cdot A(x; y) + q \cdot B(x; y) = 0, \quad \text{con } p, q \in \mathbb{R} \text{ non entrambi nulli.}$$

p e q sono detti parametri della combinazione lineare.

# ESEMPIO

Combinazione lineare delle equazioni 3x - 5y - 4 = 0 e x - 2y + 1 = 0:

$$p \cdot (3x - 5y - 4) + q \cdot (x - 2y + 1) = 0, \text{con } p, q \in \mathbb{R} \text{ non entrambi nulli.}$$

Se la coppia (c; d) è soluzione di entrambe le equazioni date, allora è anche soluzione di ogni loro combinazione lineare. Infatti, per ogni valore di p e di q, se (c; d) è soluzione delle due equazioni, allora:

$$A(c; d) = 0, \quad B(c; d) = 0 \rightarrow p \cdot A(c; d) + q \cdot B(c; d) = p \cdot 0 + q \cdot 0 = 0.$$

# Listen to it

The set of all lines passing through a point P in the plane is called the sheaf of lines through P.

# PROVA SUBITO

# Fascio proprio di rette

Determina l'equazione del fascio di rette di centro (-2; 0).

# Equazione completa del fascio

Talvolta, per brevità, si omette la retta x = x₁ nell'equazione del fascio. Quando viene esplicitamente inclusa, si parla di equazione completa del fascio.

# PROVA SUBITO

# Combinazione lineare

Verifica che le equazioni

$$\begin{array}{l} 2x - y + 1 = 0, \\ -3x + 2y - 4 = 0 \end{array}$$

e ogni loro combinazione lineare hanno come soluzione comune (2; 5).

ITALIANA

209