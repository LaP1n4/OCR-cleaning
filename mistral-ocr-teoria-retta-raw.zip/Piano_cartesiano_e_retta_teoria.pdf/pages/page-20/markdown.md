TEORIA IN SINTESI

# TEORIA
# IN SINTESI

Mappa dei
fondamentali

Mappa
interattiva

Nel segmento di estremi $P_1(x_1; y_1)$ e $P_2(x_2; y_2)$:

il punto medio $M(x_M; y_M)$ ha coordinate

$$x_M = \frac{x_1 + x_2}{2}, \quad y_M = \frac{y_1 + y_2}{2};$$

la distanza fra $P_1$ e $P_2$ è:

$$P_1 P_2 = \sqrt{(x_1 - x_2)^2 + (y_1 - y_2)^2}.$$

In un triangolo di vertici $A(x_A; y_A)$, $B(x_B; y_B)$ e $C(x_C; y_C)$, le coordinate del baricentro $G$ sono:

$$x_G = \frac{x_A + x_B + x_C}{3}, \quad y_G = \frac{y_A + y_B + y_C}{3}.$$

Equazione di una retta:

- in forma implicita: $ax + by + c = 0$;
- in forma esplicita: $y = mx + q$ (retta non parallela all'asse $y$); $m$ coefficiente angolare, $q$ ordinata all'origine
- parallela all'asse $x$: $y = k$;
- parallela all'asse $y$: $x = h$;
- passante per l'origine $O(0; 0)$: $y = mx$.

Angolo fra una retta e l'asse $x$: è acuto se $m > 0$, ottuso se $m < 0$. Se $m = 0$, allora la retta è parallela all'asse $x$. Il coefficiente angolare non esiste se la retta è parallela all'asse $y$.

Equazione di una retta di coefficiente angolare $m$ e passante per $P(x_1; y_1)$: $y - y_1 = m \cdot (x - x_1)$.

Due rette, $r$: $y = mx + q$ e $s$: $y = m_1x + q_1$, non parallele all'asse $y$, sono fra loro:

- parallele quando hanno lo stesso coefficiente angolare;
- perpendicolari quando il prodotto dei loro coefficienti angolari è uguale a $-1$.

Se le rette hanno equazioni in forma implicita $r$: $ax + by + c = 0$ e $s$: $a_1x + b_1y + c_1 = 0$:

- $r \parallel s \leftrightarrow m = m_1 \leftrightarrow ab_1 - a_1b = 0$;
- $r \perp s \leftrightarrow m = -\frac{1}{m_1} \leftrightarrow aa_1 + bb_1 = 0$.

Distanza di un punto $P(x_0; y_0)$ da una retta $r$ di equazione $ax + by + c = 0$: misura del segmento che ha per estremi il punto $P$ e il piede della perpendicolare a $r$ passante per $P$. Si calcola con:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

Luogo geometrico: l'insieme di tutti e soli i punti che godono di una proprietà.

- Asse di un segmento: la retta perpendicolare al segmento passante per il suo punto medio; è il luogo dei punti equidistanti dagli estremi del segmento.
- Bisettrice di un angolo: la retta che divide l'angolo in due angoli congruenti; è il luogo dei punti equidistanti dai lati dell'angolo.

Date due rette non parallele di equazioni $ax + by + c = 0$ e $a'x + b'y + c' = 0$, le equazioni delle bisettrici degli angoli che le due rette formano sono:

$$\frac{|ax + by + c|}{\sqrt{a^2 + b^2}} = \frac{|a'x + b'y + c'|}{\sqrt{(a')^2 + (b')^2}} \rightarrow \frac{ax + by + c}{\sqrt{a^2 + b^2}} = \pm \frac{a'x + b'y + c'}{\sqrt{(a')^2 + (b')^2}}.$$

Date due rette distinte, $r$ e $r'$, di equazioni

$$r: ax + by + c = 0 \text{ e } r': a'x + b'y + c' = 0,$$

il fascio di rette generato da $r$ e $r'$ ha equazione:

$$ax + by + c + k(a'x + b'y + c') = 0.$$

- Se $r$ e $r'$ si intersecano in un punto $C$, il fascio è proprio con centro in $C$.
- Se $r$ e $r'$ sono parallele, il fascio è improprio.

213

TEORIA