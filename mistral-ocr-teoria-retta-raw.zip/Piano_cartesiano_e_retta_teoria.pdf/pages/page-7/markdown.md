RETTE NEL PIANO CARTESIANO

Paragrafo 2

Analogamente, se $m = -1$, i punti della retta hanno coordinate opposte (figura a lato). Il triangolo $OKQ$ è rettangolo e isoscele e l'angolo $K\overline{O}Q$ è metà dell'angolo retto.

![img-19.jpeg](img-19.jpeg)

$y = -x$ — equazione della bisettrice del secondo e quarto quadrante

Se $m = 0$, otteniamo nuovamente l'equazione dell'asse $x$.

Se confrontiamo quanto esaminato per le due equazioni, in forma implicita ed esplicita, confermiamo che le uniche rette non rappresentate dall'equazione $y = mx + q$, al variare di $m$ e $q$, sono le rette parallele all'asse $y$, di equazione $x = h$. Si ha quindi che

$$ax + by + c = 0 \quad \text{equivale a} \quad y = mx + q \lor x = h.$$

Se $b \neq 0$, per passare dalla forma implicita a quella esplicita basta risolvere l'equazione rispetto a $y$. Tale operazione è utile per mettere in evidenza i valori di $m$ e di $q$, che hanno un preciso significato nel grafico della retta.

# Significato di $m$ e $q$ nell'equazione $y = mx + q$

# Coefficiente angolare e pendenza

![img-20.jpeg](img-20.jpeg)

Chiamiamo angolo fra retta e asse $x$ l'angolo orientato $\alpha$ che ha per vertice il loro punto di intersezione e come lati la semiretta costituita dai punti della retta con ordinata positiva e la semiretta sull'asse $x$ di verso positivo. L'angolo è misurato in senso antiorario a partire dal semiasse positivo delle ascisse.

Il valore di $m$ è funzione di tale angolo ed esprime la pendenza della retta rispetto all'asse $x$. Per questo motivo, il coefficiente $m$ si chiama coefficiente angolare.

# ESEMPIO

Osserviamo la figura a fianco. Ricordando le relazioni fra le misure dei lati di un triangolo con angoli acuti di $30^{\circ}$ e di $60^{\circ}$, se l'angolo fra la retta passante per l'origine e l'asse $x$ è di $60^{\circ}$, $P(1; \sqrt{3})$ appartiene alla retta, quindi:

$$\sqrt{3} = m \cdot 1 \rightarrow m = \sqrt{3}.$$

Nella figura a fianco vediamo come varia $m$ al variare dell'angolo $\alpha$:

![img-21.jpeg](img-21.jpeg)

se \(\alpha\) e nullo o piatto, \(m\) e nullo;
se \(\alpha\) e acuto, \(m\) assume valori positivi e sempre maggiori man mano che l'angolo si avvicina all'angolo retto;
se \(\alpha\) e retto, non esiste un corrispondente valore di \(m\) in quanto le rette parallele all'asse \(y\) non hanno equazione esprimibile nella forma \(y = mx\);
se \(\alpha\) e ottuso, \(m\) e negativo e assume valori sempre minori,cioe sempre maggiori in valore assoluto, all'avicinarisi di \(\alpha\) all'angolo retto.

# ESEMPIO

![img-22.jpeg](img-22.jpeg)

In base alla normativa, una rampa per disabili non può avere una pendenza superiore all'8%. Questo significa che, per una rampa con la massima pendenza consentita, uno spostamento orizzontale di $1 \text{ m} = 100 \text{ cm}$ comporta uno spostamento verticale di $8 \text{ cm}$.

A quale coefficiente angolare corrisponde tale pendenza?

>SEGUE

![img-23.jpeg](img-23.jpeg)

![img-24.jpeg](img-24.jpeg)

Se $\overline{OA} = 1$, allora $\overline{OP} = 2$ e $\overline{AP} = \sqrt{3}$, quindi $P(1; \sqrt{3})$.

# PROVA SUBITO

# Angolo di $30^{\circ}$

Qual è il coefficiente angolare di una retta passante per l'origine che forma con l'asse $x$ un angolo di $30^{\circ}$?

199

TECNIA