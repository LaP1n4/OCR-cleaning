Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

# 5 Distanza di un punto da una retta

Esercizi a pagina 247

Tracciamo da un punto P la perpendicolare a una retta r. Chiamiamo H la proiezione ortogonale di P su r, ossia il punto di intersezione fra la retta stessa e la perpendicolare. La misura del segmento di perpendicolare PH è la distanza del punto P dalla retta r.

![img-44.jpeg](img-44.jpeg)

Consideriamo un punto P(x₀; y₀) e una retta r nel piano cartesiano. Esaminiamo i due casi possibili.

- La retta r è parallela all'asse x o all'asse y. In questo caso la distanza di P da r è il valore assoluto della differenza delle ordinate o delle ascisse di P e H.

![img-45.jpeg](img-45.jpeg)

![img-46.jpeg](img-46.jpeg)

- La retta r non è parallela agli assi. Se la retta non è parallela a uno degli assi, consideriamo la distanza come altezza di un particolare triangolo.

# ESEMPIO

Dato il punto P(3; 1), calcoliamo la sua distanza PH dalla retta di equazione 4x - 3y + 3 = 0.

![img-47.jpeg](img-47.jpeg)

Per farlo, tracciamo da P le parallele agli assi fino a incontrare la retta nei punti A e B. Individuiamo così il triangolo rettangolo APB, di cui PH è l'altezza relativa all'ipotenusa.

A ha ordinata 1, come P. Sostituendola nell'equazione della retta, determiniamo la sua ascissa:

$$4x - 3 \cdot 1 + 3 = 0 \rightarrow x = 0.$$

In modo analogo, poiché l'ascissa di B è uguale a quella di P, ricaviamo l'ordinata di B, che è 5.

Otteniamo quindi: A(0; 1), B(3; 5).

Il doppio dell'area di APB si ottiene moltiplicando le misure dei cateti AP e PB. Se dividiamo poi per la misura dell'ipotenusa AB, otteniamo la misura cercata dell'altezza PH relativa all'ipotenusa:

$$\overline{PH} = \frac{\overline{PA} \cdot \overline{PB}}{\overline{AB}} = \frac{3 \cdot 4}{5} = \frac{12}{5}.$$

Utilizzando lo stesso procedimento dell'esempio, si dimostra che, in generale, la distanza d di un punto P(x₀; y₀) da una retta di equazione ax + by + c = 0 è:

$$d = \frac{|ax_0 + by_0 + c|}{\sqrt{a^2 + b^2}}.$$

# PROVA SUBITO

Distanza di un punto dalla bisettrice del I e III quadrante

Calcola la distanza del punto

(-2; -7) dalla retta di

equazione y = x.

206