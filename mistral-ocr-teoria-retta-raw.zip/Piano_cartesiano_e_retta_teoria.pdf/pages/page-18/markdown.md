Capitolo 4

PIANO CARTESIANO E RETTA

Studiamo ora i fasci di rette le cui equazioni si possono ottenere dalla combinazione lineare delle equazioni di due rette.

# Fascio proprio

Date le equazioni di due rette r: ax + by + c = 0 e s: a'x + b'y + c' = 0 che si incontrano nel punto C(x₁; y₁), si può dimostrare che le equazioni di tutte le rette del fascio proprio per C si ottengono dalla combinazione lineare:

$$p \cdot (ax + by + c) + q \cdot (a'x + b'y + c') = 0,$$

con p, q ∈ ℝ non entrambi nulli.

Le rette r e s vengono dette generatrici del fascio.

Le loro equazioni si ottengono, rispettivamente, per q = 0 e per p = 0.

Poiché p e q non sono entrambi nulli, supposto p ≠ 0, possiamo dividere entrambi i membri della combinazione lineare per p e, ponendo k = q/p, otteniamo:

$$ax + by + c + k \cdot (a'x + b'y + c') = 0, \quad \text{con } k \in \mathbb{R}.$$

Nell'equazione, a ogni valore di k corrisponde l'equazione di una retta del fascio. In particolare, per k = 0 si ottiene l'equazione della retta r.

Non è invece vero l'inverso in quanto l'equazione della retta s non corrisponde ad alcun valore di k. Tuttavia, la retta s è l'unica retta esclusa.

# ESEMPIO

▶ Combiniamo linearmente le equazioni delle rette r e s, e studiamo il fascio di rette che generano:

$$r: 2x - y - 1 = 0, \quad s: x + y - 5 = 0.$$

Se combiniamo linearmente le equazioni delle due rette, introducendo un solo parametro reale k, otteniamo:

$$2x - y - 1 + k(x + y - 5) = 0.$$

Questa equazione rappresenta, al variare di k, le infinite rette passanti per il punto di intersezione C delle due rette date, esclusa la retta s, ossia rappresenta il fascio proprio di rette di centro C.

Per esempio, per k = 2 si ottiene la retta t: 4x + y - 11 = 0, per k = -2 si ottiene la retta u: y = 3 e così via.

La retta r si ottiene per k = 0, mentre la retta s è l'unica che non si ottiene dall'equazione.

Tuttavia, se nell'equazione

![img-54.jpeg](img-54.jpeg)

$$2x - y - 1 + k(x + y - 5) = 0$$

dividiamo per k, otteniamo l'equazione

$$\frac{1}{k}(2x - y - 1) + (x + y - 5) = 0;$$

se a k sostituiamo valori sempre maggiori, ossia per k → +∞ (si legge: «k tendente a più infinito»), allora 1/k diventa sempre più piccolo, cioè 1/k tende a 0 e otteniamo l'equazione di s: x + y - 5 = 0.

Con un ragionamento analogo, se a k sostituiamo valori negativi sempre minori, ossia per k → -∞ (si legge: «k tendente a meno infinito»), allora 1/k tende a 0 e otteniamo ancora l'equazione di s.

Diciamo allora che la retta s si ottiene dall'equazione del fascio per k → ±∞.

# PROVA SUBITO

# Fascio generato da due rette

Scrivi l'equazione del fascio generato dalle rette di equazioni y = -x + 1 e y = 2x.

# PROVA SUBITO

# Generatrici di un fascio

Trova le generatrici del fascio di rette di equazione

$$x(2k - 1) + ky - 5 = 0, \quad \text{con } k \in \mathbb{R}.$$

ITALIANO

210