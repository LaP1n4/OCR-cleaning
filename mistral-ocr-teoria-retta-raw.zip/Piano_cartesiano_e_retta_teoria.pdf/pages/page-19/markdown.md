FASCI DI RETTE

Paragrafo 7

Le generatrici del fascio possono essere due rette qualsiasi del fascio. In particolare, se consideriamo le due rette parallele agli assi passanti per $P_i(x_i; y_i)$, di equazioni $x - x_i = 0$ e $y - y_i = 0$, otteniamo

$$p \cdot (x - x_i) + q \cdot (y - y_i) = 0,$$

da cui, con $q \neq 0$ e posto $-\frac{p}{q} = m$, abbiamo

$$y - y_i = m \cdot (x - x_i),$$

ossia l'equazione della retta passante per un punto e di coefficiente angolare $m$ che abbiamo già ricavato in altro modo.

# Fascio improprio

Si può dimostrare che anche l'equazione di un fascio improprio di rette si può ottenere dalla combinazione lineare delle equazioni di due rette del fascio.

# ESEMPIO

▶ Combiniamo linearmente le equazioni delle due rette parallele $a$ e $b$, e studiamo il fascio di rette che generano:

$$a: x - y + 1 = 0, \quad b: x - y - 3 = 0.$$

Se combiniamo linearmente le equazioni delle due rette, introducendo un parametro reale $k$, otteniamo l'equazione:

$$x - y + 1 + k(x - y - 3) = 0.$$

![img-55.jpeg](img-55.jpeg)

Esplicitiamo la $y$:

$$\begin{array}{l} x - y + 1 + kx - ky - 3k = 0 \rightarrow \\ (k + 1)y = (k + 1)x + 1 - 3k \xrightarrow{k \neq -1} \\ y = x + \frac{1 - 3k}{k + 1}. \end{array}$$

Otteniamo, al variare di $k$ (con $k \neq -1$), una retta parallela alle generatrici, quindi l'equazione è relativa a un fascio improprio.

In generale, date due rette distinte, $r$ e $s$, di equazioni

$$r: ax + by + c = 0, \quad s: a'x + b'y + c' = 0,$$

il fascio di rette generato da $r$ e $s$ ha equazione

$$ax + by + c + k(a'x + b'y + c') = 0,$$

ossia

$$(a + ka')x + (b + kb')y + c + kc' = 0.$$

Esse sono le equazioni di un fascio:

proprio se \(\frac{a}{b}\neq \frac{a^{\prime}}{b^{\prime}}\)
improprio se \(\frac{a}{b} = \frac{a^{\prime}}{b^{\prime}}\)

In entrambi i casi, l'equazione rappresenta tutte le rette del fascio tranne la retta $s$.

Se viene data un'equazione lineare in $x$ e $y$ con i coefficienti che dipendono dal parametro $k$, essa rappresenta un fascio di rette e solitamente occorre studiare le sue caratteristiche. Vedremo esempi negli esercizi.

# Famiglia di rette

Se nell'equazione

parametrica il grado del

parametro $k$ è maggiore di 1,

non si ha un fascio di rette

ma una più generica famiglia

di rette, che possono essere

fra loro parallele o incidenti.

Per esempio, nell'equazione

$$(k^2 - 1)x + ky + 2 = 0$$

per \(k = 1\)
\(y + 2 = 0\rightarrow y = -2\)
per \(k = -1\)
-y+2=0-y=2
per \(k = 0\)
\(-x + 2 = 0\rightarrow x = 2\)

Le prime due rette sono

parallele, mentre la terza e

ciascuna delle altre due sono

incidenti.

TECNIA

211