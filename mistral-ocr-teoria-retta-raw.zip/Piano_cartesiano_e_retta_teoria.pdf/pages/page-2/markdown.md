Capitolo 4

PIANO CARTESIANO E RETTA

ITALIANO

# Distanza fra due punti

Esercizi a pagina 216

# I punti hanno la stessa ordinata o la stessa ascissa

La distanza fra due punti $A(x_A; y_A)$ e $B(x_B; y_B)$ che hanno la stessa ordinata $y_A = y_B$ è la differenza delle loro ascisse, presa in valore assoluto, in modo da non doverci preoccupare di qual è la maggiore:

![img-3.jpeg](img-3.jpeg)

$$\overline{AB} = |x_B - x_A|.$$

Per esempio, nella figura a: $\overline{AB} = |x_B - x_A| = |3 - (-4)| = 7$.

Analogamente, la distanza fra due punti $A(x_A; y_A)$ e $B(x_B; y_B)$ con la stessa ascissa $x_A = x_B$ è:

![img-4.jpeg](img-4.jpeg)

$$\overline{AB} = |y_B - y_A|.$$

Per esempio, nella figura b: $\overline{AB} = |-1 - 2| = 3$.

# Il caso generale

Consideriamo il segmento $AB$ non parallelo agli assi cartesiani e indichiamo con $H$ il punto di intersezione tra la retta parallela all'asse $x$ tracciata da $A$ e la retta parallela all'asse $y$ tracciata da $B$. $H$ ha ascissa $x_B$ e ordinata $y_A$.

Applichiamo il teorema di Pitagora al triangolo rettangolo $ABH$:

![img-5.jpeg](img-5.jpeg)

$$\overline{AB} = \sqrt{AH^2 + BH^2}.$$

$$\overline{AH} = |x_B - x_A| \quad \text{e} \quad \overline{BH} = |y_B - y_A|.$$

quindi:

![img-6.jpeg](img-6.jpeg)

$$\overline{AB} = \sqrt{(x_B - x_A)^2 + (y_B - y_A)^2}.$$

Per esempio, nella figura c:

$$\overline{AB} = \sqrt{(5 - 2)^2 + (7 - 3)^2} = \sqrt{3^2 + 4^2} = \sqrt{9 + 16} = 5.$$

La formula è applicabile anche nei due casi particolari precedenti.

Inoltre, la distanza di un punto $P(x; y)$ dall'origine $O$ è $\overline{OP} = \sqrt{x^2 + y^2}$.

# Punto medio di un segmento

Esercizi a pagina 218

Consideriamo i punti $A(x_A; y_A)$ e $B(x_B; y_B)$. Vogliamo calcolare le coordinate del punto medio $M$ del segmento $AB$.

Dopo aver tracciato le parallele agli assi passanti per i punti $A, B$ e $M$, applichiamo il teorema di Talete dei segmenti congruenti: dato un fascio di rette parallele tagliato da due trasversali, a segmenti congruenti su una trasversale corrispondono segmenti congruenti sull'altra trasversale.

![img-7.jpeg](img-7.jpeg)

$AM \cong MB$, perché per ipotesi $M$ è punto medio di $AB$, quindi $A'M' \cong M'B'$ e $A''M'' \cong M''B''$.

$$\overline{A'M'} = \overline{M'B'}, \quad \text{quindi} \quad |x_M - x_A| = |x_B - x_M|.$$

Poiché $x_A < x_M$ e $x_M < x_B$, eliminiamo i valori assoluti:

$$x_M - x_A = x_B - x_M.$$

Ricaviamo $x_M$:

$$x_M + x_M = x_A + x_B \rightarrow 2x_M = x_A + x_B \rightarrow x_M = \frac{x_A + x_B}{2}.$$

Con considerazioni analoghe, otteniamo: $y_M = \frac{y_A + y_B}{2}$.

194