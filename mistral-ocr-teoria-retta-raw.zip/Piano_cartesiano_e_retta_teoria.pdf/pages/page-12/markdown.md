Capitolo 4

PIANO CARTESIANO E RETTA

VACCIA

# Coefficiente angolare, note le coordinate di due punti

Esercizi a pagina 239

Ricaviamo il coefficiente angolare m di una retta di equazione y = mx + q in funzione delle coordinate di due suoi punti distinti, A(x₁; y₁) e B(x₂; y₂).

y₁ = mx₁ + q, perché A è un punto della retta;

y₂ = mx₂ + q, perché B è un punto della retta.

Sottraendo membro a membro la prima equazione dalla seconda:

$$y_2 - y_1 = mx_2 - mx_1 \quad \rightarrow \quad y_2 - y_1 = m(x_2 - x_1) \quad \rightarrow \quad m = \frac{y_2 - y_1}{x_2 - x_1}.$$

# PROPRIETÀ

![img-38.jpeg](img-38.jpeg)

Il coefficiente angolare di una retta non parallela all'asse y è il rapporto fra la differenza delle ordinate e la differenza delle ascisse di due punti distinti della retta, prese nello stesso ordine:

$$m = \frac{y_2 - y_1}{x_2 - x_1}, \quad \text{con } x_2 \neq x_1.$$

# ESEMPIO

![img-39.jpeg](img-39.jpeg)

Qual è il coefficiente angolare della retta passante per i punti A(-2; 2) e B(3; -1/2)?

$$m = \frac{-\frac{1}{2} - 2}{3 - (-2)} = \frac{-\frac{5}{2}}{5} = -\frac{1}{2}.$$

Se indichiamo con Δx l'incremento x₂ - x₁ dei valori di x e con Δy la corrispondente variazione y₂ - y₁ dei valori di y, otteniamo:

$$m = \frac{y_2 - y_1}{x_2 - x_1} = \frac{\Delta y}{\Delta x}.$$

Se Δx = 1, allora Δy = m.

La proprietà che abbiamo ricavato fa comprendere che il coefficiente angolare è il tasso di variazione della variabile y al variare di x, poiché indica di quanto aumenta o diminuisce y sulla retta per un aumento unitario di x: quando l'ascissa aumenta di 1, l'ordinata varia di m.

# ESEMPIO

![img-40.jpeg](img-40.jpeg)

![img-41.jpeg](img-41.jpeg)

a. Nella retta di equazione \( y = 2x - 1 \), \( m = 2 \): quello indica che per andare da \( A(1;1) \) a \( B(2;3) \), quando \( x \) aumenta di 1, \( y \) aumenta di 2,osi come per passare dal punto \( B \) a \( C(3;5) \).
b. Nella retta di equazione \( y = -3x + 1 \), \( m = -3 \): quando l'ascissa aumenta di 1, l'ordinata varia di -3,cioè diminuisce di 3.

Per andare da A(-2; 7) a B(1; -2), x aumenta di 3, dunque y diminuisce di 9 = 3 · 3.

# Listen to it

For a generic line the slope is the ratio of the difference between the y-coordinates to the difference between the x-coordinates of two points on the line. This definition does not apply to vertical lines.

# PROVA SUBITO

Coefficiente angolare di una retta per due punti

Calcola il coefficiente angolare della retta che passa per l'origine e per il punto (6; 2).

La formula ottenuta permette di calcolare il coefficiente angolare della retta passante per due punti, ma non l'equazione di tale retta. Per ottenere l'equazione servono condizioni aggiuntive, come il passaggio da uno dei due punti dati.

204